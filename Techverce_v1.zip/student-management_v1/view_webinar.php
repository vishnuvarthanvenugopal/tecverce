<?php 
include "header.php";
include "left-menu.php";
if(isset($_POST["submit"]))
{
	$webinar_id = $_POST['webinar_id'];
    $filename = md5($_POST['title']).".pdf";  
	$filepath = "../webinar/files/invitations/";
    $newname = $filepath .$filename;
    $FileType = pathinfo($newname,PATHINFO_EXTENSION);
    //$FileType == "pdf";
   
		$category_of_event = $_POST['category_of_event'];
		$title = $_POST['title'];
		$start_date_time = $_POST['start_date_time'];
		$end_date_time = $_POST['end_date_time'];
		$start_date_time = date('Y-m-d H:i:s',strtotime($start_date_time));
		$end_date_time = date('Y-m-d H:i:s',strtotime($end_date_time));
		$event_organizer = $_POST['event_organizer'];
		$registration_link = $_POST['registration_link'];
		$join_event_link = $_POST['join_event_link'];
		$video_link = $_POST['video_link'];
		$feedback_link = $_POST['feedback_link'];
		$staff_name = $_POST['staff_name'];
		$organizer_name = $_POST['organizer_name'];
		$staff_phone = $_POST['staff_phone'];
		$staff_email = $_POST['staff_email'];
		$staff_details = $_POST['staff_details'];
		$event_details = $_POST['event_details'];
		$invitation_brochure = $_POST['invitation_brochure_old'];
		$staff_photo = $_POST['staff_photo_old'];
		$banner_image = $_POST['banner_image_old'];
		
		$invitation_path = "../webinar/files/invitations/".basename( $_FILES['invitation_brochure']['name']);
		$profile_path = "../webinar/files/profile_images/".basename( $_FILES['staff_photo']['name']);
		$banner_image_path = "../webinar/files/banner_image/".basename( $_FILES['banner_image']['name']);
		
        if(move_uploaded_file($_FILES['invitation_brochure']['tmp_name'],$invitation_path))
        {
			$invitation_brochure = $_FILES['invitation_brochure']['name'];
			$invitation_brochure_old = "../webinar/files/invitations/".$_POST['invitation_brochure_old'];
			unlink($invitation_brochure_old);
		}
		if(move_uploaded_file($_FILES['staff_photo']['tmp_name'],$profile_path))
        {
			$staff_photo = $_FILES['staff_photo']['name'];
			$staff_photo_old = "../webinar/files/profile_images/".$_POST['staff_photo_old'];
			unlink($staff_photo_old);
		}
		if(move_uploaded_file($_FILES['banner_image']['tmp_name'],$banner_image_path))
        {
			$banner_image = $_FILES['banner_image']['name'];
			$banner_image_old = "../webinar/files/banner_image/".$_POST['banner_image_old'];
			unlink($banner_image_old);
		}
			
			
			
			//$date = $_POST['start_date_time'];
			//$date = new \DateTime();
			//$start_date_time =  date_format($date, 'Y-m-d H:i:s');
			//echo date_format($date, 'G:ia');
			$updatedata = mysqli_query($connection,"update webinar_info set category_of_event='$category_of_event',title='$title',start_date_time='$start_date_time',end_date_time='$end_date_time',event_organizer='$event_organizer',registration_link='$registration_link',join_event_link='$join_event_link',video_link='$video_link',feedback_link='$feedback_link',staff_name='$staff_name',organizer_name='$organizer_name',staff_phone='$staff_phone',staff_email='$staff_email',staff_details='$staff_details',event_details='$event_details',invitation_brochure='$invitation_brochure',staff_photo='$staff_photo',banner_image='$banner_image' where id='$webinar_id'") or die(mysqli_error($connection));

			if($updatedata)
			{
				echo "<script>
				  alert('Webinar updated succefully!')
				  window.location.href='view_webinar.php'
				  </script>";
			}
			else
			{
				echo "<script>
				  alert('Webinar Record update Error')
				  //window.location.href='add_webinar.php'
				  </script>";
			}
		  
       
   
	

}
?> 

<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="css/font-awesome.css">
<link rel="stylesheet" href="css/bootstrap-datetimepicker.min.css" type="text/css" media="all" />

<div class="page-wrapper">
  <!-- Bread crumb -->
  <div class="row page-titles">
    <div class="col-md-5 align-self-center">
      <h3 class="text-primary">View Webinar</h3> </div>
      <div class="col-md-7 align-self-center">
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
          <li class="breadcrumb-item active">View Webinar</li>
        </ol>
      </div>
    </div>
    <!-- End Bread crumb -->
    <!-- Container fluid  -->
    <div class="container-fluid">
      <!-- Start Page Content -->
      <div class="row">
        <div class="col-12">
          <div class="card">
		  
            <div class="card-body">
			
              <h2 style="text-align: center;">Webinar Details</h2> 
				<?php
					if(!empty($_GET['videw_webinar']))
					{
						echo "<p><a href='javascript:window.history.back();'> Go Back </a></p>";
						
						$webinar_id=$_GET['videw_webinar'];
						$result = mysqli_query($connection,"SELECT * FROM webinar_info where id='$webinar_id'") or die(mysqli_error());
						$i = 1;
						$row = mysqli_fetch_array( $result ); 
						
						$date = $row['start_date_time'];
						$start_date_time =  date('d-m-Y G:i A',strtotime($date));
						
						$date2 = $row['end_date_time'];
						$end_date_time =  date('d-m-Y G:i A',strtotime($date2));
						//echo date_format($date, 'G:ia');
						
						  echo "<div class='table-responsive m-t-40'> <table border='0px solid #000' width='60%' cellspacing='10' cellpadding='10' style='color:#000'>";
						  echo '<tr style="height:50px"><td> Banner Image <td/><td><img src="../webinar/files/banner_image/' . $row['banner_image'] . '" width="260" height="120" alt="No Image"/></td></tr>';
						  echo '<tr style="height:50px"><td> Staff  Image <td/><td><img src="../webinar/files/profile_images/' . $row['staff_photo'] . '" height="90" alt="No Image"/></td></tr>';
						  echo '<tr style="height:50px"><td>Staff Name : <td/><td>' . $row['staff_name'] . '</td></tr>';
						  echo '<tr style="height:50px"><td>Title : <td/><td>' . $row['title'] . '</td></tr>';
						  echo '<tr style="height:50px"><td>Category : <td/><td>' . $row['category_of_event'] . '</td></tr>';
						  echo '<tr style="height:50px"><td>Date and Time : <td/><td>' . $start_date_time . '</td></tr>';
						  echo '<tr style="height:50px"><td>End and Time : <td/><td>' . $end_date_time . '</td></tr>';
						  echo '<tr style="height:50px"><td>Event Organizer  : <td/><td>' . $row['event_organizer'] . '</td></tr>';
						  echo '<tr style="height:50px"><td>Registration Link  : <td/><td>' . $row['registration_link'] . '</td></tr>';
						  echo '<tr style="height:50px"><td>Join Event Link : <td/><td>' . $row['join_event_link'] . '</td></tr>';
						  echo '<tr style="height:50px"><td>Video link : <td/><td>' . $row['video_link'] . '</td></tr>';
						  echo '<tr style="height:50px"><td>Feedback Link : <td/><td>' . $row['feedback_link'] . '</td></tr>';
						  echo '<tr style="height:50px"><td>Staff Details : <td/><td>' . $row['staff_details'] . '</td></tr>';
						  echo '<tr style="height:50px"><td>Event Details  : <td/><td>' . $row['event_details'] . '</td></tr>';
						  echo '<tr style="height:50px"><td>Event Organizer Name  : <td/><td>' . $row['organizer_name'] . '</td></tr>';
						  echo '<tr style="height:50px"><td>Event Organizer Phone  : <td/><td>' . $row['staff_phone'] . '</td></tr>';
						  echo '<tr style="height:50px"><td>Event Organizer Email  : <td/><td>' . $row['staff_email'] . '</td></tr>';
						  echo '<tr style="height:50px"><td>Invitations  : <td/><td> <a href="../webinar/files/invitations/'.$row['invitation_brochure'].'" target="_blank" download> Download Invitation </a></td></tr>';
					                      
						  echo "  </div> </table>";
					}
					else if(!empty($_GET['update_webinar']))
					{
						echo "<p><a href='javascript:window.history.back();'> Go Back </a></p>";
						
						$webinar_id=$_GET['update_webinar'];
						$result = mysqli_query($connection,"SELECT * FROM webinar_info where id='$webinar_id'") or die(mysqli_error());
						$i = 1;
						$row = mysqli_fetch_array( $result ); 
						
						$date = $row['start_date_time'];
						$start_date_time =  date('d-m-Y G:i A',strtotime($date));
						//echo date_format($date, 'G:ia');
						/*
						  echo "<div class='table-responsive m-t-40'> <table border='0px solid #000' width='50%' cellspacing='10' cellpadding='10' style='color:#000'>";
						  echo '<tr style="height:50px"><td> &nbsp; <td/><td><img src="../webinar/files/profile_images/' . $row['staff_photo'] . '" height="90"/></td></tr>';
						  echo '<tr style="height:50px"><td>Staff Name : <td/><td>' . $row['staff_name'] . '</td></tr>';
						  echo '<tr style="height:50px"><td>Title : <td/><td>' . $row['title'] . '</td></tr>';
						  echo '<tr style="height:50px"><td>Category : <td/><td>' . $row['category_of_event'] . '</td></tr>';
						  echo '<tr style="height:50px"><td>Date and Time : <td/><td>' . $start_date_time . '</td></tr>';
						  echo '<tr style="height:50px"><td>Event Organizer  : <td/><td>' . $row['event_organizer'] . '</td></tr>';
						  echo '<tr style="height:50px"><td>Registration Link  : <td/><td>' . $row['registration_link'] . '</td></tr>';
						  echo '<tr style="height:50px"><td>Join Event Link : <td/><td>' . $row['join_event_link'] . '</td></tr>';
						  echo '<tr style="height:50px"><td>Video link : <td/><td>' . $row['video_link'] . '</td></tr>';
						  echo '<tr style="height:50px"><td>Feedback Link : <td/><td>' . $row['feedback_link'] . '</td></tr>';
						  echo '<tr style="height:50px"><td>Staff Details : <td/><td>' . $row['staff_details'] . '</td></tr>';
						  echo '<tr style="height:50px"><td>Event Details  : <td/><td>' . $row['event_details'] . '</td></tr>';
						  echo '<tr style="height:50px"><td>Invitations  : <td/><td> <a href="../webinar/files/invitations/'.$row['invitation_brochure'].'" target="_blank" download> Download Invitation </a></td></tr>';
					                      
						  echo "  </div> </table>";
						  */
						  ?>
						  <div class="form-validation">
								<form method="POST" action="#" id="add_webinar" name="add_webinar" enctype="multipart/form-data">
									<input type="hidden" name="webinar_id" value="<?php echo $row['id'];  ?>"/>
									<input type="hidden" name="invitation_brochure_old" value="<?php echo $row['invitation_brochure'];  ?>"/>
									<input type="hidden" name="staff_photo_old" value="<?php echo $row['staff_photo'];  ?>"/>
									<input type="hidden" name="banner_image_old" value="<?php echo $row['banner_image'];  ?>"/>
									<div class="row">
										<div class="col-md-12">
											<div class="form-group row">
												<label class="col-md-12 col-form-label" for="val-category">Category of Event   <span class="text-danger">*</span></label>
												<div class="col-md-9">
													<input type="text" class="form-control validate" id="category_of_event" name="category_of_event" value="<?php echo $row['category_of_event']; ?>" placeholder="Enter a Category of Event.." required>
												</div>
											</div>
										</div>
										<div class="col-md-12">
											<div class="form-group row">
												<label class="col-md-12 col-form-label" for="val-event-name">Title of the Event <span class="text-danger">*</span></label>
												<div class="col-md-9">
													<input type="text" class="form-control validate" id="title" name="title" value="<?php echo $row['title']; ?>" placeholder="Enter a Title.." required>
												</div>
											</div>
										</div>
										<div class="col-md-12">
											<div class="form-group row">
												<label class="col-md-12 col-form-label" for="val-date-time">Start Date & Time <span class="text-danger">*</span></label>
												<div class="col-md-9">
												<div class="input-group date" id="id_0">
													<input type="text" class="form-control" name="start_date_time" id="start_date_time" value="<?php echo date("m/d/Y H:i:s A",strtotime($row['start_date_time'])); ?>" placeholder="Start Date and Time Here*">
													<div class="input-group-addon input-group-append">
														<div class="input-group-text">
															<i class="glyphicon glyphicon-calendar fa fa-calendar"></i>
														</div>
													</div>
												</div>
													<!-- <input type="text" class="form-control validate" id="start_date_time" name="start_date_time" placeholder="Enter a Date format of : Y-m-d H:i:s" required> -->
												</div>
											</div>
										</div>
										<div class="col-md-12">
											<div class="form-group row">
												<label class="col-md-12 col-form-label" for="val-date-time">End Date & Time <span class="text-danger">*</span></label>
												<div class="col-md-9">
												<div class="input-group date" id="id_1">
													<input type="text" class="form-control" name="end_date_time" id="end_date_time" value="<?php echo date("m/d/Y H:i:s A",strtotime($row['end_date_time'])); ?>" placeholder="End Date and Time Here*">
													<div class="input-group-addon input-group-append">
														<div class="input-group-text">
															<i class="glyphicon glyphicon-calendar fa fa-calendar"></i>
														</div>
													</div>
												</div>
													<!-- <input type="text" class="form-control validate" id="start_date_time" name="start_date_time" placeholder="Enter a Date format of : Y-m-d H:i:s" required> -->
												</div>
											</div>
										</div>
										<div class="col-md-12">
											<div class="form-group row">
												<label class="col-md-12 col-form-label" for="val-event-org">Event Organizer<span class="text-danger">*</span></label>
												<div class="col-md-9">
													<input type="text" class="form-control validate" id="event_organizer" name="event_organizer" value="<?php echo $row['event_organizer']; ?>" placeholder="Enter Event Organizer" required>
												</div>
											</div>
										</div>
										<div class="col-md-12">
											<div class="form-group row">
												<label class="col-md-12 col-form-label" for="val-reg-link">Registration Link<span class="text-danger">*</span></label>
												<div class="col-md-9">
													<input type="text" class="form-control validate" id="registration_link" name="registration_link"  value="<?php echo $row['registration_link']; ?>" placeholder="Enter a Registration Link" required>
												</div>
											</div>
										</div>
										<div class="col-md-12">
											<div class="form-group row">
												<label class="col-md-12 col-form-label" for="val-online-event">Link for Join the Online event  <span class="text-danger">*</span></label>
												<div class="col-md-9">
													<input type="text" class="form-control validate" id="join_event_link" name="join_event_link" value="<?php echo $row['join_event_link']; ?>" placeholder="Enter Join Event Link.." required>
												</div>
											</div>
										</div>
										<div class="col-md-12">
											<div class="form-group row">
												<label class="col-md-12 col-form-label" for="val-video-link">Recorded Video Link <span class="text-danger">*</span></label>
												<div class="col-md-9">
													<input type="text" class="form-control validate" id="video_link" name="video_link" value="<?php echo $row['video_link']; ?>" placeholder="Enter a video link" required>
												</div>
											</div>
										</div>
										<div class="col-md-12">
											<div class="form-group row">
												<label class="col-md-12 col-form-label" for="val-feedback">Feedback Form Link <span class="text-danger">*</span></label>
												<div class="col-md-9">
													<input type="text" class="form-control validate" id="feedback_link" name="feedback_link" value="<?php echo $row['feedback_link']; ?>" placeholder="Enter Feedback Form Link" required>
												</div>
											</div>
										</div>
										<div class="col-md-12">
											<div class="form-group row">
												<label class="col-md-12 col-form-label" for="val-feedback">Staff/Speaker Name <span class="text-danger">*</span></label>
												<div class="col-md-9">
													<input type="text" class="form-control validate" id="staff_name" name="staff_name" value="<?php echo $row['staff_name']; ?>" placeholder="Enter Staff Name" required>
												</div>
											</div>
										</div>
										
										
										<div class="col-md-12">
											<div class="form-group row ">
												<label class="col-md-12 col-form-label" for="val-staff-details"> Details of Staff/Speaker  <span class="text-danger">*</span></label>
												<div class="col-md-9">
													<textarea type="text" class="form-control" rows="5" id="staff_details" name="staff_details" placeholder="Staff Details " required><?php echo $row['staff_details']; ?></textarea>
												</div>
											</div>
										</div>
										<div class="col-md-12">
											<div class="form-group row ">
												<label class="col-md-12 col-form-label" for="val-about-event"> About this event  <span class="text-danger">*</span></label>
												<div class="col-md-9">
													<textarea type="text" class="form-control" rows="5" id="event_details" name="event_details" placeholder="About this event " required><?php echo $row['event_details']; ?></textarea>
												</div>
											</div>
										</div>
										
										<div class="col-md-12">
											<div class="form-group row">
												<label class="col-md-12 col-form-label" for="val-feedback">Event Organizer Name <span class="text-danger">*</span></label>
												<div class="col-md-9">
													<input type="text" class="form-control validate" id="organizer_name" name="organizer_name" value="<?php echo $row['organizer_name']; ?>" placeholder="Enter organizer name" required>
												</div>
											</div>
										</div>
										
										<div class="col-md-12">
											<div class="form-group row">
												<label class="col-md-12 col-form-label" for="val-feedback">Event Organizer Mobile <span class="text-danger">*</span></label>
												<div class="col-md-9">
													<input type="text" class="form-control validate" id="staff_phone" name="staff_phone" value="<?php echo $row['staff_phone']; ?>" placeholder="Enter Staff Mobile number" required>
												</div>
											</div>
										</div>
										<div class="col-md-12">
											<div class="form-group row">
												<label class="col-md-12 col-form-label" for="val-feedback">Event Organizer Email <span class="text-danger">*</span></label>
												<div class="col-md-9">
													<input type="email" class="form-control validate" id="staff_email" name="staff_email" value="<?php echo $row['staff_email']; ?>" placeholder="Enter staff email" required>
												</div>
											</div>
										</div>

										<div class="col-md-6">
											<div class="form-group row ">
													<label class="col-md-12 col-form-label" >Upload Invitation/Brochure <span class="text-danger">*</span></label>
													<div class="col-md-9">
														 <input type="file" id="invitation_brochure" name="invitation_brochure" accept="application/pdf">
													</div>
											</div>
										</div>
										
										<div class="col-md-6">
											<div class="form-group row ">
													<label class="col-md-12 col-form-label" >Upload the Photo of Staff/Speaker <span class="text-danger">*</span></label>
													<div class="col-md-9">
														 <input type="file" id="staff_photo" name="staff_photo">
													</div>
											</div>
										</div>
										
										<div class="col-md-6">
											<div class="form-group row ">
													<label class="col-md-12 col-form-label" >Upload banner image <span class="text-danger">*</span></label>
													<div class="col-md-9">
														 <input type="file" id="banner_image" name="banner_image">
													</div>
											</div>
										</div>
								
										<div class="col-md-12">
                                            <div class="form-group row ">
                                                <label class="col-md-12 col-form-label" for="val-email"> &nbsp; </label>
                                                <div class="col-md-9">
                                                    <button type="submit" name="submit" value="Upload" class="btn btn-primary">Update Webinar</button>
                                                </div>
                                            </div>
                                        </div>

									</div>
								</form>
							</div>
						  <?php
					}
					else if(!empty($_GET['delete_webinar']))
					{
						echo "<p><a href='javascript:window.history.back();'> Go Back </a></p>";
						
						$webinar_id=$_GET['delete_webinar'];
						$del_result = mysqli_query($connection,"Delete FROM webinar_info where id='$webinar_id'") or die(mysqli_error());
						if($del_result)
						{
							echo "<script>
								  alert('Webinar Record Deleted Successfully')
								  window.location.href='view_webinar.php'
								  </script>";
						}
					
					}
					else
					{
					  ?>
					  <div class="table-responsive m-t-40">
						<table id="example23" class="display nowrap table table-hover table-striped table-bordered" cellspacing="0" width="100%">
						  <thead>
							<tr>
							  <th>S.no</th>
							  <th>Webinar Title</th> 
							  <th>Category</th>   
							  <th>Webinar Guest</th>
							  <th>Date Of Event </th>
							  <th>Phone Number </th>
							  <th>email</th>
							  <th>Action</th>
							</tr>
						  </thead>
						  <tbody>
							<?php
							$result = mysqli_query($connection,"SELECT * FROM webinar_info ORDER BY added_date DESC") or die(mysqli_error());
							$i = 1;
							while($row = mysqli_fetch_array( $result )) 
							{
								$date = $row['start_date_time'];
								$start_date_time =  date('d-m-Y G:i A',strtotime($date));
							  echo "<tr>";
							  echo '<td>' . $i++ . '</td>';
							  echo '<td>' . $row['title'] . '</td>';
							  echo '<td>' . $row['category_of_event'] . '</td>';
							  echo '<td>' . $row['staff_name'] . '</td>';
							  echo '<td>' . $start_date_time . '</td>';
							  echo '<td>' . $row['staff_phone'] . '</td>';
							  echo '<td>' . $row['staff_email'] . '</td>';                      
							  echo '<td style="width:110px;">
							  <a href="view_webinar.php?videw_webinar='.$row['id'].' ">
							  <i class="fa fa-eye" title="View" style="color:#1c8fb7; font-size:17px;"></i></a>
							  &nbsp;&nbsp;
							  <a href="view_webinar.php?update_webinar='.$row['id'].' "><i class="fa fa-pencil-square-o" 
							  <i class="fa fa-pencil" title="Edit" style="color:green;font-size:17px;"></i></a>
							 
							  &nbsp;&nbsp;
							  <a href="view_webinar.php?delete_webinar='.$row['id'].' "><i class="fa fa-trash" 
							  <i class="fa fa-trash" title="Delete" style="color:red;font-size:17px;"></i></a>
							  &nbsp;&nbsp;
							  </td>'; 
							  echo "</tr>";
							}
							?>
						  </tbody>
						</table>
					  </div>
					  <?php
					}
			  ?>
            </div>
          </div>
        </div>
      </div>
      <!-- End PAge Content -->
    </div>
    <!-- End Container fluid  -->
    <!-- footer -->
	
    <?php include "footer.php"; ?>
	<script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.10.0/jquery.validate.js" type="text/javascript">
	</script>  
	<script type="text/javascript">  
  
				$(document).ready(function () {
					$("#add_webinar").validate({
						rules: {
							status: "required",
							title: "required",
							staff_details: "required",
							file: "required",
						},
						 messages: {
							status: "Please select status from list",
							 title : "Please enter the title",
							staff_details: "Please enter the staff detail",
							file: "Please Upload the pdf file"
						}
					});     
				}); 
			</script>
    <script type="text/javascript">
      $(document).ready( function () {
			$('#example23').DataTable();
		} );
    </script>
	<script type="text/javascript" src="js/moment-with-locales.min.js"></script>
	<script type="text/javascript" src="js/bootstrap-datetimepicker.min.js"></script>
	<script type="text/javascript" src="js/dtpicker.js"></script>