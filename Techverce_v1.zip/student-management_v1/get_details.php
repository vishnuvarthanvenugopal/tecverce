<?php
include 'connect.php';

if(!empty($_GET['state_id'])){

	$state_id=$_GET['state_id'];

	$result = mysqli_query($connection,"SELECT * FROM tbl_cities where state_id='".$state_id."' ORDER BY name ASC") or die(mysqli_error());

	//$row= mysqli_fetch_array($result);

	 while($row = mysqli_fetch_array( $result )) 
                       { 
                       		$data['city'][]=$row;


                       }

                   echo json_encode($data['city']);
}



?>