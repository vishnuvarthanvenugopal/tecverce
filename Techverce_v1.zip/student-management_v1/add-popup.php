<?php
include "header.php";
include "left-menu.php";

$statusMsg = '';

// File upload 
$small_width = 850;
$small_height = 450;
$upload_dir_small = "../gallery/popup/";
$targetDir = "../gallery/";


if(isset($_POST["submit"]) && !empty($_FILES["files"]["name"])) {
	$image_url = $_POST['image_url'];
	$temp = explode(".", $_FILES['files']['name']);
	$fileName = "popup-img".'-'.round(microtime(true)) .'.' . end($temp);
    $targetFilePath = $targetDir.$fileName;
    $fileType = pathinfo($targetFilePath,PATHINFO_EXTENSION);
    // Allow certain file formats
    $allowTypes = array('jpg','png','jpeg','gif','pdf');
    $statusMsg = $successMsg = $errorUpload = $errorUploadType = '';
    if(in_array($fileType, $allowTypes)) {
        // Upload file to server
        if(move_uploaded_file($_FILES["files"]["tmp_name"], $targetFilePath)) {
        	 createThumbnail($fileName, $small_width, $small_height, $targetDir, $upload_dir_small);
            $formData = array(
                'show_in_home'=> 0
            );
            print_r($formData);
            dbRowUpdate('tbl_popup_image', $formData, "");
            // Insert image file name into database
            $insert = $connection->query("INSERT INTO tbl_popup_image(imagePath,image_url,show_in_home, submissionDate) VALUES ('$fileName','$image_url',1, NOW())");
        }
    }
}
$result_aray = selectQryToAray("SELECT * FROM tbl_popup_image ORDER BY imageId ASC");


// Display status message
echo $statusMsg;
$imageId = isset($_GET['imageId']) ? $_GET['imageId'] : '';
if(isset($_GET['action']) == "delete") {
	dbRowDelete('tbl_popup_image', "imageId = '".$imageId."'");
	echo "<script>
	alert('Image is deleted sucessfully!')
	window.location.href='add-popup.php'
	</script>";

}
?>
<div class="page-wrapper">
<div class="row page-titles">
		<div class="col-md-5 align-self-center">
			<h3 class="text-primary">Category</h3> </div>
			<div class="col-md-7 align-self-center">
				<ol class="breadcrumb">
					<li class="breadcrumb-item"><a >Home</a></li>
					<li class="breadcrumb-item active">Dashboard</li>
				</ol>
			</div>
		</div>

		<div class="container-fluid">
			<!-- Start Page Content -->
			<h2 style="text-align: center;">Category</h2>
			<div class="row justify-content-center">
				<div class="col-lg-12">
					<div class="card">
						<div class="card-body">
							<div class="form-validation">
								<form action="#" method="post" enctype="multipart/form-data">
								  <div class="col-md-6">
										<div class="form-group row ">
											<div class="col-md-9">
												<p style="padding-left:15px;"> Image URL <input type="text" name="image_url" id="image_url" style='width:330px;height:30px;' ></p>
												<p> Upload Image<input type="file" name="files" id="files" multiple  accept="image/gif, image/jpeg" required ></p>
												<p style="padding-left:85px;"> <input type="submit" name="submit" value="Save PopUp" class="btn btn-primary"> </p>
											</div>
										</div>
									</div>
								</form>
									<div class="table-responsive m-t-40">
									<form method="POST" action="#" id="add_news" name="edit">
										<h2>Category Lists</h2>
										<table id="myTable" class="display nowrap table table-hover table-striped table-bordered" cellspacing="0" width="100%"> 
											<thead>
												<tr>
													<th>S.no</th>
													<th>Image</th>
													<th>Action</th>
												</tr>
											</thead>
											<tbody>
                                                <?php
                                                $i = 1;
												if(!empty($result_aray))
												{
													foreach ($result_aray as $row) 
													{
														?>
														<tr>
                                                        <td><?php print $i++; ?></td>
                                                        <td><img src="../gallery/popup/<?php print $row['imagePath']; ?>" width="250px" height="250px"></td>
                                                        <td align="center">
                                                           <!--  <a class=" fix-sidebar" href="view-popup-image.php?imageId=<?php print $row['imageId'] ?> ">
                                                                <i class="fa fa-eye" title="View" style="color:blue; font-size:17px;"></i>
                                                            </a> -->
                                                                &nbsp;&nbsp;
                                                            <a class="fix-sidebar" href="popup-image-edit.php?imageId=<?php print $row['imageId'] ?> ">
                                                                <i class="fa fa-pencil" title="Edit" style="color:#1c8fb7;font-size:17px;"></i>
                                                            </a>
                                                            &nbsp;&nbsp;
                                                            <a class="confirmation fix-sidebar" href="?imageId=<?php print $row['imageId'] ?>&action=delete"> 
                                                                <i class="fa fa-trash" style="color:red;" title="delete" aria-hidden="true"></i>
                                                            </a>
                                                            
                                                                </td>
                                                            </tr>
                                                            <?php
                                                    }
												}
                                                        ?>
													</tbody>
												</table>
											</form>

										</div>
							
									</div>
								</div>
							</div>
						</div>
					</div>
					<!-- End PAge Content -->
				</div>
				</div>





    <?php include "footer.php"; ?>