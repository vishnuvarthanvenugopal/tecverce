<?php
include "header.php";
include "left-menu.php";


  if(isset($_POST['submit'])){ 
  
$thumb_width = 100;
$thumb_height = 90;
$upload_dir_thumbs1 = '../images/smallImg/';
$upload_dir_thumbs2 = '../images/mediumImg/';
$upload_dir_thumbs3 = '../images/largeImg/';
$targetDir = "../images/";
$allowTypes = array('jpg','png','jpeg','gif');
    
    $statusMsg = $errorMsg = $insertValuesSQL = $errorUpload = $errorUploadType = '';
    if(!empty(array_filter($_FILES['files']['name']))){
        foreach($_FILES['files']['name'] as $key=>$val){
            // File upload path
            $fileName = basename($_FILES['files']['name'][$key]);
            $targetFilePath = $targetDir.$fileName;
            
            // Check whether file type is valid
            $fileType = pathinfo($targetFilePath,PATHINFO_EXTENSION);
            if(in_array($fileType, $allowTypes)){
                // Upload file to server
                if(move_uploaded_file($_FILES["files"]["tmp_name"][$key], $targetFilePath)){
                	createThumbnail($fileName, $thumb_width, $thumb_height, $targetDir, $upload_dir_thumbs1);
                    // Image db insert sql
                   $last_insert_id = mysqli_insert_id($connection);
                 $formdata = dbRowInsert('tbl_galleries', array(
               
                "catId"=>$last_insert_id,
                "catName"=> $_POST["categoryName"],
                "smallImg"=>$targetFilePath,
                "mediumImg"=>$targetFilePath,
                "largeImg"=> $targetFilePath,
                "createdDate" =>date('Y-m-d H:i:s'), 
                "createdBy" =>$_SESSION['userType']['name'], 
                                                            
            ));
            echo "<script>
				  alert('Images added succefully!')
				  window.location.href='upload-image.php'
				  </script>";
                }
                
                else{
                    $errorUpload .= $_FILES['files']['name'][$key].', ';
                }
            }else{
                $errorUploadType .= $_FILES['files']['name'][$key].', ';
            }
        }
        
        
    }else{
        $statusMsg = 'Please select a file to upload.';
    }
    
    // Display status message
    echo $statusMsg;
}
$id = isset($_GET['id']) ? $_GET['id'] : '';
if(isset($_GET['action']) == "delete") {
    dbRowDelete('tbl_galleries', "id = '".$id."'");
    echo "<script>
          alert('Category is deleted sucessfully!')
          window.location.href='upload-image.php'
          </script>";
        
}
 ?>
<div class="page-wrapper">
	<!-- Bread crumb -->
	<div class="row page-titles">
		<div class="col-md-5 align-self-center">
			<h3 class="text-primary">Category</h3> </div>
			<div class="col-md-7 align-self-center">
				<ol class="breadcrumb">
					<li class="breadcrumb-item"><a >Home</a></li>
					<li class="breadcrumb-item active">Dashboard</li>
				</ol>
			</div>
		</div>
		<!-- End Bread crumb -->
		<!-- Container fluid  -->
		<div class="container-fluid">
			<!-- Start Page Content -->
			<h2 style="text-align: center;">Category</h2>

			<div class="row justify-content-center">
				<div class="col-lg-12">
					<div class="card">
						<div class="card-body">
							<div class="form-validation">

								<form method="post" enctype="multipart/form-data">
										<div class="col-md-6">
                                            <div class="form-group row ">
                                                <label class="col-md-12 col-form-label" for="val-email">Category<span class="text-danger">*</span></label>
                                                <div class="col-md-9">
                                                    <select class="form-control" name="categoryName" id="categoryName">
													<?php 
													$sql = mysqli_query($connection, "SELECT catName FROM tbl_image_category");
													while ($row = $sql->fetch_assoc()){
													echo "<option>" . $row['catName'] . "</option>";
													}
													?>
													</select>
                                                </div>
                                            </div>
                                        </div>
								    <input type="file" name="files[]" multiple >
    								<input type="submit" name="submit" value="UPLOAD">
								</form>
										<div class="table-responsive m-t-40">
									<form method="POST" action="#" id="add_news" name="edit">
										<h2>Category Lists</h2> 

										<table id="example23" class="display nowrap table table-hover table-striped table-bordered" cellspacing="0" width="100%"> 
											<thead>
												<tr>
													<th>S.no</th>
													<th>Category Name</th>
													<th>Small Images</th>
													<th>Medium Images</th>
													<th>Large Images</th>
													<th>Action</th>

												</tr>
											</thead>
											<tbody>
												<?php
												$cat_result_aray = mysqli_query($connection,"SELECT * FROM tbl_galleries ORDER BY id ASC") or die(mysqli_error());
												$i = 1;
												while($row = mysqli_fetch_array( $cat_result_aray )) 
												{
													echo "<tr>";
													echo '<td>' . $i++ . '</td>';
													echo '<td>' . $row['catName'] . '</td>';
													echo '<td>' . $row['smallImg'] . '</td>';
													echo '<td>' . $row['mediumImg'] . '</td>';
													echo '<td>' . $row['largeImg'] . '</td>';
													echo '<td>

													&nbsp;&nbsp;
													<a href="?id='.$row['id'].'&action=delete"> 
													<i class="fa fa-trash" style="color:red;" title="delete" aria-hidden="true"></i>
													</a>
													&nbsp;&nbsp;
													</td>'; 
													echo "</tr>";

												}
												?>

											</tbody>
										</table>
									</form>

								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- End PAge Content -->
		</div>
		<!-- End Container fluid  -->
		<?php include "footer.php"; ?>
		<script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.10.0/jquery.validate.js" type="text/javascript">
		</script>  
		<script type="text/javascript">  

			$(document).ready(function () {
				$("#imageForm").validate({
					rules: {
						categoryName: "required",
						files: "required",
						
						
					},
					messages: {

						categoryName : "Please enter the Category ",
						files: "Please browse the image",
						
						
					},    
					submitHandler: function(form) {
						form.submit();
					}
				});
				
				});
			
		
 
		</script>
		

		<!--======== SCRIPT FILES =========-->
		<script src="js/bootstrap.min.js"></script>
		<script src="js/materialize.min.js"></script>
		<script src="js/custom.js"></script>