<?php
include "header.php";
include "left-menu.php";
$imageId = isset($_GET['imageId']) ? $_GET['imageId'] : '';
$query = "SELECT * FROM tbl_popup_image where imageId='$imageId'";
$result = mysqli_query($connection,$query) or die(mysqli_error());
$row = mysqli_fetch_assoc($result);  
if(isset($_POST["submit"]) ) {
	$formData = array(
		'show_in_home'=> $_POST['show_in_home'],

	);
	dbRowUpdate('tbl_popup_image', $formData, "imageId = '".$imageId."'");
	$success = true;	
} 

$status = "";
if(isset($row['show_in_home'])) {
$status = $row['show_in_home'];
}
?>
<div class="page-wrapper">
	<!-- Bread crumb -->
	<div class="row page-titles">
		<div class="col-md-5 align-self-center">
			<h3 class="text-primary">Category</h3> </div>
			<div class="col-md-7 align-self-center">
				<ol class="breadcrumb">
					<li class="breadcrumb-item"><a >Home</a></li>
					<li class="breadcrumb-item active">Dashboard</li>
				</ol>
			</div>
		</div>
		<!-- End Bread crumb -->
		<!-- Container fluid  -->
		<div class="container-fluid">
			<!-- Start Page Content -->
			<h2 style="text-align: center;">Category</h2>
 <a href="add-popup.php">
         <button type="submit" name="submit" id="submit" class="btn btn-primary">
      <i class="fa fa-check-arrow"></i> BACK</button></a>
			<div class="row justify-content-center">
				<div class="col-lg-12">
					<div class="card">
						<div class="card-body">
							<div class="form-validation">

								<form method="post" name="image_upload" id="image_upload" enctype="multipart/form-data">
									<div class="container">
										<div class="row">
											<div class="col-md-4">
												<div class="form-group row ">
													<label   for="val-email"><b>Popup Image</b></label>
												</div>
											</div>
											
										</div>
										<div class="row">
											<div class="col-md-4">
												<div class="form-group row ">
													<img width=100 height=100 src='../gallery/popup/<?php echo $row['imagePath']; ?>'>
												</div>
											</div>
											

											</div>


										</div>
										<div class="row">
											<div class="col-md-4">
												<div class="form-group row ">
													<label class="form-group">Status: </label>
													<div class="col-md-9">
													<input type="radio" name="show_in_home" <?php echo ($status == "1") ? "checked" : "" ?> value="1">Yes
														<input type="radio" name="show_in_home"  <?php echo ($status == "0") ? "checked" : "" ?> value="0"> No
													</div>
												</div>

											</div>
											
											
											
										</div>
									</div>
									<div class="col-md-12" style="text-align: center;" id="submit-cat" >
										<div class="form-group row">
											<div class="col-lg-12 ml-auto">
												<button type="submit" name="submit" value="submit" class="btn btn-primary">Save Image</button>
											</div>
										</div>
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- End PAge Content -->
		</div>
		<!-- End Container fluid  -->
		<?php include "footer.php"; ?>
		<script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.10.0/jquery.validate.js" type="text/javascript">
		</script>  
		<script type="text/javascript">  

			$(document).ready(function () {
				$("#image_upload").validate({
					rules: {
						categoryName: "required",
						
						files: "required",
					},
					messages: {
						categoryName: "Please select category name from list",

						files: "Please Upload the images"
					},    
					submitHandler: function(form) {
						form.submit();
					}
				});     
			}); 
			


		</script>
		

		<!--======== SCRIPT FILES =========-->
		<script src="js/bootstrap.min.js"></script>
		<script src="js/materialize.min.js"></script>
		<script src="js/custom.js"></script>