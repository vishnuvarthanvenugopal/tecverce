<?php include "header.php";
include "left-menu.php"; ?>
<section id="regnocontainer">
    <div class="container" id="regnocontainer" style="padding-top: 100px;">
        <div class="row">
            <div class="col-md-4"></div>                        
            <div class="col-md-4">
                <div class="form-group">
                    <label for="studentRollnumber">Application / register number *</label>
                    <input type="text" class="form-control" id="studentRollnumber" name="studentRollnumber" required="required" autocomplete="off" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" value="" />
                   <!--  <span style="color: #1c8fb7">For I<sup>st</sup> year students enter application no</span> -->
                 <p><span id="errorMsg" style="color: #ff0000"></span></p>
                </div>
                <button type="submit" class="btn btn-primary pull-left" id="submit" name="submit">Submit</button>
            </div>
        </div>
    </div>
    <div class="container" style="padding-top:800px; padding-bottom: 100px;">
        <div class="row">
            <div class="col-md-4"></div>                        
            <div class="col-md-4">
            </div>
        </div>
    </div>
</section>
<section id="studentDetailSection" style="padding-top: 100px;">   
    <div class="container">
        <div class="row">
         <div class="col-md-12"> 
            <h2 style="text-align: center;padding-left: 200px;">Student Details</h2><br>
        </div>
    <div class="col-md-3">   
    </div>
    <div class="col-md-9">
        <div class="well well-sm">
            <form action="payment-sucess.php" method="POST" name="paymentDetails" id="paymentDetails" >
                <div class="row">
                    <div class="col-md-6">
                            <div class="form-group">
                                <label for="name">Name *</label>
                                <input type="text" class="form-control" id="firstName" name="firstName" required="required" value="" readonly/>
                            </div>
                    </div>
                    <div class="col-md-6">
                            <div class="form-group">
                                <label for="mobile"> Mobile *</label>
                                <input type="text" class="form-control" id="mobile"  name="mobile" required="required" value="" readonly/>
                            </div>  
                    </div>
                    <div class="col-md-6">
                           <div class="form-group">
                            <label for="emailId"> Email *</label>
                            <input type="email" class="form-control" id="emailId" name="emailId" required="required" value="" readonly/>
                        </div>
                    </div>
                    <div class="col-md-6">
                          <div class="form-group">
                            <label for="department"> Department *</label>
                            <input type="text" class="form-control" id="department" name="department" required="required" value="" readonly/>
                         </div>
                    </div>
                <div class="col-md-6">
                   <div class="form-group">
                    <label for="yearOfJoining"> Joining year *</label>
                    <input type="text" class="form-control" id="yearOfJoining" name="yearOfJoining" readonly required="required" value="" />
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label for="registerNumber">
                    Registration / Roll number *</label>
                    <input type="text" class="form-control" id="registerNumber" name="registerNumber" required="required" readonly value="" />
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label for="dateOfBirth">
                    Date of birth *</label>
                    <input type="text" class="form-control" id="dateOfBirth" name="dateOfBirth" readonly required="required" value="" />
                </div>
            </div>            
            <div class="col-md-6">
                <div class="form-group">
                    <label for="tutionfees">Tution fees *</label>
                    <input type="text" class="form-control" id="tutionfees" name="tutionfees" readonly required="required" value="" />
                </div>
            </div>
            <div class="col-md-6" >
                <div class="form-group">
                   <label for="hostelfees" id="fees_id">Fees *</label>
                    <input type="text" class="form-control" id="hostelfees" name="hostelfees" readonly required="required" value="" />
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label for="previoustutionfees">Previous Tution fee Due *</label>
                    <input type="text" class="form-control" id="previoustutionfees" name="previoustutionfees" readonly required="required" value="" />
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label for="previousHostelfees">Previous Hostel/Bus fee Due *</label>
                    <input type="text" class="form-control" id="previousHostelfees" name="previousHostelfees" readonly required="required" value="" />
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label for="payType" id="fees_id">Payment *</label> 
                    <select name="payType" id="payType" class="form-control" required="required">
                        <option value="">-Select payment-</option>
                        <option value="FULL">Full payment</option>
                        <option value="PARTIAL">Partial payment</option>
                    </select>      
                </div>
            </div>
                <div class="col-md-6 partialType">
                     <div class="form-group">
                    <label for="partialhostelFee">Partial tution amount *</label>
                <input type="text" class="form-control partialTxt Number" id="partialTutAmt" name="partialTutAmt" value="" minlength="1" maxlength="6"  />               
                </div>
            </div>
            <div class="col-md-6 partialType">
                <div class="form-group">
                  <label for="partialAmt" id="partialHdsAmtxt">Partial tution amount *</label>
                <input type="text" class="form-control partialTxt Number" id="partialHDsAmt" name="partialHDsAmt" value="" minlength="1" maxlength="6"  />
                </div>
            </div>

            <div class="col-md-6 partialType">
                     <div class="form-group">
                    <label for="partialpreHDsAmt">Partial Previous tution amount *</label>
                <input type="text" class="form-control partialTxt Number" id="partialpreTutAmt" name="partialpreTutAmt" value="" minlength="1" maxlength="6"  />               
                </div>
            </div>
            <div class="col-md-6 partialType">
                <div class="form-group">
                  <label for="partialpreHDsAmt" id="partialHdsAmtxt">Partial Previous hostel amount *</label>
                <input type="text" class="form-control partialTxt Number" id="partialpreHDsAmt" name="partialpreHDsAmt" value="" minlength="1" maxlength="6"  />
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-group">
                   <label for="partialpaidTution">Total amount *</label>
                <input type="text" class="form-control" id="fullAmt" name="fullAmt" value="" readonly   />
                </div>
            </div>
             <div class="col-md-6">
                <div class="form-group">
                    <label for="payment_mode" id="payment_mode">PaymentMode *</label> 
                <select name="payment_mode" id="payment_mode" class="form-control" required="required">
                        <option value="">-Select payment-</option>
                        <option value="CASH">CASH</option>
                        <option value="BANK-DEPOSIT">BANK-DEPOSIT</option>
                    </select>      
                </div>
            </div>
            <div class="col-md-6">
                     <div class="form-group">
                    <label for="bnk_ref_no">BankRefNo*</label>
                <input type="text" class="form-control" id="bnk_ref_no" name="bnk_ref_no" value="" required="required"  />
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                  <label for="pay_date" id="pay_date">PaymentDate *</label>
                <input type="date" class="form-control" id="pay_date" name="pay_date" value="" minlength="1" maxlength="20" required="required"  />
                </div>
            </div>
             <input type="hidden" name="studentType" id="studentType" value="" readonly="readonly" required>            
            <input type="hidden" name="student_id" id="student_id" value="">

              <div class="container-fluid" style="text-align: center;">
               <div class="form-group">
                   <button type="submit" class="btn btn-primary" id="payNow" name="payNow">Update</button>
                   <a href="" class="btn btn-warning" title="Cancel" id="btn-cancel"> Cancel </a>
               </div>
            </div>
        </div>
    </form>
</div>
</div>
<div class="col-md-2">
</div>
</div>
</div>
</section>
<p>&nbsp;</p>
<?php include "footer.php"; ?>
<script type="text/javascript">
$("#studentDetailSection").hide();
$(".partialType").hide();
$('.Number').keypress(function (event) {
    var keycode = event.which;
    if (!(event.shiftKey == false && (keycode == 46 || keycode == 8 || keycode == 37 || keycode == 39 || (keycode >= 48 && keycode <= 57)))) {
        event.preventDefault();
    }
});


$('#payType').change(function() {
    var paymentType = $('#payType').val();   
    if(paymentType == "PARTIAL") {       
       $(".partialType").show();  
    } else {
        $(".partialType").hide();
        /*var tutamt = parseFloat($("#tutionfees").val());
        var hosdys = parseFloat($("#hostelfees").val());*/
        var tutamt = parseFloat($("#tutionfees").val());
        var hosdys = parseFloat($("#hostelfees").val());
        var pretutamt = parseFloat($("#previoustutionfees").val());
        var prehosdys = parseFloat($("#previousHostelfees").val());
        $("#fullAmt").val(parseFloat(tutamt)+parseFloat(hosdys)+parseFloat(pretutamt)+parseFloat(prehosdys));
    }
});

$('#payType').change(function() {
    var tutamt = parseFloat($("#tutionfees").val());
    var hosdys = parseFloat($("#hostelfees").val());
    var pretutamt = parseFloat($("#previoustutionfees").val());
    var prehosdys = parseFloat($("#previousHostelfees").val());
    if(tutamt == 0 ){
        $("#partialTutAmt").prop("readonly", true);
     }
     if(hosdys == 0){
          $("#partialHDsAmt").prop("readonly", true);
     }
     if(pretutamt == 0){
          $("#partialpreTutAmt").prop("readonly", true);
     }
     if(prehosdys == 0){
          $("#partialpreHDsAmt").prop("readonly", true);
     }
});

// $('#payment_mode').change(function() {
//     var paymentmode = $('#payment_mode').val();   
//     if(paymentmode == "CASH") {       
//        $("#bnk_ref_no").hide();
//     }
// });

$(".partialTxt").keyup(function() {
    var tutamt = parseFloat($("#tutionfees").val());
    var hosdys = parseFloat($("#hostelfees").val());
    var pretutamt = parseFloat($("#previoustutionfees").val());
    var prehosdys = parseFloat($("#previousHostelfees").val());
    var partialHDsAmt = $("#partialHDsAmt").val();
    var partialTutAmt = $("#partialTutAmt").val();
    var partialpreTutAmt = $("#partialpreTutAmt").val();
    var partialpreHDsAmt = $("#partialpreHDsAmt").val();
     if (partialTutAmt > tutamt){
    alert("Enter the correct amount");
    }
    if (partialHDsAmt > hosdys){
    alert("Enter the correct amount");
    }
    if (partialpreTutAmt > pretutamt){
    alert("Enter the correct amount");
    }
    if (partialpreHDsAmt > prehosdys){
    alert("Enter the correct amount");
    }
    if(partialTutAmt !="" && partialHDsAmt != "" && partialpreTutAmt != "" && partialpreHDsAmt != "") {
        var fullAmt = parseFloat(partialHDsAmt)+parseFloat(partialTutAmt)+parseFloat(partialpreTutAmt)+parseFloat(partialpreHDsAmt) ;
        $("#fullAmt").val(fullAmt);
    }
});
$('input[name=paymentAmtType]').change(function() {
    var paymentAmtType = $( 'input[name=paymentAmtType]:checked' ).val();    
    if(paymentAmtType == "tution") {
        var tutamt = parseFloat($("#tutionfees").val());
        $("#partialAmt").val(tutamt);
    } else {
        var hosdys = parseFloat($("#hostelfees").val());
        $("#partialAmt").val(hosdys);
    }
});
    $('#submit').click(function(){    
        $.ajax({
            type: "GET",
            // url: "ajax.php?reg="+$("#studentRollnumber").val()+"&action=fetchdetails",
            // success: function(data) {  
             url: "ajax.php?reg="+$("#studentRollnumber").val()+"&action=fetchdetails",
        success: function(data) {       
               var response = JSON.parse(data);
                if(response.status == "error") {
                    $("#errorMsg").text(response.message);
                }
                if(response.status == "success") {
                    $("#regnocontainer").hide();
                    $("#studentDetailSection").show();
                    if(response.studentType == "H") {                        
                        $("#fees_id").text("Hostel fees *");
                        $("#partialHdsAmtxt").text("Partial hostel fees *");
                    } else {                       
                        $("#fees_id").text("Day scholar fees*");
                        $("#partialHdsAmtxt").text("Partial day scholar fees *");
                    }
                    $("#studentType").val(response.studentType);
                    $("#firstName").val(response.firstName);

                    if(response.registerNumber) {
                        $("#registerNumber").val(response.registerNumber);
                    } else {
                        $("#registerNumber").val(response.applicationNumber);
                    }                  
                    $("#dateOfBirth").val(response.dateOfBirth);
                    $("#department").val(response.department);
                    $("#yearOfJoining").val(response.yearOfJoining);
                    $("#emailId").val(response.emailId);
                    $("#mobile").val(response.mobile);
                    $("#student_id").val(response.studentId);
                    
                    
                    var tution_fees;
                    var hos_dys_fees;
                    var pre_tution_fees;
                    var pre_hos_dys_fees;
                    if(response.fees.paid_tution == null) {                        
                        /*tution_fees = parseInt(response.fees.tutionFees);*/
                         tution_fees =(parseInt(response.fees.tutionFees)-parseInt(response.fees.firstGrConcession)-parseInt(response.fees.scTutionFeeConcession));
                         //tution_fees = 1000;
                    } else {
                        tution_fees = (parseInt(response.fees.tutionFees)-parseInt(response.fees.firstGrConcession)-parseInt(response.fees.scTutionFeeConcession))-parseInt(response.fees.paid_tution);
                        //tution_fees = 50;
                    } 

                    if(response.fees.paid_other_fees == null) {                        
                        hos_dys_fees = parseInt(response.fees.hostelFees);
                    } else {
                        hos_dys_fees = (parseInt(response.fees.hostelFees)-parseInt(response.fees.paid_other_fees));
                    }
                    
                    if(response.fees.paid_pre_tution == null) {                        
                        pre_tution_fees = parseInt(response.fees.previoustutionDue);
                    } else {
                        pre_tution_fees = (parseInt(response.fees.previoustutionDue)-parseInt(response.fees.paid_pre_tution));
                    }       
                    
                    if(response.fees.paid_pre_other_fees == null) {                        
                        pre_hos_dys_fees = parseInt(response.fees.previoushostelDue);
                    } else {
                        pre_hos_dys_fees = (parseInt(response.fees.previoushostelDue)-parseInt(response.fees.paid_pre_other_fees));
                    }

                    var befor_txt_tution = (response.fees.paid_tution);
                    var befor_txt_hostel = (response.fees.paid_other_fees);
                    var initial_tution = (response.fees.tutionFees);
                    var initial_hostel = (response.fees.hostelFees);
                    $("#tutionfees").val(tution_fees);
                    $("#hostelfees").val(hos_dys_fees);
                    $("#previoustutionfees").val(pre_tution_fees);
                    $("#previousHostelfees").val(pre_hos_dys_fees);
                    var totaltAmt = parseFloat(tution_fees) + parseFloat(hos_dys_fees) + parseFloat(pre_tution_fees) + parseFloat(pre_hos_dys_fees);
                    if(tution_fees <= 0 && hos_dys_fees <=0 || totaltAmt <= 0) {
                     $("#payNow").hide();
                    }
                 $("#fullAmt").val(totaltAmt);
                    // $("#tutionfees").val(response.fees.tutionFees);
                    // $("#hostelfees").val(response.fees.hostelFees);
                    // var totaltAmt = parseFloat(response.fees.tutionFees) + parseFloat(response.fees.hostelFees);
                    // $("#fullAmt").val(totaltAmt);
                }
            }
        });
    });
</script>

</body>
</html>

