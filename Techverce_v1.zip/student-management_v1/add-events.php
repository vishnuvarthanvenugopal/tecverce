<?php
 include "header.php";
 include "left-menu.php";
 if(isset($_POST["submit"]))
{
    $filename =generateSeoURL($_POST['title']) . ".pdf";  
	$filepath = "../events/";
    $newname = $filepath . $filename;
    $FileType = pathinfo($newname,PATHINFO_EXTENSION);
    if($FileType == "pdf")
    {
        if (move_uploaded_file($_FILES['file']['tmp_name'], $newname))
        {
             $insertdata = dbRowInsert('tbl_news_events', array(
               
                'title'=> $_POST['title'],
                'description'=> $_POST['description'],
                'type'=>'events',
                'status'=> $_POST['status'],
                'createdDate' =>date('Y-m-d H:i:s'), 
                'createdBy' =>$_SESSION['userType']['name'], 
                'link'  => $filename,                                              
            ));
            echo "<script>
				  alert('Events added succefully!')
				  window.location.href='events-lists.php'
				  </script>";
        }
        else
        {
            echo 'failed to upload';
        }
    }
	    else
	    {
	        echo "<p>Files must be uploaded in PDF format.</p>";
	    }

}
?>   
		<div class="page-wrapper">
		<div class="row page-titles">
		<div class="col-md-5 align-self-center">
			<h3 class="text-primary">Add Events</h3> 
		</div>
			<div class="col-md-7 align-self-center">
				<ol class="breadcrumb">
					<li class="breadcrumb-item"><a >Home</a></li>
					<li class="breadcrumb-item active">Dashboard</li>
				</ol>
			</div>
		</div>
	
		<div class="container-fluid">
			<h2 style="text-align: center;">Events</h2>
			<div class="row justify-content-center">
				<div class="col-lg-12">
					<div class="card">
						<div class="card-body">
							<div class="form-validation">
							<form method="POST" action="#" id="add_events" enctype="multipart/form-data">
									<div class="row">
										<div class="col-md-6">
											<div class="form-group row">
												<label class="col-md-12 col-form-label" for="val-username">Title <span class="text-danger">*</span></label>
												<div class="col-md-9">
													<input type="text" class="form-control validate" id="title" name="title" placeholder="Enter a Title.." required>
												</div>
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group row ">
												<label class="col-md-12 col-form-label" for="val-email">Descriptions <span class="text-danger">*</span></label>
												<div class="col-md-9">
													<textarea type="text" class="form-control" id="description" name="description" placeholder="Description" required></textarea>
												</div>
											</div>
										</div>

										<div class="col-md-6">
											<div class="form-group row ">
													<label class="col-md-12 col-form-label" >Upload Documents <span class="text-danger">*</span></label>
													<div class="col-md-9">
														 <input type="file" name="file" accept="application/pdf" >
													</div>
											</div>
										</div>
										
										 <div class="col-md-6">
                                            <div class="form-group row ">
                                                <label class="col-md-12 col-form-label" for="val-email">Status<span class="text-danger">*</span></label>
                                                <div class="col-md-9">
                                                    <select class="form-control" id="status" name="status">
                                                        <option value="">Select</option>
                                                        <option value="ACTIVE">Active</option>
                                                        <option value="INACTIVE">In Active</option>                
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
										<div class="form-group row">
											<div class="col-lg-8 ml-auto">
												 <button type="submit" name="submit" value="Upload" class="btn btn-primary">Add Events</button>
											</div>
										</div>
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

		<!-- End Container fluid  -->
		<?php include "footer.php"; ?>
<script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.10.0/jquery.validate.js" type="text/javascript">
</script>  
		<script type="text/javascript">
			$(document).ready(function () {
				$("#add_events").validate({
					rules: {
						title: "required",
						description: "required",
						status: "required",
						file: "required"
					},

					messages: {
						title: "Please enter the  title",
						description: "Please enter the description",
						status: "Please select status from list",
						file: "Please upload the pdf file for the event"
					},    
					submitHandler: function(form) {
						form.submit();
					}
				});     
			}); 
		</script>
		
		<!--======== SCRIPT FILES =========-->
		<script src="js/bootstrap.min.js"></script>
		<script src="js/materialize.min.js"></script>
		<script src="js/custom.js"></script>