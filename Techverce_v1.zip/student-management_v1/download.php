<?php
include 'connect.php';
$f = fopen('php://memory',"w");

$header = array('Student Name', 'Register No', 'Application No', 'Date Of Birth', 'Student Type', 'Department','Year of Studying', 'Year of joining', 'Email', 'Mobile', 'Address','Locality','Zip code','First Graduation', 'Quota', 'Tution Amount', 'Hostel/Transport Amount', 'Paid Tution Amount', 'Paid Hostel/Transport Amount', 'Balance Tution Amount', 'Balance Hostel/Transport Amount');
fputcsv($f,$header);


$query = "SELECT * FROM student";
$result = mysqli_query($connection,$query) or die(mysqli_error());

while($row = mysqli_fetch_assoc($result)){
    $studentFetch = "SELECT * FROM studentfees where studentId=".$row['studentId'];
    $result2 = mysqli_query($connection,$studentFetch) or die(mysqli_error());
    $row1 = mysqli_fetch_assoc($result2); 

    $payment_result = "SELECT * FROM payment_history where student_id=".$row['studentId'];
    $pay_result = mysqli_query($connection,$payment_result) or die(mysqli_error());

    $paidhostelFees = 0;
    $paidtutionFees = 0;
    while($r = mysqli_fetch_assoc($pay_result)){
        if($r['payment_status'] == 'SUCCESS'){
            $paidhostelFees += ($r['hos_dys_fee'] + $r['pre_hos_dys_fee']);
            $paidtutionFees += ($r['tutition_fee'] + $r['pre_tutition_fee']);
        }
    }

    $data = array($row['firstName'], $row['registerNumber'], $row['applicationNumber'], $row['dateOfBirth'], $row['studentType'], $row['department'],$row['yearOfStudying'], $row['yearOfJoining'], $row['emailId'], $row['mobile'], $row['address'],$row['locality'],$row['zip_code'],$row['first_graduation'], $row['quota'], $row1['tutionFees'], $row1['hostelFees'], $paidtutionFees, $paidhostelFees, ($row1['tutionFees'] - $paidtutionFees), ($row1['hostelFees'] - $paidhostelFees));

    fputcsv($f,$data);
}

fseek($f, 0);
// tell the browser it's going to be a csv file
header('Content-Type: application/csv');
// tell the browser we want to save it instead of displaying it
header('Content-Disposition: attachment; filename="student.csv";');
// make php send the generated csv lines to the browser
fpassthru($f);