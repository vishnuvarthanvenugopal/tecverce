
<?php 
include 'header.php';
include 'left-menu.php';
$id = $_GET['id'];
if(isset($_POST['update'])) {

  $name = filter($_POST['name']);
  $email = filter($_POST['email']);
  $userType = filter($_POST['userType']);
  $status = filter($_POST['status']);           
  $sql = mysqli_query($connection,"UPDATE  admin_login SET name = '".$name."',email = '".$email."',userType = '".$userType."', status = '".$status."' WHERE id = '".$id."'");
  $retval = mysqli_query($connection,$sql); 
  echo "<script>
  alert('Account has been updated!')
  window.location.href='admin.php'
  </script>";
}
$query = "SELECT * FROM admin_login where id='$id'";
$result = mysqli_query($connection,$query) or die(mysqli_error());
$row = mysqli_fetch_assoc($result);  
?>
<!-- End header header -->
<!-- Page wrapper  -->
<div class="page-wrapper">
  <!-- Bread crumb -->
  <div class="row page-titles">
    <div class="col-md-5 align-self-center">
      <h3 class="text-primary">Edit ADMIN</h3> </div>
      <div class="col-md-7 align-self-center">
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a >Home</a></li>
          <li class="breadcrumb-item active">Dashboard</li>
        </ol>
      </div>
    </div>
    <!-- End Bread crumb -->
    <!-- Container fluid  -->
    <div class="container-fluid">
      <!-- Start Page Content -->
      <h2 style="text-align: center;"> EDIT ADMIN</h2>

      <div class="row justify-content-center">
        <div class="col-lg-12">
          <div class="card">
            <div class="card-body">
              <div class="form-validation">
                <form class="form-valide" id="add_usr_frm" method="post">
                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group row">
                        <label class="col-md-12 col-form-label" for="val-username">Username <span class="text-danger">*</span></label>
                        <div class="col-md-9">
                          <input type="text" oninput="this.value = this.value.replace(/[^A-Za-z.]/g, '').replace(/(\..*)\./g, '$1');" class="form-control validate" id="name" name="name" placeholder="Enter a username.." value="<?php echo $row['name']; ?>" >
                        </div>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group row ">
                        <label class="col-md-12 col-form-label" for="val-email">Email <span class="text-danger">*</span></label>
                        <div class="col-md-9">
                          <input type="text" class="form-control" id="email" name="email" placeholder="Your valid email.." value="<?php echo $row['email']; ?>">
                        </div>
                      </div>
                    </div>

                    <!-- <div class="col-md-6">
                      <div class="form-group row ">
                        <label class="col-md-12 col-form-label" >Password <span class="text-danger">*</span></label>
                        <div class="col-md-9">
                          <input type="password" class="form-control" id="password" name="password" placeholder="Password" value="<?php echo $row['password']; ?>">
                        </div>
                      </div>
                    </div> -->
                    <div class="col-md-6">
                      <div class="form-group row ">
                        <label class="col-md-12 col-form-label" >USER TYPE <span class="text-danger">*</span></label>
                        <div class="col-md-9">
                          <select class="form-control" id="userType" name="userType">
                                            <option value="">Select</option>
                                            <option value="SUPERADMIN" <?php echo ($row['userType'] == "SUPERADMIN") ? "selected" : ""; ?>>SUPER ADMIN</option>
                                            <option value="ADMIN" <?php echo ($row['userType'] == "ADMIN") ? "selected" : ""; ?>>ADMIN</option>
                                        </select>
                        </div>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group row ">
                        <label class="col-md-12 col-form-label" for="val-email">STATUS <span class="text-danger">*</span></label>
                        <div class="col-md-9">
                          <select class="form-control" id="status" name="status">
                                            <option value="">Select</option>
                                            <option value="ACTIVE" <?php echo ($row['status'] == "ACTIVE") ? "selected" : ""; ?>>ACTIVE</option>
                                            <option value="INACTIVE" <?php echo ($row['status'] == "INACTIVE") ? "selected" : ""; ?>>INACTIVE</option>
                                        </select>
                        </div>
                      </div>
                    </div>
                    <div class="col-md-6">
                    </div>
                    <div class="col-md-12"> 
                    <div class="form-group row" style="text-align: center;">
                      <div class="col-md-12 ml-auto">
                       <button type="submit" id="update" name="update" class="btn btn-primary">Update</button>
                        <a href="admin.php">
                          <button type="button" name="submit" id="submit" class="btn btn-danger">
                          Close</button></a>
                        </div>
                      </div>
                    </div>
                    </div>
                  </form>
                </div>

              </div>
            </div>
          </div>
        </div>
        <!-- End PAge Content -->
      </div>
      <!-- End Container fluid  -->
      <?php include "footer.php"; ?>
      <!-- Form validation -->

      <script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.10.0/jquery.validate.js" type="text/javascript"></script>
      <script  type="text/javascript">
        $(document).ready(function () {
          $("#add_usr_frm").validate({
            rules: {
              name: "required",
              userType: "required",
              status: "required",
              phone: {
                required:true,
                minlength:10,
                maxlength:10,
                number: true
              },
              email: {
                required: true,
                email: true
              },                      
              password: {
                required:true,
                minlength:6,
                maxlength:15
              },

            },
            messages: {
              name: "Please enter Name",
              userType: "Please select User Type from List",
              status: "Please select User Status from List",
              phone: {
                required:"Enter Mobile number",
                minlength:"10 digits only",
                maxlength:"10 digits only",
                number: "Enter number only!",
              },                      
              email: {
                required:"Please enter email ID",
                email:"Enter a valid email ID",
                remote: "Email already in use!",
              },
              password: {
                required:"Enter correct password",
                minlength:"Please enter 6 digits minimum",
                maxlength:"Please enter 15 digits maximum",

              }, 

            },    
            submitHandler: function(form) {
              form.submit();
            }
          });     
        }); 
      </script>
      <!--======== SCRIPT FILES =========-->
    <!-- <script src="js/bootstrap.min.js"></script>
    <script src="js/materialize.min.js"></script>
    <script src="js/custom.js"></script> -->