
<?php 
include 'header.php';
include 'left-menu.php';
$id = $_GET['id'];
$query = "SELECT * FROM admin_login where id='$id'";
$result = mysqli_query($connection,$query) or die(mysqli_error());
$row = mysqli_fetch_assoc($result);  
?>
<div class="page-wrapper">
  <!-- Bread crumb -->
  <div class="row page-titles">
    <div class="col-md-5 align-self-center">
      <h3 class="text-primary">VIEW ADMIN</h3> </div>
      <div class="col-md-7 align-self-center">
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a >Home</a></li>
          <li class="breadcrumb-item active">Dashboard</li>
        </ol>
      </div>
    </div>
    <!-- End Bread crumb -->
    <!-- Container fluid  -->
    <div class="container-fluid">
      <!-- Start Page Content -->
      <h2 style="text-align: center;">VIEW ADMIN DETAILS</h2>
      <div class="row justify-content-center">
        <div class="col-lg-12">
          <div class="card">
            <div class="card-body">
              <div class="form-validation">
                <form action="" method="POST">
                  <div class="row">
                   <div class="col-md-4">
                   </div>
                   <div class="col-md-6">
                    <div class="form-group row">
                      <label for="name" class="col-md-6" style="color: gray;"> Name</label>
                      <?php echo $row['name']; ?>
                    </div>
                  </div>
                  <div class="col-md-4">
                  </div>
                </div> 
                <div class="row">
                 <div class="col-md-4">
                 </div>
                 <div class="col-md-6">
                  <div class="form-group row">
                    <label for="name" class="col-md-6 col-form-label"  style="color: gray;"> Email</label>
                    <?php echo $row['email']; ?>
                  </div>
                </div>
                <div class="col-md-4">
                </div>
              </div>  
              <div class="row">
               <div class="col-md-4">
               </div>
               <div class="col-md-6">
                <div class="form-group row">
                  <label class="col-md-6 col-form-label" for="val-email">USER TYPE </label>
                  <?php echo $row['userType']; ?>
                </div>
              </div>
              <div class="col-md-4">
              </div>
            </div> 
            <div class="row">
             <div class="col-md-4">
             </div>
             <div class="col-md-6">
              <div class="form-group row">
               <label class="col-md-6 col-form-label" for="val-email">Status</label>
               <?php echo $row['status']; ?>
             </div>
           </div>
           <div class="col-md-4">
           </div>
         </div> 
       <div class="col-md-12">
        <a href="admin.php">
          <p style="text-align: center;"><button type="button" name="submit" id="submit" class="btn btn-danger">
          Close</button></p></a>
        </div>

      </form>
    </div>
  </div>
</div>
</div>
</div>
</div>
</div>


<?php include 'footer.php';?>