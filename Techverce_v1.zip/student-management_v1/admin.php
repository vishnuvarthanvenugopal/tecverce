
<?php include "header.php";
include "left-menu.php";
?>
<!-- Page wrapper  -->
<div class="page-wrapper">
  <!-- Bread crumb -->
  <div class="row page-titles">
    <div class="col-md-5 align-self-center">
     <h3 class="text-primary">AdminDetails</h3> </div>
     <div class="col-md-7 align-self-center">
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
        <li class="breadcrumb-item active">AdminDetails</li>
      </ol>
    </div>
  </div>
  <!-- End Bread crumb -->
  <!-- Container fluid  -->
  <div class="container-fluid">
    <!-- Start Page Content -->
    <div class="row">
      <div class="col-12">
        <div class="card">
          <div class="card-body">
           <h2 style="text-align: center;">Admin</h2>
            <div class="table-responsive m-t-40">
               <table id="myTable" class="display nowrap table table-hover table-striped table-bordered" cellspacing="0" width="100%">
              <!-- <table id="example" class="display nowrap table table-hover table-striped table-bordered" cellspacing="0" width="100%"> -->
                <thead>
                  <tr>
                    <th>S.no</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>User Type</th>
                    <th>Status</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                 <?php
                 $result = mysqli_query($connection,"SELECT * FROM admin_login ORDER BY id DESC") or die(mysqli_error());
                 $i = 1;
                 while($row = mysqli_fetch_array( $result )) 
                 {
                  echo "<tr>";
                  echo '<td>' . $i++ . '</td>';
                  echo '<td>' . $row['name'] . '</td>';
                  echo '<td>' . $row['email'] . '</td>';
                  echo '<td>' . $row['userType'] . '</td>';
                  echo '<td>' . $row['status'] . '</td>';                                
                  echo '                        <td>
                  <a href="admin-details.php?id='.$row['id'].' ">
                  <i class="fa fa-eye" title="View" style="color:#1c8fb7; font-size:17px;"></i></a>
                  &nbsp;&nbsp;
                  <a href="edit-admin.php?id='.$row['id'].' "><i class="fa fa-pencil-square-o" 
                  <i class="fa fa-pencil" title="Edit" style="color:green;font-size:17px;"></i></a>
                  &nbsp;&nbsp;
                  </td>'; 
                  echo "</tr>";
                }
                ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- End PAge Content -->
</div>
<!-- End Container fluid  -->
<!-- footer -->
<?php include "footer.php"; ?>
<script>
$(document).ready( function () {

    $('#example23').DataTable();
     dom: 'Bfrtip',
  buttons: [{
    extend: "excel",
    className: "btn-sm btn-success",
    titleAttr: 'Export in Excel',
    text: 'Excel',
    init: function(api, node, config) {
       $(node).removeClass('btn-default')
    }
  }]
   
} );
</script>