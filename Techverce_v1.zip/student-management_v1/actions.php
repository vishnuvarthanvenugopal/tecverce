<?php
if(isset($_POST['studenteditsubmit']))
{
    $id = $_GET['id'];
    $formData = array(
       'applicationNumber' => $_POST['applicationNumber'],
       'firstName' => $_POST['firstName'],
       "lastName" => $_POST['lastName'],
       "registerNumber" => $_POST['registerNumber'],
       "dateOfBirth" => date("Y-m-d",strtotime($_POST['dateOfBirth'])),
       "department" => $_POST['department'],
       "yearOfStudying" => $_POST['yearOfStudying'],
       "yearOfJoining" => $_POST['yearOfJoining'],
       "emailId" => $_POST['emailId'],
       "mobile" => $_POST['mobile'],
       "quota" => $_POST['quota'],
       "address" => $_POST['address'],
        "address" => $_POST['address'],
            "city" => $_POST['city'],
            "state" => $_POST['state'],
            "locality" => $_POST['locality'],
            "zip_code" => $_POST['zip_code'],
            'first_graduation'=> $_POST['firstgraduation'],

       "studentType" => $_POST['studentType']
   );
    dbRowUpdate('student', $formData, "studentId = '".$id."'") ;
    
    $student_fees_aray = array(
        "tutionFees" => $_POST['tutionFees'],
        "hostelFees" => $_POST['hostelFees'],
        "previoustutionDue" => $_POST['previoustutionDue'],
        "previoushostelDue" => $_POST['previoushostelDue'],
        "firstGrConcession" => $_POST['firstGrConcession'],
        "scTutionFeeConcession" => $_POST['scTutionFeeConcession'],
        "totalFees" => $_POST['totalFees'],
        "totalFeesdue" => $_POST['totalFeesdue'],
        "paymentType" => $_POST['paymentType'],
    );
    dbRowUpdate('studentfees', $student_fees_aray,"studentId = '".$id."'");
    $_SESSION['msg'] = 'Student data updated successfully.';
    $_SESSION['msgclass'] = 'success';
    header('Location:student-details.php');
    exit;
}