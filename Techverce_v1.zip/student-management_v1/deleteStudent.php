<?php
// $connection = mysqli_connect('localhost', 'aihtpayment', 'aihtpayment@123');
$connection = mysqli_connect('localhost', 'root', '');
if (!$connection){
    die("Database Connection Failed" . mysqli_error($connection));
}
$select_db = mysqli_select_db($connection, 'aiht-payment');
if (!$select_db){
    die("Database Selection Failed" . mysqli_error($connection));
}
$id=$_REQUEST['id'];

$select_admin=mysqli_query($connection,"delete from `student` where id='$id'");

if($select_admin)

{

	echo "Record Deleted Successfully";

}

else

{

	echo "Delete Process Failed";

}





?>