<?php include "header.php";
include "left-menu.php";
$query = "SELECT count(studentId) studentId FROM student";
$result = mysqli_query($connection,$query) or die(mysqli_error());
$row = mysqli_fetch_assoc($result);

$query1 = "SELECT count(studentId) studentId FROM studentfees WHERE tutionFeeDue = 0 AND travelHostelDue = 0 ";
$result1 = mysqli_query($connection,$query1) or die(mysqli_error());
$row1 = mysqli_fetch_assoc($result1);

$query2 = "SELECT count(studentId) studentId FROM studentfees WHERE tutionFeeDue > 0 AND travelHostelDue > 0 ";
$result2 = mysqli_query($connection,$query2) or die(mysqli_error());
$row2 = mysqli_fetch_assoc($result2);

$query3 = "SELECT SUM(tutionFeeDue+travelHostelDue+pretutionFeeDue+pretravelHostelDue) totalamountpending FROM studentfees WHERE tutionFeeDue > 0 AND travelHostelDue > 0 ";
$result3 = mysqli_query($connection,$query3) or die(mysqli_error());
$row3 = mysqli_fetch_assoc($result3);
$totalpendingamount=($row3['totalamountpending'] > 0)? $row3['totalamountpending'] : 0;

$result4 = mysqli_query($connection,"SELECT COUNT(student.studentId) totalstudent,student.department,SUM(studentfees.finaltutionfee)+SUM(studentfees.finalhostelfee) totalamount,SUM(studentfees.tutionFeeDue)+
    SUM(studentfees.travelHostelDue) paidamount, SUM(studentfees.pretutionFeeDue)+
    SUM(studentfees.pretravelHostelDue) paidpreamt
          FROM student 
          INNER JOIN studentfees ON student.studentId = studentfees.studentId WHERE student.department = 'MECH' ") or die(mysqli_error()); 
$row4 = mysqli_fetch_assoc($result4);
$totalamt4=$row4['paidamount']+$row4['paidpreamt'];
$sub4 = $row4['totalamount']-($row4['paidamount']+$row4['paidpreamt']);
//$sub4 = $row4['totalamount']-$row4['paidamount'];
// $mechperc1= (($sub4 /$row4['totalamount'])*100);
// $mechperc = ($mechperc1 >0) ? $mechperc1 : 0;

if($sub4 !=0 && $row4 !=0){
$mechperc1= (($sub4/$row4['totalamount'])*100);
}
else{
  $mechperc1=0;
}
$mechperc = $mechperc1;

$result5 = mysqli_query($connection,"SELECT COUNT(student.studentId) totalstudent,student.department,SUM(studentfees.finaltutionfee)+SUM(studentfees.finalhostelfee) totalamount,SUM(studentfees.tutionFeeDue)+
    SUM(studentfees.travelHostelDue) paidamount, SUM(studentfees.pretutionFeeDue)+
    SUM(studentfees.pretravelHostelDue) paidpreamt
          FROM student 
          INNER JOIN studentfees ON student.studentId = studentfees.studentId WHERE student.department = 'IT' ") or die(mysqli_error()); 
$row5 = mysqli_fetch_assoc($result5);
$totalamt5=$row5['paidamount']+$row5['paidpreamt'];
$sub5 = $row5['totalamount']-($row5['paidamount']+$row5['paidpreamt']);
//$sub5 = $row5['totalamount']-$row5['paidamount'];
// $itperc1= (($sub5/$row5['totalamount'])*100);
// $itperc = ($itperc1 >0) ? $itperc1 : 0;
if($sub5 !=0 && $row5 !=0){
$itperc1= (($sub5/$row5['totalamount'])*100);
}
else{
  $itperc1=0;
}
$itperc = $itperc1;


$result6 = mysqli_query($connection,"SELECT COUNT(student.studentId) totalstudent,student.department,SUM(studentfees.finaltutionfee)+SUM(studentfees.finalhostelfee) totalamount,SUM(studentfees.tutionFeeDue)+
    SUM(studentfees.travelHostelDue) paidamount, SUM(studentfees.pretutionFeeDue)+
    SUM(studentfees.pretravelHostelDue) paidpreamt
          FROM student 
          INNER JOIN studentfees ON student.studentId = studentfees.studentId WHERE student.department = 'CSE' ") or die(mysqli_error()); 
$row6 = mysqli_fetch_assoc($result6);

$totalamt6=$row6['paidamount']+$row6['paidpreamt'];
$sub6 = $row6['totalamount']-($row6['paidamount']+$row6['paidpreamt']);
//$sub6 = $row6['totalamount']-$row6['paidamount'];
// $cseperc1= (($sub6/$row6['totalamount'])*100);
// $cseperc = ($cseperc1 >0) ? $cseperc1 : 0;

if($sub6 !=0 && $row6 !=0){
$cseperc1= (($sub6/$row6['totalamount'])*100);
}
else{
  $cseperc1=0;
}
$cseperc = $cseperc1;


$result7 = mysqli_query($connection,"SELECT COUNT(student.studentId) totalstudent,student.department,SUM(studentfees.finaltutionfee)+SUM(studentfees.finalhostelfee) totalamount,SUM(studentfees.tutionFeeDue)+
    SUM(studentfees.travelHostelDue) paidamount, SUM(studentfees.pretutionFeeDue)+
    SUM(studentfees.pretravelHostelDue) paidpreamt
          FROM student 
          INNER JOIN studentfees ON student.studentId = studentfees.studentId WHERE student.department = 'ECE' ") or die(mysqli_error()); 
$row7 = mysqli_fetch_assoc($result7);
$totalamt7=$row7['paidamount']+$row7['paidpreamt'];
$sub7 = $row7['totalamount']-($row7['paidamount']+$row7['paidpreamt']);
//$sub7 = $row7['totalamount']-$row7['paidamount'];
// $eceperc1= (($sub7/$row7['totalamount'])*100);
// $eceperc = ($eceperc1 >0) ? $eceperc1 : 0;

if($sub7 !=0 && $row7 !=0){
$eceperc1= (($sub7/$row7['totalamount'])*100);
}
else{
  $eceperc1=0;
}
$eceperc = $eceperc1;

$result8 = mysqli_query($connection,"SELECT COUNT(student.studentId) totalstudent,student.department,SUM(studentfees.finaltutionfee)+SUM(studentfees.finalhostelfee) totalamount,SUM(studentfees.tutionFeeDue)+
    SUM(studentfees.travelHostelDue) paidamount, SUM(studentfees.pretutionFeeDue)+
    SUM(studentfees.pretravelHostelDue) paidpreamt
          FROM student 
          INNER JOIN studentfees ON student.studentId = studentfees.studentId WHERE student.department = 'CIVIL' ") or die(mysqli_error()); 
$row8 = mysqli_fetch_assoc($result8);
$totalamt8=$row8['paidamount']+$row8['paidpreamt'];
$sub8 = $row8['totalamount']-($row8['paidamount']+$row8['paidpreamt']);
//$sub8 = $row8['totalamount']-$row8['paidamount'];
if($sub8 !=0 && $row8 !=0){
$civilperc1= (($sub8/$row8['totalamount'])*100);
}
else{
  $civilperc1=0;
}
$civilperc = $civilperc1;


$result9 = mysqli_query($connection,"SELECT COUNT(student.studentId) totalstudent,student.department,SUM(studentfees.finaltutionfee)+SUM(studentfees.finalhostelfee) totalamount,SUM(studentfees.tutionFeeDue)+
    SUM(studentfees.travelHostelDue) paidamount, SUM(studentfees.pretutionFeeDue)+
    SUM(studentfees.pretravelHostelDue) paidpreamt
          FROM student 
          INNER JOIN studentfees ON student.studentId = studentfees.studentId WHERE student.department = 'EEE' ") or die(mysqli_error()); 
$row9 = mysqli_fetch_assoc($result9);
$totalamt9=$row9['paidamount']+$row9['paidpreamt'];
$sub9 = $row9['totalamount']-($row9['paidamount']+$row9['paidpreamt']);
//$sub9 = $row9['totalamount']-$row9['paidamount'];
// $eeeperc1= (($sub9/$row9['totalamount'])*100);
// $eeeperc = ($eeeperc1 >0) ? $eeeperc1 : 0;
if($sub9 !=0 && $row9 !=0){
$eeeperc1= (($sub9/$row9['totalamount'])*100);
}
else{
  $eeeperc1=0;
}
$eeeperc = $eeeperc1;

$result10 = mysqli_query($connection,"SELECT COUNT(student.studentId) totalstudent,student.department,SUM(studentfees.finaltutionfee)+SUM(studentfees.finalhostelfee) totalamount,SUM(studentfees.tutionFeeDue)+
    SUM(studentfees.travelHostelDue) paidamount, SUM(studentfees.pretutionFeeDue)+
    SUM(studentfees.pretravelHostelDue) paidpreamt
          FROM student 
          INNER JOIN studentfees ON student.studentId = studentfees.studentId WHERE student.department = 'E&I' ") or die(mysqli_error()); 
$row10 = mysqli_fetch_assoc($result10);
$totalamt10=$row10['paidamount']+$row10['paidpreamt'];
$sub10 = $row10['totalamount']-($row10['paidamount']+$row10['paidpreamt']);
//$sub10 = $row10['totalamount']-$row10['paidamount'];
// $eiperc1= (($sub10/$row10['totalamount'])*100);
// $eiperc = ($eiperc1 >0) ? $eiperc1 : 0;

if($sub10 !=0 && $row10 !=0){
$eiperc1= (($sub10/$row10['totalamount'])*100);
}
else{
  $eiperc1=0;
}
$eiperc = $eiperc1;



$result11 = mysqli_query($connection,"SELECT COUNT(student.studentId) totalstudent,student.department,SUM(studentfees.finaltutionfee)+SUM(studentfees.finalhostelfee) totalamount,SUM(studentfees.tutionFeeDue)+
    SUM(studentfees.travelHostelDue) paidamount, SUM(studentfees.pretutionFeeDue)+
    SUM(studentfees.pretravelHostelDue) paidpreamt
          FROM student 
          INNER JOIN studentfees ON student.studentId = studentfees.studentId WHERE student.department = 'MBA' ") or die(mysqli_error()); 
$row11 = mysqli_fetch_assoc($result11);
$totalamt11=$row11['paidamount']+$row11['paidpreamt'];
$sub11 = $row11['totalamount']-($row11['paidamount']+$row11['paidpreamt']);
//$sub11 = $row11['totalamount']-$row11['paidamount'];
// $mbaperc1= (($sub11/$row11['totalamount'])*100);
// $mbaperc = ($mbaperc1 >0) ? $mbaperc1 : 0;

if($sub11 !=0 && $row11 !=0){
$mbaperc1= (($sub11/$row11['totalamount'])*100);
}
else{
  $mbaperc1=0;
}
$mbaperc = $mbaperc1;


$result12 = mysqli_query($connection,"SELECT COUNT(student.studentId) totalstudent,student.department,SUM(studentfees.finaltutionfee)+SUM(studentfees.finalhostelfee) totalamount,SUM(studentfees.tutionFeeDue)+
    SUM(studentfees.travelHostelDue) paidamount, SUM(studentfees.pretutionFeeDue)+
    SUM(studentfees.pretravelHostelDue) paidpreamt
          FROM student 
          INNER JOIN studentfees ON student.studentId = studentfees.studentId WHERE student.department = 'Science and Humanities' ") or die(mysqli_error()); 
$row12 = mysqli_fetch_assoc($result12);
$totalamt12=$row12['paidamount']+$row12['paidpreamt'];
$sub12 = $row12['totalamount']-($row12['paidamount']+$row12['paidpreamt']);
//$sub12 = $row12['totalamount']-$row12['paidamount'];
// $shperc1= (($sub12/$row12['totalamount'])*100);
// $shperc = ($shperc1 >0) ? $shperc1 : 0;

if($sub12 !=0 && $row12 !=0){
$shperc1= (($sub12/$row12['totalamount'])*100);
}
else{
  $shperc1=0;
}
$shperc = $shperc1;


$result13 = mysqli_query($connection,"SELECT COUNT(student.studentId) totalstudent,student.department,SUM(studentfees.finaltutionfee)+SUM(studentfees.finalhostelfee) totalamount,SUM(studentfees.tutionFeeDue)+
    SUM(studentfees.travelHostelDue) paidamount, SUM(studentfees.pretutionFeeDue)+
    SUM(studentfees.pretravelHostelDue) paidpreamt
          FROM student 
          INNER JOIN studentfees ON student.studentId = studentfees.studentId WHERE student.department = 'BARCH' ") or die(mysqli_error()); 
$row13 = mysqli_fetch_assoc($result13);
$totalamt13=$row13['paidamount']+$row13['paidpreamt'];
$sub13 = $row13['totalamount']-($row13['paidamount']+$row13['paidpreamt']);
// $baperc1= (($sub13/$row13['totalamount'])*100);
// $baperc = ($baperc1 >0) ? $baperc1 : 0;

if($sub13 !=0 && $row13 !=0){
$baperc1= (($sub13/$row13['totalamount'])*100);
}
else{
  $baperc1=0;
}
$baperc = $baperc1;



// $mbal = mysqli_query($connection,"SELECT COUNT(student.studentId) totalstudent,student.department,SUM(studentfees.tutionFeeDue)+
//     SUM(studentfees.travelHostelDue) paidamount
//           FROM student 
//           INNER JOIN studentfees ON student.studentId = studentfees.studentId WHERE student.department = 'MECH'  paidamount > 0 ") or die(mysqli_error()); 
// $val = mysqli_fetch_assoc($mbal);
// $sub13 = $row13['totalamount']-$row13['paidamount'];
// $baperc= (($sub13/$row13['totalamount'])*100);

// echo $val['totalstudent'];
/*$mbal = mysqli_query($connection,"SELECT student.studentId , student.firstName , student.lastName ,   payment_history.tutition_fee , payment_history.hos_dys_fee ,payment_history.student_id  FROM student INNER JOIN payment_history ON student.studentId = payment_history.student_id ORDER BY payment_history.id DESC LIMIT 5") or die(mysqli_error()); 
while($row = mysqli_fetch_array($mbal))*/

// $mbal = mysqli_query($connection,"SELECT * FROM payment_history ORDER BY id DESC LIMIT 5") or die(mysqli_error()); 
// while($rows = mysqli_fetch_array($mbal))
// {
    
    /*echo $rows['tutition_fee'] ;
    echo $rows['hos_dys_fee'] ; 
    // echo $row['firstName'] ; 
    // echo  $row['lastName'] ;
    echo  $rows['student_id'] ;
    echo $rows['firstName'] ; */ 


$mbal1 = mysqli_query($connection,"SELECT COUNT(student.studentId) totalstudent,student.department,studentfees.tutionFeeDue tutiondue,
    studentfees.travelHostelDue hostelamount
          FROM student 
          INNER JOIN studentfees ON student.studentId = studentfees.studentId WHERE student.department = 'CIVIL' AND studentfees.tutionFeeDue = 0 AND studentfees.travelHostelDue = 0 ") or die(mysqli_error()); 
$val1 = mysqli_fetch_assoc($mbal1);


$mbal2 = mysqli_query($connection,"SELECT COUNT(student.studentId) totalstudent,student.department,studentfees.tutionFeeDue tutiondue,
    studentfees.travelHostelDue hostelamount
          FROM student 
          INNER JOIN studentfees ON student.studentId = studentfees.studentId WHERE student.department = 'MECH' AND studentfees.tutionFeeDue = 0 AND studentfees.travelHostelDue = 0 ") or die(mysqli_error()); 
$val2 = mysqli_fetch_assoc($mbal2);


$mbal3 = mysqli_query($connection,"SELECT COUNT(student.studentId) totalstudent,student.department,studentfees.tutionFeeDue tutiondue,
    studentfees.travelHostelDue hostelamount
          FROM student 
          INNER JOIN studentfees ON student.studentId = studentfees.studentId WHERE student.department = 'IT' AND studentfees.tutionFeeDue = 0 AND studentfees.travelHostelDue = 0 ") or die(mysqli_error()); 
$val3 = mysqli_fetch_assoc($mbal3);


$mbal4 = mysqli_query($connection,"SELECT COUNT(student.studentId) totalstudent,student.department,studentfees.tutionFeeDue tutiondue,
    studentfees.travelHostelDue hostelamount
          FROM student 
          INNER JOIN studentfees ON student.studentId = studentfees.studentId WHERE student.department = 'CSE' AND studentfees.tutionFeeDue = 0 AND studentfees.travelHostelDue = 0 ") or die(mysqli_error()); 
$val4 = mysqli_fetch_assoc($mbal4);


$mbal5 = mysqli_query($connection,"SELECT COUNT(student.studentId) totalstudent,student.department,studentfees.tutionFeeDue tutiondue,
    studentfees.travelHostelDue hostelamount
          FROM student 
          INNER JOIN studentfees ON student.studentId = studentfees.studentId WHERE student.department = 'ECE' AND studentfees.tutionFeeDue = 0 AND studentfees.travelHostelDue = 0 ") or die(mysqli_error()); 
$val5 = mysqli_fetch_assoc($mbal5);


$mbal6 = mysqli_query($connection,"SELECT COUNT(student.studentId) totalstudent,student.department,studentfees.tutionFeeDue tutiondue,
    studentfees.travelHostelDue hostelamount
          FROM student 
          INNER JOIN studentfees ON student.studentId = studentfees.studentId WHERE student.department = 'E&I' AND studentfees.tutionFeeDue = 0 AND studentfees.travelHostelDue = 0 ") or die(mysqli_error()); 
$val6 = mysqli_fetch_assoc($mbal6);


$mbal7 = mysqli_query($connection,"SELECT COUNT(student.studentId) totalstudent,student.department,studentfees.tutionFeeDue tutiondue,
    studentfees.travelHostelDue hostelamount
          FROM student 
          INNER JOIN studentfees ON student.studentId = studentfees.studentId WHERE student.department = 'EEE' AND studentfees.tutionFeeDue = 0 AND studentfees.travelHostelDue = 0 ") or die(mysqli_error()); 
$val7 = mysqli_fetch_assoc($mbal7);


$mbal8 = mysqli_query($connection,"SELECT COUNT(student.studentId) totalstudent,student.department,studentfees.tutionFeeDue tutiondue,
    studentfees.travelHostelDue hostelamount
          FROM student 
          INNER JOIN studentfees ON student.studentId = studentfees.studentId WHERE student.department = 'MBA' AND studentfees.tutionFeeDue = 0 AND studentfees.travelHostelDue = 0 ") or die(mysqli_error()); 
$val8 = mysqli_fetch_assoc($mbal8);


$mbal9 = mysqli_query($connection,"SELECT COUNT(student.studentId) totalstudent,student.department,studentfees.tutionFeeDue tutiondue,
    studentfees.travelHostelDue hostelamount
          FROM student 
          INNER JOIN studentfees ON student.studentId = studentfees.studentId WHERE student.department = 'Science and Humanities' AND studentfees.tutionFeeDue = 0 AND studentfees.travelHostelDue = 0 ") or die(mysqli_error()); 
$val9 = mysqli_fetch_assoc($mbal9);


$mbal10 = mysqli_query($connection,"SELECT COUNT(student.studentId) totalstudent,student.department,studentfees.tutionFeeDue tutiondue,
    studentfees.travelHostelDue hostelamount
          FROM student 
          INNER JOIN studentfees ON student.studentId = studentfees.studentId WHERE student.department = 'BARCH' AND studentfees.tutionFeeDue = 0 AND studentfees.travelHostelDue = 0 ") or die(mysqli_error()); 
$val10 = mysqli_fetch_assoc($mbal10);



$resultyear1 = mysqli_query($connection,"SELECT COUNT(student.studentId) totalstudent,student.yearOfJoining,SUM(studentfees.finaltutionfee)+SUM(studentfees.finalhostelfee) totalamount,SUM(studentfees.tutionFeeDue)+
    SUM(studentfees.travelHostelDue) paidamount
          FROM student 
          INNER JOIN studentfees ON student.studentId = studentfees.studentId WHERE student.yearOfJoining = '2014' ") or die(mysqli_error()); 
$rowyear1 = mysqli_fetch_assoc($resultyear1);
$subyear1 = $rowyear1['totalamount']-$rowyear1['paidamount'];
//$sum1= (($subyear1/$rowyear1['totalamount'])*100);





$resultyear2 = mysqli_query($connection,"SELECT COUNT(student.studentId) totalstudent,student.yearOfJoining,SUM(studentfees.finaltutionfee)+SUM(studentfees.finalhostelfee) totalamount,SUM(studentfees.tutionFeeDue)+
    SUM(studentfees.travelHostelDue) paidamount
          FROM student 
          INNER JOIN studentfees ON student.studentId = studentfees.studentId WHERE student.yearOfJoining = '2015' ") or die(mysqli_error()); 
$rowyear2 = mysqli_fetch_assoc($resultyear2);
$subyear2 = $rowyear2['totalamount']-$rowyear2['paidamount'];
//$sum2= (($subyear2/$rowyear2['totalamount'])*100);



$resultyear3 = mysqli_query($connection,"SELECT COUNT(student.studentId) totalstudent,student.yearOfJoining,SUM(studentfees.finaltutionfee)+SUM(studentfees.finalhostelfee) totalamount,SUM(studentfees.tutionFeeDue)+
    SUM(studentfees.travelHostelDue) paidamount
          FROM student 
          INNER JOIN studentfees ON student.studentId = studentfees.studentId WHERE student.yearOfJoining = '2016' ") or die(mysqli_error()); 
$rowyear3 = mysqli_fetch_assoc($resultyear3);
$subyear3 = $rowyear3['totalamount']-$rowyear3['paidamount'];
//$sum3= (($subyear3/$rowyear3['totalamount'])*100);
// echo $sum3;
// exit;





$resultyear4 = mysqli_query($connection,"SELECT COUNT(student.studentId) totalstudent,student.yearOfJoining,SUM(studentfees.finaltutionfee)+SUM(studentfees.finalhostelfee) totalamount,SUM(studentfees.tutionFeeDue)+
    SUM(studentfees.travelHostelDue) paidamount
          FROM student 
          INNER JOIN studentfees ON student.studentId = studentfees.studentId WHERE student.yearOfJoining = '2017' ") or die(mysqli_error()); 
$rowyear4 = mysqli_fetch_assoc($resultyear4);
$subyear4 = $rowyear4['totalamount']-$rowyear4['paidamount'];
//$sum4= (($subyear4/$rowyear4['totalamount'])*100);
//echo $sum4;

//exit;



$resultyear5 = mysqli_query($connection,"SELECT COUNT(student.studentId) totalstudent,student.yearOfJoining,SUM(studentfees.finaltutionfee)+SUM(studentfees.finalhostelfee) totalamount,SUM(studentfees.tutionFeeDue)+
    SUM(studentfees.travelHostelDue) paidamount
          FROM student 
          INNER JOIN studentfees ON student.studentId = studentfees.studentId WHERE student.yearOfJoining = '2018' ") or die(mysqli_error()); 
$rowyear5 = mysqli_fetch_assoc($resultyear5);
$subyear5 = $rowyear5['totalamount']-$rowyear5['paidamount'];
//$sum5= (($subyear5/$rowyear5['totalamount'])*100);
// echo $sum5;
// exit;

// echo $sum;
// exit;



























?>
<!-- End Left Sidebar  -->
<!-- Page wrapper  -->
<div class="page-wrapper">
    <!-- Bread crumb -->
    <div class="row page-titles">
        <div class="col-md-5 align-self-center">
            <h3 class="text-primary">Dashboard</h3> </div>
            <div class="col-md-7 align-self-center">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                    <li class="breadcrumb-item active">Dashboard</li>
                </ol>
            </div>
        </div>
        <!-- End Bread crumb -->
        <!-- Container fluid  -->
        <div class="container-fluid">
            <!-- Start Page Content -->
            <div class="row">
                <div class="col-md-3">
                    <div class="card p-30">
                        <div class="media">
                            <div class="media-left meida media-middle">
                                <span><i class="fa fa-usd f-s-40 color-primary"></i></span>
                            </div>
                            <div class="media-body media-text-right">
                                <h5>Total </h5>
                                <h5><?php echo $row['studentId']; ?></h5>
                                <p class="m-b-0">Students</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card p-30">
                        <div class="media">
                            <div class="media-left meida media-middle">
                                <span><i class="fa fa-shopping-cart f-s-40 color-success"></i></span> 
                            </div>
                            <div class="media-body media-text-right">
                                <h5>Fees Paid</h5>
                                <h5><?php echo $row1['studentId']; ?></h5>
                                <p class="m-b-0">Students</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card p-30">
                        <div class="media">
                            <div class="media-left meida media-middle">
                                <span><i class="fa fa-archive f-s-40 color-warning"></i></span>
                            </div>
                            <div class="media-body media-text-right">
                                <h5>Fees Pending</h5>
                                <h5><?php echo $row2['studentId']; ?></h5>
                                <p class="m-b-0">Students</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card p-30">
                        <div class="media">
                            <div class="media-left meida media-middle">
                                <span><i class="fa fa-usd f-s-40 color-primary"></i></span>
                            </div>
                            <div class="media-body media-text-right">
                                <h5>Total Pending Amount </h5>
                                <h5>₹<?php echo $totalpendingamount ;?></h5>
                                <p class="m-b-0">Pending</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row bg-white m-l-0 m-r-0 box-shadow ">

                <!-- column -->
                <div class="col-lg-8">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">Extra Area Chart</h4>
                            <div id="extra-area-chart"></div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="card">
                        <div class="card-body browser">
                            <p class="m-t-30 f-w-600">CIVIL<span class="pull-right"><?php echo round($civilperc,2) ;?>%</span></p>
                            <div class="progress">
                                <div role="progressbar" style="width: <?php echo $civilperc ;?>%; height:8px;" class="progress-bar bg-success wow animated progress-animated"> <span class="sr-only">60% Complete</span> </div>
                            </div>

                            <p class="f-w-600">MECH <span class="pull-right"><?php echo round($mechperc,2) ;?>%</span></p>
                            <div class="progress ">
                                <div role="progressbar" style="width: <?php echo $mechperc ;?>%; height:8px;" class="progress-bar bg-danger wow animated progress-animated"> <span class="sr-only">60% Complete</span> </div>
                            </div>

                            <p class="m-t-30 f-w-600">IT<span class="pull-right"><?php echo round($itperc,2) ;?>%</span></p>
                            <div class="progress">
                                <div role="progressbar" style="width: <?php echo $itperc ;?>%; height:8px;" class="progress-bar bg-info wow animated progress-animated"> <span class="sr-only">60% Complete</span> </div>
                            </div>

                            <p class="m-t-30 f-w-600">CSE<span class="pull-right"><?php echo round($cseperc,2) ;?>%</span></p>
                            <div class="progress">
                                <div role="progressbar" style="width: <?php echo $cseperc ;?>%; height:8px;" class="progress-bar bg-success wow animated progress-animated"> <span class="sr-only">60% Complete</span> </div>
                            </div>

                            <p class="m-t-30 f-w-600">ECE<span class="pull-right"><?php echo round($eceperc,2) ;?>%</span></p>
                            <div class="progress">
                                <div role="progressbar" style="width: <?php echo $eceperc ;?>%; height:8px;" class="progress-bar bg-warning wow animated progress-animated"> <span class="sr-only">60% Complete</span> </div>
                            </div>

                            
                             <p class="m-t-30 f-w-600">EEE<span class="pull-right"><?php echo round($eeeperc,2) ;?>%</span></p>
                            <div class="progress">
                                <div role="progressbar" style="width: <?php echo $eeeperc ;?>%; height:8px;" class="progress-bar bg-success wow animated progress-animated"> <span class="sr-only">60% Complete</span> </div>
                            </div>
                             <p class="m-t-30 f-w-600">E&I<span class="pull-right"><?php echo round( $eiperc,2) ;?>%</span></p>
                            <div class="progress">
                                <div role="progressbar" style="width: <?php echo $eiperc ;?>%; height:8px;" class="progress-bar bg-success wow animated progress-animated"> <span class="sr-only">60% Complete</span> </div>
                            </div>
                             <p class="m-t-30 f-w-600">MBA<span class="pull-right"><?php echo round($mbaperc ,2);?>%</span></p>
                            <div class="progress">
                                <div role="progressbar" style="width: <?php echo $mbaperc ;?>%; height:8px;" class="progress-bar bg-success wow animated progress-animated"> <span class="sr-only">60% Complete</span> </div>
                            </div>
                             <p class="m-t-30 f-w-600">Science and Humanities<span class="pull-right"><?php echo round($shperc,2) ;?>%</span></p>
                            <div class="progress">
                                <div role="progressbar" style="width: <?php echo $shperc ;?>%; height:8px;" class="progress-bar bg-success wow animated progress-animated"> <span class="sr-only">60% Complete</span> </div>
                            </div>
                             <p class="m-t-30 f-w-600">BA<span class="pull-right"><?php echo round($baperc,2) ;?>%</span></p>
                            <div class="progress">
                                <div role="progressbar" style="width: <?php echo $baperc ;?>%; height:8px;" class="progress-bar bg-success wow animated progress-animated"> <span class="sr-only">60% Complete</span> </div>
                            </div>
                        </div>
                    </div>
                </div>
               
            </div>
            <div class="row">
             
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-title">
                        <h4>Department Wise </h4>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table" style="text-align: center;">
                                <thead>
                                    <tr>
                                        <th>S.no</th>
                                        <th>Dept</th>
                                        <th>No Of Students</th>
                                        <th>No Of Students Paid the Fees</th>
                                        <th>No Of Students Fees Pending</th>
                                        <th>Total Amount Pending</th>
                                        
                                    </tr>
                                </thead>
                                <tbody>

                                    <tr>
                                        <td>1</td>
                                        <td>CIVIL</td>
                                        <td><?php echo $row8['totalstudent']; ?></td>
                                        <td><?php echo $val1['totalstudent'];?></td>
                                        <td><?php echo $row8['totalstudent'] -  $val1['totalstudent'];?></td>
                                        <td><?php echo $totalamt8; ?></td>
                                    </tr>
                                    <tr>
                                        <td>2</td>
                                        <td>MECH</td>
                                        <td><?php echo $row4['totalstudent']; ?></td>
                                        <td><?php echo $val2['totalstudent'];?></td>
                                        <td><?php echo $row4['totalstudent'] -  $val2['totalstudent'];?>
                                    </td>
                                        <td><?php echo $totalamt4; ?></td>
                                    </tr>
                                    <tr>
                                        <td>3</td>
                                        <td>IT</td>
                                        <td><?php echo $row5['totalstudent']; ?></td>
                                        <td><?php echo $val3['totalstudent'];?></td>
                                        <td><?php echo $row5['totalstudent'] -  $val3['totalstudent'];?></td>
                                        <td><?php echo $totalamt5; ?></td>
                                    </tr>
                                    <tr>
                                        <td>4</td>
                                        <td>CSE</td>
                                        <td><?php echo $row6['totalstudent']; ?></td>
                                        <td><?php echo $val4['totalstudent'];?></td>
                                        <td><?php echo $row6['totalstudent'] -  $val4['totalstudent'];?></td>
                                        <td><?php echo $totalamt6; ?></td>
                                    </tr>
                                    <tr>
                                        <td>5</td>
                                        <td>ECE</td>
                                        <td><?php echo $row7['totalstudent']; ?></td>
                                        <td><?php echo $val5['totalstudent'];?></td>
                                        <td><?php echo $row7['totalstudent'] -  $val5['totalstudent'];?></td>
                                        <td><?php echo $totalamt7; ?></td>
                                    </tr>
                                    <tr>
                                        <td>6</td>
                                        <td>E&I</td>
                                        <td><?php echo $row10['totalstudent']; ?></td>
                                        <td><?php echo $val6['totalstudent'];?></td>
                                        <td><?php echo $row10['totalstudent'] -  $val6['totalstudent'];?></td>
                                        <td><?php echo $totalamt10; ?></td>
                                    </tr>
                                    <tr>
                                        <td>7</td>
                                        <td>EEE</td>
                                        <td><?php echo $row9['totalstudent']; ?></td>
                                        <td><?php echo $val7['totalstudent'];?></td>
                                    
                                        <td><?php echo $row9['totalstudent'] -  $val7['totalstudent'];?></td>
                                        <td><?php echo $totalamt9; ?></td>
                                    </tr>
                                    <tr>
                                        <td>8</td>
                                        <td>MBA</td>
                                        <td><?php echo $row11['totalstudent']; ?></td>
                                        <td><?php echo $val8['totalstudent'];?></td>
                                        <td><?php echo $row11['totalstudent'] -  $val8['totalstudent'];?></td>
                                        <td><?php echo $totalamt11; ?></td>
                                    </tr>
                                    <tr>
                                        <td>9</td>
                                        <td>S&H</td>
                                        <td><?php echo $row12['totalstudent']; ?></td>
                                        <td><?php echo $val9['totalstudent'];?></td>
                                        <td><?php echo $row12['totalstudent'] -  $val9['totalstudent'];?></td>
                                        <td><?php echo $totalamt12; ?></td>
                                    </tr>
                                    <tr>
                                        <td>10</td>
                                        <td>BA</td>
                                        <td><?php echo $row13['totalstudent']; ?></td>
                                        <td><?php echo $val10['totalstudent'];?></td>
                                        <td><?php echo $row13['totalstudent'] -  $val10['totalstudent'];?></td>
                                        <td><?php echo $totalamt13; ?></td>
                                    </tr>
                                    <tr>
                                      <td colspan="2">Total</td>
                                      <td><?php echo $row['studentId']; ?></td>
                                      <td><?php echo $row1['studentId']; ?></td>
                                      <td><?php echo $row2['studentId']; ?></td>
                                      <td><?php echo $totalpendingamount ;?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
         <div class="col-lg-8">
          <div class="row">
              <div class="col-lg-6">
               <div class="card">
                <div class="card-title">
                 <h4>Recent Paid student</h4>
             </div>
             <div class="recent-comment">
               
<?php
                $mbal = mysqli_query($connection,"SELECT * FROM payment_history ORDER BY id DESC LIMIT 5") or die(mysqli_error()); 
while($rows = mysqli_fetch_array($mbal))
{
    ?>

           <div class="media">
              <div class="media-left">
               <!-- <a href="student-view.php?id=<?php echo $rows['student_id'];?> class="media-object">...</a> -->
           </div>
           <div class="media-body">
               <h4 class="media-heading"><a href="student-view.php?id=<?php echo $rows['student_id'];?>"><?php echo $rows['firstName'];?></h4>
               <p>Tution Fees : <?php echo $rows['tutition_fee'];?>  <br>Hostel Fees :<?php echo $rows['hos_dys_fee'];?><br> payment Mode : <?php echo $rows['payment_mode'];?> </p>
               <p class="comment-date"><?php echo $rows['pay_date'];?></p></a>
           </div>
        </div>
        <?php } ?>

    
</div>
</div>
<!-- /# card -->
</div>
<!-- /# column -->
<div class="col-lg-6">
   <div class="card">
    <div class="card-body">
     <div class="year-calendar"></div>
 </div>
</div>
</div>


</div>
</div>

<div class="col-lg-4">
    <div class="card">
        <div class="card-body">
            <h4 class="card-title">Yearly Wise</h4>
            <div class="card-content">
                <div class="todo-list">
                    <div class="tdl-holder">
                        <div class="tdl-content">
                            <ul>
                                <li>
                                    <!-- <label>
                                       <input type="checkbox"><i class="bg-primary"></i><span>Build an angular app</span>
                                       <a href='#' class="ti-close"></a>
                                   </label> -->
                                   <label>2014 -------- <?php echo $subyear1;?></label>
                               </li>
                               <li>
                                <label> 2015 -------- <?php echo $subyear2;?></label>
                           </li>
                           <li>
                            <label> 2016 -------- <?php echo $subyear3;?></label>
                       </li>
                       <li>
                      
                        <label> 2017 -------- <?php echo $subyear4;?></label>
                   </li>

                   <li>
                    <label> 2018 -------- <?php echo $subyear5;?></label>
               </li>
           </ul>
       </div>
       <!-- <input type="text" class="tdl-new form-control" placeholder="Type here"> -->
   </div>
</div>
</div>
</div>
</div>
</div>

</div>


<!-- End PAge Content -->
</div>
<!-- End Container fluid  -->
<!-- footer -->
<footer class="footer"> © 2018 All rights reserved.by <a href="https://colorlib.com/">AIHT</a></footer>
<!-- End footer -->

<!-- End Wrapper -->
<!-- All Jquery -->
<script src="js/lib/jquery/jquery.min.js"></script>
<!-- Bootstrap tether Core JavaScript -->
<script src="js/lib/bootstrap/js/popper.min.js"></script>
<script src="js/lib/bootstrap/js/bootstrap.min.js"></script>
<!-- slimscrollbar scrollbar JavaScript -->
<script src="js/jquery.slimscroll.js"></script>
<!--Menu sidebar -->
<script src="js/sidebarmenu.js"></script>
<!--stickey kit -->
<script src="js/lib/sticky-kit-master/dist/sticky-kit.min.js"></script>
<!--Custom JavaScript -->


<!-- Amchart -->
<script src="js/lib/morris-chart/raphael-min.js"></script>
<script src="js/lib/morris-chart/morris.js"></script>
<script src="js/lib/morris-chart/dashboard1-init.js"></script>


<script src="js/lib/calendar-2/moment.latest.min.js"></script>
<!-- scripit init-->
<script src="js/lib/calendar-2/semantic.ui.min.js"></script>
<!-- scripit init-->
<script src="js/lib/calendar-2/prism.min.js"></script>
<!-- scripit init-->
<script src="js/lib/calendar-2/pignose.calendar.min.js"></script>
<!-- scripit init-->
<script src="js/lib/calendar-2/pignose.init.js"></script>

<script src="js/lib/owl-carousel/owl.carousel.min.js"></script>
<script src="js/lib/owl-carousel/owl.carousel-init.js"></script>
<script src="js/scripts.js"></script>
<!-- scripit init-->

<script src="js/custom.min.js"></script>

<!-- Global site tag (gtag.js) - Google Analytics -->

</body>


<!-- Mirrored from colorlib.com/polygon/elaadmin/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 25 Jul 2018 07:51:28 GMT -->
</html>