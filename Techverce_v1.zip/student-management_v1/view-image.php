<?php
include "header.php";
include  "left-menu.php";
$id = isset($_GET['id']) ? $_GET['id'] : '';
$query = "SELECT * FROM tbl_galleries where catId='$id'";
$result = mysqli_query($connection,$query);
$row = mysqli_fetch_assoc($result);  
$image = $row ['smallImg'];
if(isset($_POST["submit"]) ) {
	$formData = array('show_in_home'=> 1);
	$uparay = array('show_in_home'=> 0);
	$gallery_id = $_POST['show_in_home'];
	dbRowUpdate('tbl_galleries', $uparay, "catId = '$id'");
	dbRowUpdate('tbl_galleries', $formData, "id = '$gallery_id'");	
	?>
	<script>
        alert('Request has been saved sucessfully!');
        window.location.href='add-image.php';
    </script>
    <?php
}
?>
<div class="page-wrapper">
	<!-- Bread crumb -->
	<div class="row page-titles">
		<div class="col-md-5 align-self-center">
			<h3 class="text-primary">Category</h3> </div>
			<div class="col-md-7 align-self-center">
				<ol class="breadcrumb">
					<li class="breadcrumb-item"><a >Home</a></li>
					<li class="breadcrumb-item active">Dashboard</li>
				</ol>
			</div>
		</div>
		<!-- End Bread crumb -->
		<!-- Container fluid  -->
		<div class="container-fluid">
			<!-- Start Page Content -->
			<h2 style="text-align: center;">Image Gallery</h2>
			<a href="add-image.php">
         <button type="submit" name="submit" id="submit" class="btn btn-primary">
      <i class="fa fa-check-arrow"></i> BACK</button></a>


			<div class="row justify-content-center">
				<div class="col-lg-12">
					<div class="card">
						<div class="card-body">
							<div class="form-validation">

								<form action="#" method="post" name="image_upload" id="image_upload" enctype="multipart/form-data">
									<div calss="col-md-12">
										<div class="row">
									<?php
									$query = "SELECT * FROM tbl_galleries where catId='$id'";
									$result = mysqli_query($connection,$query);

									while($row = mysqli_fetch_array($result,MYSQLI_ASSOC))
									{
									?>
									<div>
									<img src="../gallery/large/<?php print $row['smallImg']; ?>" width="250" height="250">
									<br>
									&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
									<label>Show in Home:</label>
									<input type="radio" name="show_in_home"  value="<?php print $row['id'] ?>" <?php echo ($row['show_in_home'] == 1) ? 'checked' : ''; ?> >
									</div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;									<?php
									}
									if($image =="") {
										echo "<div class=col-md-12 style=text-align:center;>No Image Found</div>";
									}										
												
									?>
									
								</div>
								</div>

										<div class="col-md-12" style="text-align: center;"  >
										<div class="form-group row">
											<div class="col-lg-12 ml-auto">
												<button type="submit" name="submit" value="submit"<?php if ($image ==""){ ?> style="display:none;"  <?php   } ?> class="btn btn-primary">Save</button>
											</div>
										</div>
									</div>						 
								</form>
							</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- End PAge Content -->
		</div>
		<!-- End Container fluid  -->
		<?php include "footer.php"; ?>

 <script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.10.0/jquery.validate.js" type="text/javascript">
		</script>  
		<script type="text/javascript">
		$(document).on("input", ".numeric", function() {
			    this.value = this.value.replace(/\D/g,'');
			});
			$(document).ready(function () {
				$("#image_upload").validate({
					rules: {
						show_in_home: "required",
					},
					 errorPlacement: function(error, element) {
	             		if ( element.is(":radio") ) {
	               
	           				 error.insertAfter( element.parent().parent());
	        				}
       				 else { // This is the default behavior of the script for all fields
           				 error.insertAfter( element );
       					}
    				},
					messages: {
						show_in_home : "Please select image to show ",						
					},    
					submitHandler: function(form) {
						form.submit();
					}
				});
				
				});  
		</script>
 