<?php
 include "header.php";
include "left-menu.php";
?>
<?php

if(function_exists('date_default_timezone_set'))
{
    date_default_timezone_set("Asia/Kolkata");
}

$date = date('YmdHis');
$trans_no = date('mdHis');
$firstName = filter($_POST['firstName']);
$mobile = filter($_POST['mobile']);
$emailId = ("" !== filter($_POST['emailId'])) ? filter($_POST['emailId']) : 'NA'; ;
$regno = filter($_POST['registerNumber']);
$payType = filter($_POST['payType']);
$student_id = filter($_POST['student_id']);
$transaction_no = "ASA".$student_id."d".$trans_no;


if($_POST["studentType"] == "H") {    
    $merchentId = "IBANHOS";
} else {    
    $merchentId = "IBANDYS";
}
$totamt = ($_POST['fullAmt']);

$service_charge = 0;

if($totamt > 2000){
  $service_charge = number_format(($totamt / 100), 2,".","");
  $totamt += $service_charge;
}

$total_records = 0;

if($_SERVER['REQUEST_METHOD'] == "POST" && isset($_POST['payNow'])) {
    
    if($payType == "FULL") {
        $tutionfeesAmt = isset($_POST['tutionfees']) ? $_POST['tutionfees'] : 0;
        $hostelfeesAmt = isset($_POST['hostelfees']) ? $_POST['hostelfees'] : 0;
        $pretutionfeesAmt = isset($_POST['previoustutionfees']) ? $_POST['previoustutionfees'] : 0;
        $prehostelfeesAmt = isset($_POST['previousHostelfees']) ? $_POST['previousHostelfees'] : 0;
    } else {
        $tutionfeesAmt = isset($_POST['partialTutAmt']) ? $_POST['partialTutAmt'] : 0;
        $hostelfeesAmt = isset($_POST['partialHDsAmt']) ? $_POST['partialHDsAmt'] : 0;
        $pretutionfeesAmt = isset($_POST['partialpreTutAmt']) ? $_POST['partialpreTutAmt'] : 0;
        $prehostelfeesAmt = isset($_POST['partialpreHDsAmt']) ? $_POST['partialpreHDsAmt'] : 0;

    }
    
    $formdata = array (
        "serviceCharge" => $service_charge,
        "totalFees" => $totamt,
        "student_id" => $student_id,
        "firstName"=> $firstName,
        "mobile" => $mobile,
        "email" => $emailId,
        "tutition_fee" => $tutionfeesAmt,
        "hos_dys_fee" => $hostelfeesAmt,
        "pre_tutition_fee"=> $pretutionfeesAmt,
        "pre_hos_dys_fee"=> $prehostelfeesAmt,
        "payment_mode" => "ONLINE",
        "payment_status" => "INITIATED"
    );    
    $latest_id = dbRowInsert("payment_history", postDataFilter($formdata));    
    
    $total_records = 0;
    $records = '';

    $totpartuamt = $tutionfeesAmt + $pretutionfeesAmt;

    if($service_charge && $_POST["studentType"] == "H"){
      $totparhosamt = $hostelfeesAmt + $prehostelfeesAmt;
    } else {
      $totparhosamt = $hostelfeesAmt + $prehostelfeesAmt + $service_charge;
    }

    if($totpartuamt){
      $total_records++;
      $records = '<RECORD ID="'.$total_records.'"><MERCID>IBANTFS</MERCID><AMOUNT>'.number_format($totpartuamt, 2,".","").'</AMOUNT><CUSTOMERID>'.$transaction_no.'</CUSTOMERID><ADDITIONALINFO1>'.$mobile.'</ADDITIONALINFO1><ADDITIONALINFO2>'.$emailId.'</ADDITIONALINFO2><ADDITIONALINFO3>'.$firstName.'</ADDITIONALINFO3><ADDITIONALINFO4>'.$regno.'</ADDITIONALINFO4><ADDITIONALINFO5>NA</ADDITIONALINFO5><ADDITIONALINFO6>NA</ADDITIONALINFO6><ADDITIONALINFO7>NA</ADDITIONALINFO7><FILLER1>NA</FILLER1><FILLER2>NA</FILLER2><FILLER3>NA</FILLER3></RECORD>';
    }

    if($totparhosamt){
      $total_records++;
      $records .= '<RECORD ID="'.$total_records.'"><MERCID>'. $merchentId.'</MERCID><AMOUNT>'.number_format($totparhosamt, 2,".","").'</AMOUNT><CUSTOMERID>aiht002'.$transaction_no.'</CUSTOMERID><ADDITIONALINFO1>'.$mobile.'</ADDITIONALINFO1><ADDITIONALINFO2>'.$emailId.'</ADDITIONALINFO2><ADDITIONALINFO3>'.$firstName.'</ADDITIONALINFO3><ADDITIONALINFO4>'.$regno.'</ADDITIONALINFO4><ADDITIONALINFO5>'.$student_id.'</ADDITIONALINFO5><ADDITIONALINFO6>'.$latest_id.'</ADDITIONALINFO6><ADDITIONALINFO7>NA</ADDITIONALINFO7><FILLER1>NA</FILLER1><FILLER2>NA</FILLER2><FILLER3>NA</FILLER3></RECORD>';
    }

    if($service_charge && $_POST["studentType"] == "H"){
      $total_records++;
      $records .= '<RECORD ID="'.$total_records.'"><MERCID>IBANDYS</MERCID><AMOUNT>'.number_format($service_charge, 2,".","").'</AMOUNT><CUSTOMERID>aiht002'.$transaction_no.'</CUSTOMERID><ADDITIONALINFO1>'.$mobile.'</ADDITIONALINFO1><ADDITIONALINFO2>'.$emailId.'</ADDITIONALINFO2><ADDITIONALINFO3>'.$firstName.'</ADDITIONALINFO3><ADDITIONALINFO4>'.$regno.'</ADDITIONALINFO4><ADDITIONALINFO5>'.$student_id.'</ADDITIONALINFO5><ADDITIONALINFO6>'.$latest_id.'</ADDITIONALINFO6><ADDITIONALINFO7>NA</ADDITIONALINFO7><FILLER1>NA</FILLER1><FILLER2>NA</FILLER2><FILLER3>NA</FILLER3></RECORD>';
    }

    $pgcustomerid = 'ASA'.$latest_id.'d'.$trans_no;
    $input_xml = '<TXNDATA><TXNSUMMARY><REQID>PGECOM201</REQID><PGMERCID>IBANANSECM</PGMERCID><RECORDS>'.$total_records.'</RECORDS><PGCUSTOMERID>'.$pgcustomerid.'</PGCUSTOMERID><AMOUNT>'.number_format(($totamt), 2,".","").'</AMOUNT><TXNDATE>'.$date.'</TXNDATE></TXNSUMMARY>'.$records.'</TXNDATA>';
    
    $response_aray = initiatePayment($input_xml);    
    $msg_str = "IBANANSECM|".$pgcustomerid."|NA|".$totamt."|NA|NA|NA|INR|NA|R|ibanatecm|NA|NA|F|".$mobile."|".$emailId."|".$firstName."|".$regno."|".$student_id."|".$latest_id."|NA|https://aiht.ac.in/online-payment/payment-sucess.php";
    $msg = $msg_str."|".makeCheckSum($msg_str); 
    
    //echo '<textarea style="margin-left:250px;" rows="20" cols="100" style="border:none;">'.$response_aray['request_xml'].'</textarea>';
    //echo '<textarea style="margin-left:250px;" rows="20" cols="100" style="border:none;">'.$response_aray['response_xml'].'</textarea>';
    
    updatePaymentLog($response_aray, $latest_id);

    $res = json_decode(json_encode(simplexml_load_string($response_aray['response_xml'])), true);
    
    $statuscode = $res['TXNDATA']['TXNSUMMARY']['STATUSCODE'];
    $statusmsg = $res['TXNDATA']['TXNSUMMARY']['STATUSDESC'];
    ?>

<!DOCTYPE html>
<html lang="en">

<div class="page-wrapper">
  <!-- Bread crumb -->
  <div class="row page-titles">
    <div class="col-md-5 align-self-center">
      <h3 class="text-primary">ASA online payment Response</h3> </div>
      <div class="col-md-7 align-self-center">
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
          <li class="breadcrumb-item active">Students</li>
        </ol>
      </div>
    </div>
    <!-- End Bread crumb -->
    <!-- Container fluid  -->
    <div class="container-fluid">
      <!-- Start Page Content -->
      <?php if($statuscode == 0){?>
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-body">
               <h2 style="text-align: center;">
               Payment Confirmation</h2><br>         
              <div class="table-responsive m-t-40">
               <!--  <table id="example23" class="display nowrap table table-hover table-striped table-bordered" cellspacing="0" width="100%"> -->
              <form name='billdesk' method='post' action='https://pgi.billdesk.com/pgidsk/PGIMerchantPayment'>
    
            <table class="display nowrap table table-hover table-striped table-bordered" cellspacing="0" width="100%">
              <thead>
                <tr>
                  <th>Details</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>Name :</td>
                  <td><?php echo "$firstName"; ?></td>
                </tr>
                <tr>
                  <td>Registration No :</td>
                  <td> <?php echo "$regno"; ?></td>
                </tr>
                <tr>
                  <td>Total Amount :</td>
                  <td> ₹<?php echo $_POST['fullAmt']; ?></td>
                </tr>
                <?php if($service_charge){?>
                  <tr>
                    <td>Service Charge :<em>Note: 1% service tax if more than 2000</em></td>
                    <td> ₹<?php echo $service_charge; ?></td>
                  </tr>
                  <tr>
                    <td>Grand Total Amount :</td>
                    <td> ₹<?php echo "$totamt"; ?></td>
                  </tr>
                <?php }?>
              </tbody>
            </table><br>
           
                         <div class="col-sm-12 text-center">
                             <input type="hidden" name="msg" value='<?=$msg?>'>
                               <button type="submit" class="btn btn-primary" target="_blank" id='button-confirm'/ >Confirm</button>
                             <a href="dashboard.php" class="btn btn-warning" title="Cancel" id="btn-cancel"> Cancel </a>
                         </div>
                      
                 
              </form>
                      </div>
                    </div>
                  </div>
                </div>
          </div>
      <?php } else {?>
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-body">
              
               <div class="col-sm-12 text-center">
             <h2 style="color:#0498c0">OOPS!</h2><br>
             <h4>Something went wrong we could'n process your request.</h4>
             <p>ERROR CODE <?= $statuscode ?></p>
             <p>ERROR MESSAGE <?= $statusmsg ?></p>
             <a href="dashboard.php" class="btn btn-warning" title="Go back to the previous page" id="btn-cancel"> Go Back </a>
         </div>

                <div class="table-responsive m-t-40">
                 <!--  <table id="example23" class="display nowrap table table-hover table-striped table-bordered" cellspacing="0" width="100%"> -->
                </div>
              </div>
            </div>
          </div>
        </div>
      <?php }?>
<?php
} else {
?>
       <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-body">
            
             <div class="col-sm-12 text-center">
           <h2 style="color:#0498c0">OOPS!</h2><br>
           <h4>Something went wrong we could'n process your request.</h4>
           <p>Please go back to the privious page and try again</p>
           <a href="dashboard.php" class="btn btn-warning" title="Go back to the previous page" id="btn-cancel"> Go Back </a>
       </div>

              <div class="table-responsive m-t-40">
               <!--  <table id="example23" class="display nowrap table table-hover table-striped table-bordered" cellspacing="0" width="100%"> -->
              </div>
            </div>
          </div>
        </div>
      </div>

      <?php
}
?>
      <!-- End PAge Content -->
    </div>
    <!-- End Container fluid  -->
    <!-- footer -->
    <?php include "footer.php"; ?>
    <script type="text/javascript">
      $(document).ready( function () {
    $('#example23').DataTable();
} );
    </script>