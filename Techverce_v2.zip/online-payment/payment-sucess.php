<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- Favicon icon -->
    <!-- <link rel="icon" type="image/png" sizes="16x16" href="images/favicon.png"> -->
    <title>AIHT-ONLINE-PAYMENT</title>
    <!-- Bootstrap Core CSS -->
    <link href="css/lib/bootstrap/bootstrap.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="css/lib/calendar2/semantic.ui.min.css" rel="stylesheet">
    <link href="css/lib/calendar2/pignose.calendar.min.css" rel="stylesheet">
    <link href="css/lib/owl.carousel.min.css" rel="stylesheet" />
    <link href="css/lib/owl.theme.default.min.css" rel="stylesheet" />
    <link href="css/helper.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
</head>
<body class="fix-header fix-sidebar">
    <!-- Main wrapper  -->
    <div id="main-wrapper">
        <!-- header header  -->
        <div class="header">
            <nav class="navbar top-navbar navbar-expand-md navbar-light">
                <!-- Logo -->
                <div class="navbar-header">
                    <a class="navbar-brand" href="index.php">
                        <!-- Logo icon -->
                        <b><img src="images/logoo.png" alt="" class="dark-logo" /></b>
                    </a>
                </div>
                <!-- End Logo -->
                <div class="navbar-collapse">
                    <!-- toggle and nav items -->
                    <ul class="navbar-nav mr-auto mt-md-0">
                        
                        <!-- Messages -->
                        <li class="nav-item dropdown mega-dropdown"> <a class="nav-link dropdown-toggle text-muted  " href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fa fa-th-large"></i></a>
                            <div class="dropdown-menu animated zoomIn">
                                <ul class="mega-dropdown-menu row">
                                    <li class="col-lg-3  m-b-30">
                                        <h4 class="m-b-20">CONTACT US</h4>
                                        <!-- Contact -->
                                        <form>
                                            <div class="form-group">
                                                <input type="text" class="form-control" id="exampleInputname1" placeholder="Enter Name"> </div>
                                                <div class="form-group">
                                                    <input type="email" class="form-control" placeholder="Enter email"> </div>
                                                    <div class="form-group">
                                                        <textarea class="form-control" id="exampleTextarea" rows="3" placeholder="Message"></textarea>
                                                    </div>
                                                    <button type="submit" class="btn btn-info">Submit</button>
                                                </form>
                                            </li>
                                        </ul>
                                    </div>
                                </li>
                                <!-- End Messages -->
                            </ul>
                            <!-- User profile and search -->
                            <ul class="navbar-nav my-lg-0">
                                <!-- Profile -->
                                <li class="nav-item dropdown">
                                    <a class="nav-link dropdown-toggle text-muted" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><?php echo $_SESSION['userType']['name']; ?> <span class="glyphicon glyphicon-chevron-down"></span></a>
                                    <div class="dropdown-menu dropdown-menu-right animated zoomIn">
                                        <ul class="dropdown-user">
                                            <li><a href="passwordchange.php"><i class="fa fa-key"></i> Password Change</a></li>
                                            <li><a href="logout.php"><i class="fa fa-power-off"></i> Logout</a></li>
                                        </ul>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </nav>
                </div>
<!-- End header header -->
<?php 
include "left-menu.php";
 include("connection.php");
$msg = $_POST['msg'];
//echo "Before the Response of the message getting:".$msg;exit;

if($msg!='')
{
    $data = explode('|',$msg);    
    $checksum_r = $data['25'];    
    $chk_ky = $data["0"].'|'.$data["1"].'|'.$data["2"].'|'.$data["3"].'|'.$data["4"].'|'.$data["5"].'|'.$data["6"].'|'.$data["7"].'|'.$data["8"].'|'.$data["9"].'|'.$data["10"].'|'.$data["11"].'|'.$data["12"].'|'.$data["13"].'|'.$data["14"].'|'.$data["15"].'|'.$data["16"].'|'.$data["17"].'|'.$data["18"].'|'.$data["19"].'|'.$data["20"].'|'.$data["21"].'|'.$data["22"].'|'.$data["23"].'|'.$data["24"];

    $checksum = makeCheckSum($chk_ky);          
    if($checksum == $checksum_r) {
        //define parameters
        $merchant_id = $data['0'];          //Merchant ID
        $customer_id = $data['1'];          //Customer ID
        $txn_ref_no = $data['2'];           //Transaction reference Number
        $bnk_ref_no = $data['3'];             //Bank Reference Number
        $amt = $data['4'];                    //Amount Paid
        $bank_id=$data['5'];                //Bank ID
        $bank_merchant_id=$data['6'];       //Bank Merchant ID
        $trans_type=$data['7'];             //Bank Merchant ID
        $currency=$data['8'];               //Currency Name
        $ItemCode=$data['9'];               //Currency Name
        $sec_type=$data['10'];              //Security Type
        $sec_id=$data['11'];                //Security ID
        $sec_pass=$data['12'];              //Security Password
        $pay_date=$data['13'];              //Payment Date
        $auth_code=$data['14'];             //Auth Code
        $settle_type=$data['15'];           //Settlement Type
        $mobile1=$data['16'];               //User mobile
        $user_email=$data['17'];            //User Email
        $user_contact=$data['18'];          //User Contact      
        $add_info4=$data['19'];             //Aditional Info4     
        $add_info5=$data['20'];             //Aditional Info5  
        $add_info6=$data['21'];             //Aditional Info6
        $add_info7=$data['22'];             //Aditional Info7  
        $error_status=$data['23'];          //Error status  
        $error_description = $data['24'];     //error description            
        $payment_status = ($auth_code == "0300") ? "SUCCESS" : "FAILURE";
        $updateFormData = array (
            "customer_id" => $customer_id,
            "txn_ref_no" => $txn_ref_no,
            "bnk_ref_no" => $bnk_ref_no,
            "pay_date" => $pay_date,
            "error_status" => $error_status,
            "error_description" => $error_description,
            "response_msg" => $msg,
            "payment_status" => $payment_status
        );
        $update_where = "id='$add_info6'";
        dbRowUpdate("payment_history", postDataFilter($updateFormData), $update_where);       
    }
}
?>

    
<div class="page-wrapper">
  <!-- Bread crumb -->
  <div class="row page-titles">
    <div class="col-md-5 align-self-center">
      <h3 class="text-primary">AIHT online payment Response</h3> </div>
      <div class="col-md-7 align-self-center">
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
          <li class="breadcrumb-item active">Students</li>
        </ol>
      </div>
    </div>
    <!-- End Bread crumb -->
    <!-- Container fluid  -->
    <div class="container-fluid">
      <!-- Start Page Content -->
       <?php 
if($payment_status == 'SUCCESS')
{?>
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-body">
             

               <h2 style="text-align: center;">
               <i class="fa fa-check-circle" style="font-size:40px;color:green"></i>
                <h4 style="color:green;text-align: center;">Thank you!</h4></h2><br>         
              <div class="table-responsive m-t-40">
               <!--  <table id="example23" class="display nowrap table table-hover table-striped table-bordered" cellspacing="0" width="100%"> -->
               <table class="display nowrap table table-hover table-striped table-bordered" cellspacing="0" width="100%">
    <thead>
      <tr>
        <th>Bank Details</th>
        <th>Status</th>
      </tr>
    </thead>
    <tbody>
         <tr class="warning">
        <td>Bank reference no</td>
        <td><?php echo $bnk_ref_no; ?></td>
      </tr>
      <tr class="danger">
        <td>Transaction reference no</td>
        <td><?php echo $bnk_ref_no; ?></td>
      </tr>
      <tr class="info">
        <td>Amount Paid</td>
        <td>₹<?php echo $amt; ?></td>
      </tr>
      <tr class="success">
        <td>Payment status</td>
        <td><?php echo $error_description; ?></td>
      </tr>
    </tbody>
  </table>
              </div>
              <?php 
  $select_invoice=mysqli_query($connection,"SELECT * FROM  `payment_history` ORDER BY `payment_history`.`id` DESC ");
$fetch_invoice=mysqli_fetch_array($select_invoice,MYSQLI_ASSOC);
$printUrl="print-challan.php?id=".$fetch_invoice['id'];                           
  ?>
   <button class="btn btn-primary"><a href="<?php echo $printUrl; ?>" title="Print" /></button>
print</a>
            </div>
          </div>
        </div>
      </div>

<?php
} else {
?>

       <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-body">
             

               <h2 style="text-align: center;"> 
               <i class="fa fa-times-circle" style="font-size:40px;color:red"></i>
                <h4 style="color:red;text-align: center;">Transaction Declined</h4></h2><br>        
              <div class="table-responsive m-t-40">
               <!--  <table id="example23" class="display nowrap table table-hover table-striped table-bordered" cellspacing="0" width="100%"> -->
               <table class="display nowrap table table-hover table-striped table-bordered" cellspacing="0" width="100%">
    <thead>
      <tr>
        <th>Bank Details</th>
        <th>Status</th>
      </tr>
    </thead>
    <tbody>
         <tr class="warning">
        <td>Bank reference no</td>
       
        <td><?php echo $bnk_ref_no; ?></td>
      </tr>
      <tr class="danger">
        <td>Transaction reference no</td>
        
        <td><?php echo $bnk_ref_no; ?></td>
      </tr>
      <tr class="info">
        <td>Amount Paid</td>
      
        <td>₹<?php echo $amt; ?></td>
      </tr>
      <tr class="success">
        <td>Payment status</td>
        
        <td><?php echo $error_description; ?></td>
      </tr>
    </tbody>
  </table>
              </div>
              <?php 
  $select_invoice=mysqli_query($connection,"SELECT * FROM  `payment_history` ORDER BY `payment_history`.`id` DESC ");
$fetch_invoice=mysqli_fetch_array($select_invoice,MYSQLI_ASSOC);
$printUrl="print-challan.php?id=".$fetch_invoice['id'];                           
  ?><br>
  <button class="btn btn-primary"><a href="<?php echo $printUrl; ?>" title="Print" />
print</a></button>
            </div>
          </div>
        </div>
      </div>

      <?php
}
?>
      <!-- End PAge Content -->
    </div>
    <!-- End Container fluid  -->
    <!-- footer -->
    <?php include "footer.php"; ?>