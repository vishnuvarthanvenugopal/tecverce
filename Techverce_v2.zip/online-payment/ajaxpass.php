<?php
include("connect.php");
$cur =$_POST['currentvalue'];
 $reg =$_SESSION['userType']['registerNumber']
 
 
$qry = "SELECT * FROM student WHERE password ='$cur' ";
       $stdqry = mysqli_query($connection,$qry) or die(mysql_error());
        $row = mysqli_fetch_assoc($stdqry);
         $count = mysqli_num_rows($stdqry);
         //alert();
         if($count==0)
         {
         	echo "User current password not Matched ";
         }


?>