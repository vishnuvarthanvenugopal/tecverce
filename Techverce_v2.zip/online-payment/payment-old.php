<?php
 include "header.php";
include "left-menu.php";
?>
<?php
// include("connect.php");

if(function_exists('date_default_timezone_set'))
{
    date_default_timezone_set("Asia/Kolkata");
}

$date = date('YmdHis');
$trans_no = date('mdHis');
$firstName = filter($_POST['firstName']);
$mobile = filter($_POST['mobile']);
$emailId = ("" !== filter($_POST['emailId'])) ? filter($_POST['emailId']) : 'NA'; ;
$regno = filter($_POST['registerNumber']);
$payType = filter($_POST['payType']);
$student_id = filter($_POST['student_id']);
$transaction_no = "AIHT".$student_id."d".$trans_no;


if($_POST["studentType"] == "H") {    
    $merchentId = "IBATHOS";
} else {    
    $merchentId = "IBATDYS";
}
$totamt = ($_POST['fullAmt']);

$total_records = 0;

if($_SERVER['REQUEST_METHOD'] == "POST" && isset($_POST['payNow'])) {
    
    if($payType == "FULL") {
        $tutionfeesAmt = $_POST['tutionfees'];
        $hostelfeesAmt = $_POST['hostelfees'];
        $pretutionfeesAmt = $_POST['previoustutionfees'];
        $prehostelfeesAmt = $_POST['previousHostelfees'];
    } else {
        $tutionfeesAmt = $_POST['partialTutAmt'];
        $hostelfeesAmt = $_POST['partialHDsAmt'];
        $pretutionfeesAmt = $_POST['partialpreTutAmt'];
        $prehostelfeesAmt = $_POST['partialpreHDsAmt'];

    }
    
    $formdata = array (
        "student_id" => $student_id,
        "firstName"=> $firstName,
        "mobile" => $mobile,
        "email" => $emailId,
        "tutition_fee" => $tutionfeesAmt,
        "hos_dys_fee" => $hostelfeesAmt,
        "pre_tutition_fee"=> $pretutionfeesAmt,
        "pre_hos_dys_fee"=> $prehostelfeesAmt,
        "payment_mode" => "ONLINE",
        "payment_status" => "INITIATED"
    );    
    $latest_id = dbRowInsert("payment_history", postDataFilter($formdata));    
    if($payType == "FULL") {
        $partialTutAmt = $_POST['tutionfees'];
        $partialHDsAmt = $_POST['hostelfees'];
        $partialpreTutAmt = $_POST['previoustutionfees'];
        $partialpreHDsAmt = $_POST['previousHostelfees'];

        $partialTutAmt = $partialTutAmt;
        $partialHDsAmt = $partialHDsAmt;
        $pretutionfeesAmt = $partialpreTutAmt;
        $prehostelfeesAmt = $partialpreHDsAmt;

        $tottutionamt = number_format(($partialTutAmt + $pretutionfeesAmt), 2);
        $tothosamt = number_format(($partialHDsAmt + $prehostelfeesAmt), 2);

        $total_records = 2;
        $records = '<RECORD ID="1"><MERCID>IBATTFS</MERCID><AMOUNT>'.$tottutionamt.'</AMOUNT><CUSTOMERID>'.$transaction_no.'</CUSTOMERID><ADDITIONALINFO1>'.$mobile.'</ADDITIONALINFO1><ADDITIONALINFO2>'.$emailId.'</ADDITIONALINFO2><ADDITIONALINFO3>'.$firstName.'</ADDITIONALINFO3><ADDITIONALINFO4>'.$regno.'</ADDITIONALINFO4><ADDITIONALINFO5>'.$student_id.'</ADDITIONALINFO5><ADDITIONALINFO6>'.$latest_id.'</ADDITIONALINFO6><ADDITIONALINFO7>NA</ADDITIONALINFO7><FILLER1>NA</FILLER1><FILLER2>NA</FILLER2><FILLER3>NA</FILLER3></RECORD><RECORD ID="2"><MERCID>'. $merchentId.'</MERCID><AMOUNT>'.$tothosamt.'</AMOUNT><CUSTOMERID>aiht002'.$transaction_no.'</CUSTOMERID><ADDITIONALINFO1>'.$mobile.'</ADDITIONALINFO1><ADDITIONALINFO2>'.$emailId.'</ADDITIONALINFO2><ADDITIONALINFO3>'.$firstName.'</ADDITIONALINFO3><ADDITIONALINFO4>'.$regno.'</ADDITIONALINFO4><ADDITIONALINFO5>'.$student_id.'</ADDITIONALINFO5><ADDITIONALINFO6>'.$latest_id.'</ADDITIONALINFO6><ADDITIONALINFO7>NA</ADDITIONALINFO7><FILLER1>NA</FILLER1><FILLER2>NA</FILLER2><FILLER3>NA</FILLER3></RECORD>';
    } else {
        $partialTutAmt = $_POST['partialTutAmt'];
        $partialHDsAmt = $_POST['partialHDsAmt'];
        $partialpreTutAmt = $_POST['partialpreTutAmt'];
        $partialpreHDsAmt = $_POST['partialpreHDsAmt'];

        if($partialTutAmt != 0 && $partialHDsAmt != 0 && $partialpreTutAmt !=0 && $partialpreHDsAmt !=0 ) {        
            $total_records = 2;
            $partialTutAmt = $partialTutAmt;
            $partialHDsAmt = $partialHDsAmt;
            $partialpreTutAmt = $partialpreTutAmt;
            $partialpreHDsAmt = $partialpreHDsAmt;

            $totpartuamt = number_format(($partialTutAmt + $partialpreTutAmt), 2);
            $totparhosamt = number_format(($partialHDsAmt + $partialpreHDsAmt), 2);
    

            $records = '<RECORD ID="1"><MERCID>IBATTFS</MERCID><AMOUNT>'.$totpartuamt.'</AMOUNT><CUSTOMERID>'.$transaction_no.'</CUSTOMERID><ADDITIONALINFO1>'.$mobile.'</ADDITIONALINFO1><ADDITIONALINFO2>'.$emailId.'</ADDITIONALINFO2><ADDITIONALINFO3>'.$firstName.'</ADDITIONALINFO3><ADDITIONALINFO4>'.$regno.'</ADDITIONALINFO4><ADDITIONALINFO5>NA</ADDITIONALINFO5><ADDITIONALINFO6>NA</ADDITIONALINFO6><ADDITIONALINFO7>NA</ADDITIONALINFO7><FILLER1>NA</FILLER1><FILLER2>NA</FILLER2><FILLER3>NA</FILLER3></RECORD><RECORD ID="2"><MERCID>'. $merchentId.'</MERCID><AMOUNT>'.$totparhosamt.'</AMOUNT><CUSTOMERID>aiht002'.$transaction_no.'</CUSTOMERID><ADDITIONALINFO1>'.$mobile.'</ADDITIONALINFO1><ADDITIONALINFO2>'.$emailId.'</ADDITIONALINFO2><ADDITIONALINFO3>'.$firstName.'</ADDITIONALINFO3><ADDITIONALINFO4>'.$regno.'</ADDITIONALINFO4><ADDITIONALINFO5>'.$student_id.'</ADDITIONALINFO5><ADDITIONALINFO6>'.$latest_id.'</ADDITIONALINFO6><ADDITIONALINFO7>NA</ADDITIONALINFO7><FILLER1>NA</FILLER1><FILLER2>NA</FILLER2><FILLER3>NA</FILLER3></RECORD>';
        }
         elseif($partialTutAmt != 0 && $partialHDsAmt == 0 && $partialpreTutAmt !=0 && $partialpreHDsAmt ==0 ) {

            $partialTutAmt = $partialTutAmt;
            $partialpreTutAmt = $partialpreTutAmt;
            $totpartuamt = number_format(($partialTutAmt + $partialpreTutAmt), 2);
            
            $total_records = 1;
            $records = '<RECORD ID="1"><MERCID>IBATTFS</MERCID><AMOUNT>'.$totpartuamt.'</AMOUNT><CUSTOMERID>'.$transaction_no.'</CUSTOMERID><ADDITIONALINFO1>'.$mobile.'</ADDITIONALINFO1><ADDITIONALINFO2>'.$emailId.'</ADDITIONALINFO2><ADDITIONALINFO3>'.$firstName.'</ADDITIONALINFO3><ADDITIONALINFO4>'.$regno.'</ADDITIONALINFO4><ADDITIONALINFO5>'.$student_id.'</ADDITIONALINFO5><ADDITIONALINFO6>'.$latest_id.'</ADDITIONALINFO6><ADDITIONALINFO7>NA</ADDITIONALINFO7><FILLER1>NA</FILLER1><FILLER2>NA</FILLER2><FILLER3>NA</FILLER3></RECORD>';
        } elseif ($partialTutAmt == 0 && $partialHDsAmt != 0 && $partialpreTutAmt ==0 && $partialpreHDsAmt != 0) {       
            $partialHDsAmt = $partialHDsAmt;
            $partialpreHDsAmt = $partialpreHDsAmt;
            $totparhosamt = number_format(($partialHDsAmt + $partialpreHDsAmt), 2);
            $total_records = 1;
            $records = '<RECORD ID="1"><MERCID>'. $merchentId.'</MERCID><AMOUNT>'.$totparhosamt.'</AMOUNT><CUSTOMERID>'.$transaction_no.'</CUSTOMERID><ADDITIONALINFO1>'.$mobile.'</ADDITIONALINFO1><ADDITIONALINFO2>'.$emailId.'</ADDITIONALINFO2><ADDITIONALINFO3>'.$firstName.'</ADDITIONALINFO3><ADDITIONALINFO4>'.$regno.'</ADDITIONALINFO4><ADDITIONALINFO5>'.$student_id.'</ADDITIONALINFO5><ADDITIONALINFO6>'.$latest_id.'</ADDITIONALINFO6><ADDITIONALINFO7>NA</ADDITIONALINFO7><FILLER1>NA</FILLER1><FILLER2>NA</FILLER2><FILLER3>NA</FILLER3></RECORD>';
        } 
    }
    $pgcustomerid = 'AIHT'.$latest_id.'d'.$trans_no;
    $input_xml = '<TXNDATA><TXNSUMMARY><REQID>PGECOM201</REQID><PGMERCID>IBANATECM</PGMERCID><RECORDS>'.$total_records.'</RECORDS><PGCUSTOMERID>'.$pgcustomerid.'</PGCUSTOMERID><AMOUNT>'.number_format(($totamt), 2).'</AMOUNT><TXNDATE>'.$date.'</TXNDATE></TXNSUMMARY>'.$records.'</TXNDATA>';
    
    $response_aray = initiatePayment($input_xml);    
    $msg_str = "IBANATECM|".$pgcustomerid."|NA|".$totamt."|NA|NA|NA|INR|NA|R|ibanatecm|NA|NA|F|".$mobile."|".$emailId."|".$firstName."|".$regno."|".$student_id."|".$latest_id."|NA|https://aiht.ac.in/online-payment/payment-sucess.php";
    $msg = $msg_str."|".makeCheckSum($msg_str); 
    
    echo '<textarea style="margin-left:250px;" rows="20" cols="100" style="border:none;">'.$response_aray['request'].'</textarea>';
    echo '<textarea style="margin-left:250px;" rows="20" cols="100" style="border:none;">'.$response_aray['response'].'</textarea>';
    
    // printArray($msg);
    // echo "Testing the String msg";
    // print_r($msg);
    
    ?>

<!DOCTYPE html>
<html lang="en">

<div class="page-wrapper">
  <!-- Bread crumb -->
  <div class="row page-titles">
    <div class="col-md-5 align-self-center">
      <h3 class="text-primary">AIHT online payment Response</h3> </div>
      <div class="col-md-7 align-self-center">
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
          <li class="breadcrumb-item active">Students</li>
        </ol>
      </div>
    </div>
    <!-- End Bread crumb -->
    <!-- Container fluid  -->
    <div class="container-fluid">
      <!-- Start Page Content -->
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-body">
               <h2 style="text-align: center;">
               Payment Confirmation</h2><br>         
              <div class="table-responsive m-t-40">
               <!--  <table id="example23" class="display nowrap table table-hover table-striped table-bordered" cellspacing="0" width="100%"> -->
              <form name='billdesk' method='post' action='https://pgi.billdesk.com/pgidsk/PGIMerchantPayment'>
    
            <table class="display nowrap table table-hover table-striped table-bordered" cellspacing="0" width="100%">
    <thead>
      <tr>
        <th>Details</th>
        <th>Status</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>Name :</td>
        <td><?php echo "$firstName"; ?></td>
      </tr>
      <tr>
        <td>Registration No :</td>
        <td> <?php echo "$regno"; ?></td>
      </tr>
      <tr>
        <td>Total Amount :</td>
        <td> ₹<?php echo "$totamt"; ?></td>
      </tr>
    </tbody>
  </table><br>
 
               <div class="col-sm-12 text-center">
                   <input type="hidden" name="msg" value='<?=$msg?>'>
                     <button type="submit" class="btn btn-primary" target="_blank" id='button-confirm'/ >Confirm</button>
                   <a href="https://aiht.ac.in/online-payment/dashboard.php" class="btn btn-warning" title="Cancel" id="btn-cancel"> Cancel </a>
               </div>
            
       
    </form>
            </div>
          </div>
        </div>
      </div>
</div>
<?php
} else {
?>
       <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-body">
            
             <div class="col-sm-12 text-center">
           <h2 style="color:#0498c0">OOPS!</h2><br>
           <h4>Something went wrong we could'n process your request.</h4>
           <p>Please go back to the privious page and try again</p>
           <a href="index.php" class="btn btn-warning" title="Go back to the previous page" id="btn-cancel"> Go Back </a>
       </div>

              <div class="table-responsive m-t-40">
               <!--  <table id="example23" class="display nowrap table table-hover table-striped table-bordered" cellspacing="0" width="100%"> -->
              </div>
            </div>
          </div>
        </div>
      </div>

      <?php
}
?>
      <!-- End PAge Content -->
    </div>
    <!-- End Container fluid  -->
    <!-- footer -->
    <?php include "footer.php"; ?>
    <script type="text/javascript">
      $(document).ready( function () {
    $('#example23').DataTable();
} );
    </script>