<?php include "connect.php"; 
if(isset($_POST['importsubmit'])){
    //validate whether uploaded file is a csv file
    $csvMimes = array('text/x-comma-separated-values', 'text/comma-separated-values', 'application/octet-stream', 'application/vnd.ms-excel', 'application/x-csv', 'text/x-csv', 'text/csv', 'application/csv', 'application/excel', 'application/vnd.msexcel','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    if(!empty($_FILES['file']['name']) && in_array($_FILES['file']['type'],$csvMimes)){
        if(is_uploaded_file($_FILES['file']['tmp_name'])){   
            $csv = array_map("str_getcsv", file($_FILES['file']['tmp_name'],FILE_SKIP_EMPTY_LINES));
            $keys = array_shift($csv);
            foreach ($csv as $i=>$row) {
                $csv[$i] = array_combine($keys, $row);
            }
            $totalrows = count($csv);
            if($totalrows > 0) {
                foreach ($csv as $col => $val) {                    
                    $prevResult = checkStudentExists($val["REGNO"]);
                    if($prevResult == 0 && $val['Name of the Student'] != null) {
                     $date = date("Y-m-d H:i:s",strtotime($val['DOB']));
                     $studentType = $val['H / DS'];
                        $formData = array(
                            'applicationNumber' => $val['Appliction Number'],
                            'firstName' => $val['Name of the Student'],
                            "lastName" => "",
                            "registerNumber" => $val['REGNO'],
                            "dateOfBirth" => $date,//date("Y-m-d",strtotime($val['DOB'])), //$val['DOB'],
                            "department" => $val['Department'],
                            "yearOfStudying" => $val['YEAR'],
                            "yearOfJoining" => $val['YEAR OF JOINING'],
                            "emailId" => $val['e-mail i.d'],
                            "mobile" => $val['Phone Number'],
                            "address" => $val['Address'],
                            "quota" => $val['GQ/ MQ'],
                            "studentType" => $studentType
                        );
                        $last_insert_id = dbRowInsert('student', $formData);

                        $travelHostelDue = ($studentType == "H") ? $val['hostel Due'] : $val['Tra. Due'];

                        $travel_hos_food = ($studentType == "H") ? $val['Hostel Fee'] :$val['Transport & Food / Hostel Fee'];
                        

                        $student_fees_aray = array(
                            "studentId" =>  $last_insert_id,
                            "tutionFees" => $val['Tuition Fees'],
                            // "hostelfees" => $val['Transport & Food / Hostel Fee'],
                            "hostelfees" => $travel_hos_food,
                            "previousDue" => $val['Previous Due'],
                            "firstGrConcession" => $val['I GR Concession'],
                            "scTutionFeeConcession" => $val['SC Tuition Fees Concession'],
                            "totalFees" => $val['Total Fees'],
                            "totalFeesdue" => $val['Total Fees with Previous Dues'],
                            "tutionFeeDue" => $val['Tuition fee Due'],
                            "travelHostelDue" => $travelHostelDue
                        );
                        dbRowInsert('studentfees', $student_fees_aray);
                        if($val['Paid'] != 0){
                            if($val['Pending'] == 0){
                                 $paid_tutition_fee  = $val['Tuition Fees'];
                                 $paid_hostel_fee = $travel_hos_food;
                            }
                            else{
                        $pending_hos_food = ($studentType == "H") ? $val['hostel Due'] :$val['Tra. Due'];
                                $paid_tutition_fee = $val['Tuition Fees'] - $val['Tuition fee Due'];
                                 $paid_hostel_fee = $travel_hos_food - $pending_hos_food ;
                            }
                            $paid_data =  array( 'student_id' => $last_insert_id,
                            'firstName' => $val['Name of the Student'],
                            "mobile" => $val['Phone Number'],
                            "payment_mode" => "CASH",
                            "tutition_fee" =>  $paid_tutition_fee,
                            "hos_dys_fee" => $paid_hostel_fee,
                            "payment_status" => "SUCCESS"
                        );
                            dbRowInsert('payment_history',$paid_data);
                        }
                    }
                }
            }           
            $qstring = '?status=succ';
        } else {
            $qstring = '?status=err';
        }
    } else {
        $qstring = '?status=invalid_file';
    }
}
header("Location: student-details.php".$qstring);
?>
