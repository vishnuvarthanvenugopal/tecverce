<?php  
include('connect.php');
if(isset($_SESSION['userType'])) {
	unset($_SESSION['userType']);
	session_destroy();
	redirect('index.php');
}
?>  