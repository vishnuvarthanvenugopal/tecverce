<?php 
include "header.php";
include "left-menu.php";
$curuserpsw=$_SESSION['userType']['password'];
$curuserregisterNumber=$_SESSION['userType']['registerNumber'];

if(isset($_POST['submit']))
{
    $currentpsw=$_POST['curpsw'];
    $newpsw=$_POST['newpsw'];
    $cnewpsw=$_POST['cnewpsw'];
    if($curuserpsw==$currentpsw)
    {
     $result ="UPDATE student SET password = '$cnewpsw' WHERE registerNumber = '$curuserregisterNumber'";
     
        $row=mysqli_query($connection,$result);
        echo "<script>
  alert('Password updated!')
  window.location.href='index.php'
  </script>";
    }
    else
    {

        echo "<script>
        alert('please enter current password')
         </script>"; 
        
    }
}


?>


<div class="page-wrapper">
<div class="row page-titles">
          <div class="col-md-5 align-self-center">
            <h3 class="text-primary">Password Change</h3> </div>
            <div class="col-md-7 align-self-center">
            </div>
        </div>



          
    <div class="container" id="changepassword" style="padding-top: 50px;">
        <form  method="post" action="" id="passwordchange" name="passwordchange">
        <div class="row">
            <div class="col-md-4"></div>                        
            <div class="col-md-4">
                <div class="form-group">
                    <label for="curpsw">Current Password *</label>
                    <input type="password" class="form-control" id="curpsw" name="curpsw" required="required" autocomplete="off"  />
                    <span id="err"></span>
                </div>
            </div>
              <div class="col-md-4"></div>
        </div>
        <div class="row">
            <div class="col-md-4"></div>                        
            <div class="col-md-4">
                <div class="form-group">
                    <label for="newpsw">New Password *</label>
                    <input type="password" class="form-control" id="newpsw" name="newpsw" required="required" autocomplete="off"  />
                </div>
            </div>
              <div class="col-md-4"></div>
        </div>
        <div class="row">
            <div class="col-md-4"></div>                        
            <div class="col-md-4">
                <div class="form-group">
                    <label for="cnewpsw">Confirm New Password *</label>
                    <input type="password" class="form-control" id="cnewpsw" name="cnewpsw" required="required" autocomplete="off"  />
                </div>
            </div>
              <div class="col-md-4"></div>
        </div>
        <div class="row">
            <div class="col-md-4"></div>                        
            <div class="col-md-4">
                <div class="form-group" style="text-align: center;">
        <button  style="left: 50px;" type="submit" class="btn btn-primary pull-left" id="submit" name="submit">Submit</button>
        </div>
            </div>
              <div class="col-md-4"></div>
        </div>
        </form>
    </div>

    

<br><br><br><br><br><br><br><br><br>

</div> 
<?php include "footer.php"; ?>
<script type="text/javascript" src="jquery.js"></script>

<script type="text/javascript">
   $(function () {
        $("#submit").click(function () {
            var password = $("#newpsw").val();
            var confirmPassword = $("#cnewpsw").val();
            if (password != confirmPassword) {
                alert("Passwords do not match.");
                return false;
            }
            return true;
        });
    });
           

</script> 

<!-- <script type="text/javascript">
    $(document).ready(function(){
        $('#curpsw').keyup(function(){
           
            var currentvalue = $('#curpsw').val();
            $.ajax({
            type: 'POST',
            data:{currentvalue:currentvalue},
             url:'ajaxpass.php',
                success:function(result)
                {
                    $('#err').html(result);
                }
            })
        })
    });



</script> -->
    

   