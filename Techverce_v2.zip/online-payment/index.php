<?php
include 'connect.php';
if(isset($_POST['login']))
{
    $registerNumber = mysqli_real_escape_string($connection,$_POST['registerNumber']);
    $dateOfBirth = mysqli_real_escape_string($connection,$_POST['dateOfBirth']);
    $password = mysqli_real_escape_string($connection,$_REQUEST['password']);

    if(empty($registerNumber)&&empty($dateOfBirth)) {
        $error = 'Fileds are Mandatory';
    } else  {
        //Checking Login Detail
    $result ="SELECT * FROM student WHERE registerNumber = '$registerNumber' AND dateOfBirth = '$dateOfBirth' AND password = '$password'";
     
        $row=mysqli_query($connection,$result);
        $query=mysqli_fetch_assoc($row);
        $count = mysqli_num_rows($row);

        if($count == 1) 
        {
           $_SESSION['userType'] = array(
                'name' => $query['firstName'],
                'registerNumber' =>  $query['registerNumber'],
                'id' =>  $query['studentId'],
                'password' =>$query['password'],
            );
        header("Location: dashboard.php"); 
        } 
        else {
            $error='Please enter valid credential';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=UTF-8"/>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="">
  <meta name="author" content="">
  <!-- Favicon icon -->
  <!--  -->
  <title>ASA-ONLINE-PAYMENT</title>
  <!-- Bootstrap Core CSS -->
  <link href="css/lib/bootstrap/bootstrap.min.css" rel="stylesheet">
   <link rel="shortcut icon" href="images/fevi.png" type="image/x-icon" />
    <!--<link rel="shortcut icon" href=" https://www.aiht.ac.in/online-payment/images/fevi.png" type="image/x-icon" />-->
  
  <!-- Custom CSS -->
  <link href="css/helper.css" rel="stylesheet">
  <link href="css/style.css" rel="stylesheet">
</head>
<body class="fix-header fix-sidebar" style="background-image:url(../student-management/images/bg.jpg);background-position: center;
  background-repeat: no-repeat;
  background-size: cover; height:825px;">
  <!-- Preloader - style you can find in spinners.css -->
  <div class="preloader">
    <svg class="circular" viewBox="25 25 50 50">
      <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="2" stroke-miterlimit="10" /> </svg>
    </div>
    <!-- Main wrapper  -->
    <div id="main-wrapper">
      <div class="unix-login">
        <div class="container-fluid">
          <div class="row justify-content-center">
            <div class="col-lg-4">
              <div class="login-content card1">
                <div class="login-form"  style="background:#007bff;">
                  <h4><b><img style="width:100%;"  src="http://asa.ac.in/images/logo1.png" alt="" class="dark-logo" /></b></h4>
                  <form method="POST" action="" id="add_user">
                    <?php if(isset($error)){ echo "<h4 style='color:red;text-align:center;'>".$error."</h4>";}?><br>
                      <div class="form-group">
                        <label>Registration No</label>
                        <input type="text" id="registerNumber" name="registerNumber" class="form-control"  value="<?php echo (isset($_POST['registerNumber'])) ? $_POST['registerNumber'] : ""; ?>" autocomplete="off" required>
                      </div>  
                      <div class="form-group">
                        <label contenteditable="true">DOB</label>
                        <input type="date" name="dateOfBirth" class="form-control" placeholder="dd/mm/yyy" required>
                      </div>
                      <div class="form-group">
                        <label>Password</label>
                        <input type="password" name="password" class="form-control" placeholder="" required>
                      </div>
                      <button type="submit" id="login" name="login" value="Login" class="btn btn-success">Sign in</button>
                      <!--<ul style="float: right;"><li><a href="" style="color:blue;">Forgot Password-?</a></li></ul>-->
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- All Jquery -->
      <script src="js/lib/jquery/jquery.min.js"></script>
      <!-- Bootstrap tether Core JavaScript -->
      <script src="js/lib/bootstrap/js/popper.min.js"></script>
      <script src="js/lib/bootstrap/js/bootstrap.min.js"></script>
      <!-- slimscrollbar scrollbar JavaScript -->
      <script src="js/jquery.slimscroll.js"></script>
      <!--Menu sidebar -->
      <script src="js/sidebarmenu.js"></script>
      <!--stickey kit -->
      <script src="js/lib/sticky-kit-master/dist/sticky-kit.min.js"></script>
      <!--Custom JavaScript -->
      <script src="js/custom.min.js"></script>
      <!-- Global site tag (gtag.js) - Google Analytics -->
      <script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13"></script>

      <script src="http://code.jquery.com/jquery-1.8.3.min.js" type="text/javascript"></script>

      <script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.10.0/jquery.validate.js" type="text/javascript"></script>
      <script  type="text/javascript">
        $().ready(function () {
          $("#add_user").validate({
            rules: {
              email: 
              {
                required: true,
                email: true         
              },
              password: "required"
            },
            messages: {
              email: {
                required:"Please enter email address",
                email:"Please enter a valid email address",
                remote: "Email already in use!"
              },
              password: {
                required:"Please enter correct password",
              }, 
            },    
            submitHandler: function(form) {
              form.submit();
            }
          });   
        }); 
      </script>
    </body>
 </html>