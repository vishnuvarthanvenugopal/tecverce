<?php
$connection = mysqli_connect('localhost', 'test-aiht', 'test-aiht@123');
if (!$connection) {
	die("Database Connection Failed" . mysqli_error($connection));
}
$select_db = mysqli_select_db($connection, 'test-aiht');
if (!$select_db) {
	die("Database Selection Failed" . mysqli_error($connection));
}
/*session*/
function checkSessionExist() {    
	if(!isset($_SESSION['userType'])) {
		redirect('index.php');        
	} 
}
function redirect ($loc = NULL) {
	if ($loc != NULL) {
		header("Location: {$loc}");
		exit;
	}
}
/*
*** db queries
*/
function dbRowInsert($tbl_name, $formData)
{
    global $connection;
    // retrieve the keys of the array (column titles)
    $fields = array_keys($formData);

    // build the query
    $sql = "INSERT INTO ".$tbl_name."(`".implode('`,`', $fields)."`)
    VALUES('".implode("','", $formData)."')";
    //echo $sql;

    // run and return the query result resource
    if (mysqli_query($connection, $sql)) {
        $last_insert_id =  mysqli_insert_id($connection);        
    } else { 
        echo "Error: " . $sql . "<br>" . mysqli_error($connection);
    }    
    return $last_insert_id;
}

// the where clause is left optional incase the user wants to delete every row!
function dbRowDelete($table_name, $where_clause='id')
{
    global $connection;
    // check for optional where clause
    $whereSQL = 'id';
    if(!empty($id))
    {
        // check to see if the 'where' keyword exists
        if(substr(strtoupper(trim($id)), 0, 5) != 'WHERE')
        {
            // not found, add keyword
            $whereSQL = " WHERE ".$id;
        } else
        {
            $whereSQL = " ".trim($id);
        }
    }
    // build the query
    $sql = "DELETE FROM ".$admin_users.$whereSQL;

    // run and return the query result resource
    return mysqli_query($connection,$sql);
}

// again where clause is left optional
function dbRowUpdate($table_name, $form_data, $where_clause='')
{
    global $connection;
    // check for optional where clause
    $whereSQL = '';
    if(!empty($where_clause))
    {
        // check to see if the 'where' keyword exists
        if(substr(strtoupper(trim($where_clause)), 0, 5) != 'WHERE')
        {
            // not found, add key word
            $whereSQL = " WHERE ".$where_clause;
        } else
        {
            $whereSQL = " ".trim($where_clause);
        }
    }
    // start the actual SQL statement
    $sql = "UPDATE ".$table_name." SET ";

    // loop and build the column /
    $sets = array();
    foreach($form_data as $column => $value)
    {
     $sets[] = "`".$column."` = '".$value."'";
 }
 $sql .= implode(', ', $sets);

    // append the where statement
 $sql .= $whereSQL;
 //echo $sql;
    // run and return the query result
 return mysqli_query($connection,$sql);
}

function printArray($aray) {
    print "<pre>";
    print_r($aray);
    print "</pre>";
}

function filter($data) {	
    global $connection;
    $data = trim(htmlentities(strip_tags($data)));
    if (get_magic_quotes_gpc())
        $data = stripslashes($data);
    $data = mysqli_real_escape_string($connection,$data);
    return $data;
}

function postDataFilter($postAray) {
    foreach($postAray as $key => $value) {
        $mydata[$key] = filter($value);
    }
    return $mydata;
}

function numberFormat($amt) {
    return number_format((float)$amt, 2, '.', '');
}

function makeCheckSum($input_xml) {
    $checksum = hash_hmac('sha256',$input_xml,'Y7Xtv70Su135', false);    
    return strtoupper($checksum);
}

function initiatePayment($input_xml) {    
    $url = "https://payments.billdesk.com/ecom/ECOM2ReqHandler";
    $request_xml = '<REQUEST>'.$input_xml.'<CHECKSUM>'.makeCheckSum($input_xml).'</CHECKSUM></REQUEST>';
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POSTFIELDS,'msg=<?xml version="1.0" encoding="UTF-8"?>'.$request_xml);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 300);
    $data = curl_exec($ch);
    curl_close($ch);
    $array_data = json_decode(json_encode(simplexml_load_string($data)), true);
    //printArray($array_data);
    return $array_data;
}

function getIndianCurrency(float $number)
{
    $decimal = round($number - ($no = floor($number)), 2) * 100;
    $hundred = null;
    $digits_length = strlen($no);
    $i = 0;
    $str = array();
    $words = array(0 => '', 1 => 'one', 2 => 'two',
        3 => 'three', 4 => 'four', 5 => 'five', 6 => 'six',
        7 => 'seven', 8 => 'eight', 9 => 'nine',
        10 => 'ten', 11 => 'eleven', 12 => 'twelve',
        13 => 'thirteen', 14 => 'fourteen', 15 => 'fifteen',
        16 => 'sixteen', 17 => 'seventeen', 18 => 'eighteen',
        19 => 'nineteen', 20 => 'twenty', 30 => 'thirty',
        40 => 'forty', 50 => 'fifty', 60 => 'sixty',
        70 => 'seventy', 80 => 'eighty', 90 => 'ninety');
    $digits = array('', 'hundred','thousand','lakh', 'crore');
    while( $i < $digits_length ) {
        $divider = ($i == 2) ? 10 : 100;
        $number = floor($no % $divider);
        $no = floor($no / $divider);
        $i += $divider == 10 ? 1 : 2;
        if ($number) {
            $plural = (($counter = count($str)) && $number > 9) ? '' : null;
            $hundred = ($counter == 1 && $str[0]) ? ' and ' : null;
            $str [] = ($number < 21) ? $words[$number].' '. $digits[$counter]. $plural.' '.$hundred:$words[floor($number / 10) * 10].' '.$words[$number % 10]. ' '.$digits[$counter].$plural.' '.$hundred;
        } else $str[] = null;
    }
    $Only = implode('', array_reverse($str));
    $paise = ($decimal) ? "." . ($words[$decimal / 10] . " " . $words[$decimal % 10]) . ' Paise' : '';
    return ($Only ? $Only . 'Only ' : '') . $paise;
}
function dbSelectQry($sql) {
    global $connection;
    $qry = mysqli_query($connection,$sql);
    $post = array();
    while($row = mysqli_fetch_array($qry,MYSQLI_ASSOC))
    {
        //print_r($row);
        $post[] = $row;
    }
    return $post;
}

?>