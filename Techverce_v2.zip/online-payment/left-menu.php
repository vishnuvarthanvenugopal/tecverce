<!-- Left Sidebar  -->
<div class="left-sidebar">
    
<style>
/*.nav li {
  border-bottom: 3px solid rgba(0, 0, 0, 0);
}
.nav li:hover {
  border-bottom: 3px solid #eee;
}
.nav li.active {
  border-bottom: 3px solid #338ecf;
  background: blue;
}*/
</style>

<!-- Sidebar scroll-->
    <div class="scroll-sidebar">
        <!-- Sidebar navigation-->
        <nav class="sidebar-nav">
            <ul id="sidebarnav" >
                <li class="nav-devider"></li>
                <li class="nav-label">Home</li>
                <li> <a class="has-arrow" href="dashboard.php" aria-expanded="false"><i class="fa fa-credit-card-alt"></i><span class="hide-menu">TUTION FEES </span></a>
                </li>
               <li> <a class="has-arrow" href="examfees.php" aria-expanded="false"><i class="fa fa-newspaper-o"></i><span class="hide-menu">EXAM FEES </span></a>
                </li>
                <!--<li> <a class="has-arrow" href="examfees_list.php" aria-expanded="false"><i class="fa fa-newspaper-o"></i><span class="hide-menu">EXAM FEES </span></a>
                </li>-->
                 <li> <a class="has-arrow" href="paymenthistory.php" aria-expanded="false"><i class="fa fa-history"></i><span class="hide-menu">PAYMENT HISTORY</span></a>
                </li>
                   <li> <a class="has-arrow" href="exam_fee_list.php" aria-expanded="false"><i class="fa fa-history"></i><span class="hide-menu">EXAM FEES  HISTORY</span></a>
                </li>
                
               
            </ul>
        </nav>
        <!-- End Sidebar navigation -->
    </div>
    <!-- End Sidebar scroll-->
</div>
