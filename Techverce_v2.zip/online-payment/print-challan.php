<?php
include "connect.php";

$sql = "SELECT * FROM payment_history as p left join student as s on p.student_id = s.studentId  WHERE p.id=".$_GET["id"]."";

$stdqry = mysqli_query($connection,$sql) or die(mysql_error());
$row = mysqli_fetch_assoc($stdqry);  

//echo '<pre>';print_r($row);echo "</pre>";exit;
//echo '<pre>';print_r($row);
//echo $row['totalFees'];
if($row['totalFees'] == 0){
    $total = $row['tutition_fee'] + $row['hos_dys_fee'] + $row['pre_tutition_fee'] + $row['pre_hos_dys_fee'] + $row['serviceCharge'];
} else { echo $row['tutition_fee'];
    $total = $row['totalFees'];
    
}

$tutition_fee = $row['tutition_fee'] + $row['pre_tutition_fee'];
if($row['studentType'] == 'H'){
   $hostel_fee =  $row['hos_dys_fee'] + $row['pre_hos_dys_fee'];
   $daysscholar_fee = $row['serviceCharge'];
} else {
    $hostel_fee = 0;
   $daysscholar_fee =  $row['hos_dys_fee'] + $row['pre_hos_dys_fee'] + $row['serviceCharge'];
}
?> 
<html>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<!-- <link href="app-assets/css/print.css" rel="stylesheet" id="bootstrap-css"> -->
<style>
table, th, td {
	border: 1px solid black;
	border-collapse: collapse;
}
th, td {
	padding: 5px;
	text-align: left;
}
</style>

<body>
	<section>
		<div class="container">
				
					<div class="col-md-12">
						<div class="col-md-2">
						</div>
						<div class="col-md-8" style="text-align: center;">
						<h4 ><b>INDIAN BANK, Siruseri Branch</b></h4>
						<h4><b>ANAND INSTITUTE OF HIGHER TECHNOLOGY</b></h4>
						<h4><b>Kazhipattur, 603103</b></h4>
						<h4 style="text-decoration:underline"><b>AIHT - College Fees Payment Receipt</b></h4>
					</div>
					<div class="col-md-2">
						</div>
				</div>

				<div class="row" >
						<div class="col-md-6">
							<h4 style="float: left;">Challan No : <span style="display:inline-block;width:150px;border-bottom: 1px dotted;"><?php echo $row['id']; ?></span></h4>
						</div>
						<div class="col-md-6">
							<h4 style="float: right;">DATE: <?php echo date("d/m/Y");?></h4>
						</div>
				</div>
					<div class="row" >
						<div class="col-md-12">
							<h4 style="text-align:center;"><b>Received: &nbsp;&nbsp;Rs <span style="display:inline-block;width:150px;border-bottom: 1px dotted;"><?php echo $total; ?></span> to the credit of 
								AIHT College Fees Accounts</b></h4>
						</div>
					</div><br>
					
					<style>table.pay_info_table, table.pay_info_table th, table.pay_info_table td{border:none}</style>
					<table class="pay_info_table" border="0" width="100%">
					    <tr>
					        <td width="25%"><b>Student Name</b></td>
					        <td width="25%">: <?php echo $row['firstName'];?></td>
					        <td width="25%"><b>Payment Mode</b></td>
					        <td width="25%">: <?= $row['payment_mode'];?></td>
					    </tr>
					    <tr>
    						<td><b>Register Number:</b></td>
    						<td>: <?php echo $row['registerNumber'];?></td>
    						<td><b>Transaction Ref No</b></td>
    						<td>: <?= $row['txn_ref_no'];?></td>
    					</tr>
    					<tr>
    						<td><b>Branch</b></td>
    						<td>: <?php echo $row['department'];?></td>
    						<td><b>Bank Ref No</b></td>
    						<td>: <?= $row['bnk_ref_no'];?></td>
    					</tr>
    					<tr>
    						<td><b>Year</b></td>
    						<td>: <?php echo $row['yearOfStudying'];?></td>
    						<td><b>Payment Date</b></td>
    						<td>: <?= $row['payment_date'];?></td>
    					</tr>
    					<tr>
    						<td><b>Quota</b></td>
    						<td>: <?php echo $row['quota'];?></td>
    						<td><b>Mobile No</b></td>
    						<td>: <?= $row['mobile'];?></td>
    					</tr>
    					<tr>
    						<td><b>First Graduate</b></td>
    						<td>: Yes/No</td>
    						<td><b>Payment Status</b></td>
    						<td>: <?= $row['payment_status'];?></td>
    					</tr>
					</table>
					<br>
				
					<table width="100%" class="table-responsive table-bordered" rules="groups"  cellspacing="0" cellpadding="5" border="1" align="right">

						<tr>
							<th>Particulars</th>
							<th>Amounts</th>
						</tr>
						<tr>
							<td><b>Tution Fees</b> [ A/C No : 773061939 ]</td>
							<td>₹<?php echo $tutition_fee; ?></td>
						</tr>
						<tr>
							<td><b>Hostel Fees</b> [ A/C No: 494730056 ]</td>
							<td>₹<?php echo $hostel_fee; ?></td>
						</tr>
						<tr>
							<td><b>Days scholar Fees + Service Tax</b> [ A/C No: 494730012 ]</td>
							<td>₹<?php echo $daysscholar_fee; ?></td>
						</tr>
						<tr>
							<td><b>Exam Fees & Others</b> [ A/C No: 494730078 ]</td>
							<td>₹0</td>
						</tr>
						<tr>
							<td><b>Total</b></td>
							<td>₹<?= $total;?></td>
						</tr>
					</table>
					<br>
					<div class="row">
					    <div class="col-md-12">
    						<h4>Amounts in words: Rupees <span style="display:inline-block;border-bottom: 1px dotted;"><?php echo getIndianCurrency($total); ?></span></h4>
    					
    					</div>
					</div>
					<table class="pay_info_table" border="0" width="100%">
					    <tr>
					        <td width="75%">&nbsp;</td>
					        <td width="25%">[&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;]<br>&nbsp;&nbsp;Remitter Sign with Name and Date<br>&nbsp;&nbsp;Mob: </td>
					       </tr>
					</table>
					<br>
					<div style="border:1px solid;padding:10px;">
					    <p style="font-size:17px;"><b>For Office Use Only</b></p>
					    <p style="font-size:17px;">The above mentioned amounts are credited in the respective account of AIHT</p>
					    <br><br>
					    <p>Verified By</p><br><br>
					    <table class="pay_info_table" border="0" width="100%">
    					    <tr>
    					        <td width="50%">Office Staff<br>Sign & Date</td>
    					        <td width="50%">
    					            <div style="margin-right:50px;text-align:right;">College Seal</div>
    					        </td>
    					       </tr>
    					</table>
					    
					</div>
				</div>
			</section>
			<script>
			    window.print();
			</script>
		</body>
		</html>	
