<?php
include("connect.php");
$pageAction = trim($_GET["action"]);
switch ($pageAction) {
    case "fetchdetails":    
        $regno = $_GET["reg"];
        if($regno==$_SESSION['userType']['registerNumber'])
        {
        $qry = "SELECT * FROM student WHERE registerNumber ='".trim($regno)."' OR applicationNumber = '".trim($regno)."' ";
        $stdqry = mysqli_query($connection,$qry) or die(mysql_error());
        $row = mysqli_fetch_assoc($stdqry);
        }     
        if(empty($row)) {
            $json =  array("status" => "error", "message" => "Given application / registeration number is invalid." );
            echo json_encode($json);
        } else {
             $student_fees = "SELECT * FROM studentfees WHERE studentId = '".$row["studentId"]."'";
            $student_qry = selectQryToAray($student_fees);

            $student_payment_history = "SELECT SUM(tutition_fee) as paid_tution,SUM(hos_dys_fee) as paid_other_fees,SUM(pre_tutition_fee) as paid_pre_tution,SUM(pre_hos_dys_fee) as paid_pre_other_fees FROM payment_history WHERE student_id = '".$row["studentId"]."' AND payment_status = 'SUCCESS' ";
            $student_payment_qry = selectQryToAray($student_payment_history);
           /* printArray($student_payment_qry['paid_pre_other_fees']);
            exit;*/
            $student_fees_aray = array_merge($student_qry[0],$student_payment_qry[0]);
            $data = array_merge($row, array("status"=>"success","fees" => $student_fees_aray));
            echo json_encode($data);
        }
        break;
    default:
     echo "Invalid page action";
}
?>