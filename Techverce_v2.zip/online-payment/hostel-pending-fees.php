
<?php include "header.php";
include "left-menu.php";
?>
<div class="page-wrapper">
  <!-- Bread crumb -->
  <div class="row page-titles">
    <div class="col-md-5 align-self-center">
      <h3 class="text-primary">List of Students fees Pending Hostel</h3> </div>
      <div class="col-md-7 align-self-center">
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
          <li class="breadcrumb-item active">Students</li>
        </ol>
      </div>
    </div>
    <!-- End Bread crumb -->
    <!-- Container fluid  -->
    <div class="container-fluid">
      <!-- Start Page Content -->
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-body">
              <h2 style="text-align: center;">Fees Pending Student Details</h2>          
              <div class="table-responsive m-t-40">
                <table id="example23" class="display nowrap table table-hover table-striped table-bordered" cellspacing="0" width="100%">
                  <thead>
                    <tr>
                      <th>Student ID</th>
                      <th>Firstname</th> 
                    <!--   <th>Application Number</th>  -->                    
                      <th>Lastname</th>
                      <th>Register Number</th>
                      <th>Year Of Studying</th>                      
                      <th>Department</th>
                      <th>Tution Fees</th>
                      <th>Hostel Fees</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php
                    $result = mysqli_query($connection,"SELECT student.studentId,student.dateOfBirth,student.firstName,student.lastName,student.registerNumber,student.yearOfStudying,student.department ,student.studentType ,studentfees.tutionFeeDue  tution, studentfees.travelHostelDue  hostel
          FROM student 
          INNER JOIN studentfees ON student.studentId = studentfees.studentId WHERE student.studentType = 'H' AND (studentfees.tutionFeeDue > 0 OR studentfees.travelHostelDue > 0)") or die(mysqli_error()); 


                    /*$result = mysqli_query($connection,"SELECT * FROM student ORDER BY studentId DESC") or die(mysqli_error());*/
                    $i = 1;
                    while($row = mysqli_fetch_array( $result )) 
                    {
                      echo "<tr>";
                      echo '<td>' . $i++ . '</td>';
                      echo '<td>' . $row['firstName'] . '</td>';
                      // echo '<td>' . $row['applicationNumber'] . '</td>';
                      echo '<td>' . $row['lastName'] . '</td>';
                      echo '<td>' . $row['registerNumber'] . '</td>';
                      echo '<td>' . $row['yearOfStudying'] . '</td>';
                      echo '<td>' . $row['department'] . '</td>';
                      echo '<td>' . $row['tution'] . '</td>';
                      echo '<td>' . $row['hostel'] . '</td>';
                      /*echo '<td align="center">' . strtoupper($row['department']) . '</td>';
                      echo '<td>' . $row['mobile'] . '</td>';
                      echo '<td align="center">' . $row['yearOfJoining'] . '</td>';*/                      
                      echo '                        <td>
                      <a href="hostel-pending-fees-details.php?id='.$row['studentId'].' ">
                      <i class="fa fa-eye" title="View" style="color:#1c8fb7; font-size:17px;"></i></a>
                      &nbsp;&nbsp;
                      
                      </td>'; 
                      echo "</tr>";
                    }
                    ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- End PAge Content -->
    </div>
    <!-- End Container fluid  -->
    <!-- footer -->
    <?php include "footer.php"; ?>
    <script type="text/javascript">
      $(document).ready( function () {
    $('#example23').DataTable();
} );
    </script>