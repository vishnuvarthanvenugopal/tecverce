<?php include "connect.php"; 

$id=$_REQUEST['id'];

$select_events=dbRowDelete('tbl_news_events', "id = '".$id."'");

if($select_events)

{

	echo "<script>
  alert('events has been deleted!')
  window.location.href='events-lists.php'
  </script>";

}

else

{

	echo "Delete Process Failed";

}

?>