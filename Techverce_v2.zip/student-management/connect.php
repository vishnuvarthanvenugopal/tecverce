<?php
session_start();
 //$connection = mysqli_connect('localhost','tech-dev', 'tech-dev@123');
$connection = mysqli_connect('localhost', 'root', '');
if (!$connection) {
    die("Database Connection Failed" . mysqli_error($connection));
}
$select_db = mysqli_select_db($connection, 'test-aiht_new');
if (!$select_db) {
    die("Database Selection Failed" . mysqli_error($connection));
}


/*session*/
function checkSessionExist() {    
    if(!isset($_SESSION['userType'])) {
        redirect('index.php');
    } 
}
function redirect ($loc = NULL) {
    if ($loc != NULL) {
        header("Location: {$loc}");
        exit;
    }
}
/*
*** db queries
*/
function dbRowInsert($tbl_name, $formData)
{
    global $connection;
    // retrieve the keys of the array (column titles)
    $fields = array_keys($formData);
    // build the query
    $sql = "INSERT INTO ".$tbl_name."(`".implode('`,`', $fields)."`)
    VALUES('".implode("','", $formData)."')";
    //echo $sql;
    if (mysqli_query($connection, $sql)) { 
        
        $last_insert_id =  mysqli_insert_id($connection);
        
    } else { 
        echo "Error: " . $sql . "<br>" . mysqli_error($connection);
    }
    return $last_insert_id;
    // run and return the query result resource
    /*return mysqli_query($connection,$sql);*/
}
// the where clause is left optional incase the user wants to delete every row!
function dbRowDelete($table_name, $where_clause='')
{
     global $connection;
    // check for optional where clause
    $whereSQL = '';
    if(!empty($where_clause))
    {
        // check to see if the 'where' keyword exists
        if(substr(strtoupper(trim($where_clause)), 0, 5) != 'WHERE')
        {
            // not found, add keyword
            $whereSQL = " WHERE ".$where_clause;
        } else
        {
            $whereSQL = " ".trim($where_clause);
        }
    }
    // build the query
    $sql = "DELETE FROM ".$table_name.$whereSQL;
    // run and return the query result resource
    return mysqli_query($connection,$sql);
}
// again where clause is left optional
function dbRowUpdate($table_name, $form_data, $where_clause='')
{
    global $connection;
    // check for optional where clause
    $whereSQL = '';
    if(!empty($where_clause))
    {
        // check to see if the 'where' keyword exists
        if(substr(strtoupper(trim($where_clause)), 0, 5) != 'WHERE')
        {
            // not found, add key word
            $whereSQL = " WHERE ".$where_clause;
        } else
        {
            $whereSQL = " ".trim($where_clause);
        }
    }
    // start the actual SQL statement
    $sql = "UPDATE ".$table_name." SET ";

    // loop and build the column /
    $sets = array();
    foreach($form_data as $column => $value)
    {
     $sets[] = "`".$column."` = '".$value."'";
 }
 $sql .= implode(', ', $sets);

    // append the where statement
 $sql .= $whereSQL;
 
 if (mysqli_query($connection, $sql)) { 
        
   return true;
    
} else { 
    echo "Error: " . $sql . "<br>" . mysqli_error($connection);
    return false;
}
 
}
function printArray($aray) {
    print "<pre>";
    print_r($aray);
    print "</pre>";
}
function filter($data) {	
    global $connection;
    $data = trim(htmlentities(strip_tags($data)));
    if (get_magic_quotes_gpc())
        $data = stripslashes($data);
    $data = mysqli_real_escape_string($connection,$data);
    return $data;
}
function postDataFilter($postAray) {
    foreach($postAray as $key => $value) {
        $mydata[$key] = filter($value);
    }
    return $mydata;
}
function checkStudentExists($registerNumber) {
    global $connection;
    $sql = "SELECT studentId,firstName,lastName FROM student WHERE registerNumber = '".$registerNumber."' ";
    //echo $sql;
    $qry = mysqli_query($connection,$sql);
    if (!$qry) {
    printf("Error: %s\n", mysqli_error($connection));
    exit();
}
    return mysqli_fetch_array($qry,MYSQLI_ASSOC);
}
function generateSeoURL($string, $wordLimit = 0)
{
    $separator = '-';
    if($wordLimit != 0){
        $wordArr = explode(' ', $string);
        $string = implode(' ', array_slice($wordArr, 0, $wordLimit));
    }
    $quoteSeparator = preg_quote($separator, '#');
    $trans = array(
        '&.+?;'                    => '',
        '[^\w\d _-]'            => '',
        '\s+'                    => $separator,
        '('.$quoteSeparator.')+'=> $separator
    );
    $string = strip_tags($string);
    foreach ($trans as $key => $val){
        $string = preg_replace('#'.$key.'#i'.(UTF8_ENABLED ? 'u' : ''), $val, $string);
    }
    $string = strtolower($string);

    return trim(trim($string, $separator));
}
function selectQryToAray($qry) {
    global $connection;
    $result = mysqli_query($connection,$qry);
    while ($row = mysqli_fetch_array($result,MYSQLI_ASSOC)) { 
        $rows[] = $row; 
    } 
    return $rows; 
}
function selectSingleRow($sql) {
     global $connection;
   $query = mysqli_query($connection, $sql);
   return mysqli_fetch_assoc($query);
}

function createThumbnail($filename, $thumb_width, $thumb_height, $upload_dir, $upload_dir_thumbs) {
$upload_image = $upload_dir.$filename;
$thumbnail_image = $upload_dir_thumbs.$filename;
list($width,$height) = getimagesize($upload_image);
$thumb = imagecreatetruecolor($thumb_width,$thumb_height);
if(preg_match('/[.](jpg|jpeg)$/i', $filename)) {
$image_source = imagecreatefromjpeg($upload_image);
} 
else if (preg_match('/[.](gif)$/i', $filename)) {
$image_source = imagecreatefromgif($upload_image);
}
 else if (preg_match('/[.](png)$/i', $filename)) {
$image_source = imagecreatefrompng($upload_image);
}
 else {
$image_source = imagecreatefromjpeg($upload_image);
}
imagecopyresized($thumb,$image_source,0,0,0,0,$thumb_width,$thumb_height,$width,$height);
if(preg_match('/[.](jpg|jpeg)$/i', $filename)) {
imagejpeg($thumb,$thumbnail_image,100);
} 
else if (preg_match('/[.](gif)$/i', $filename)) {
imagegif($thumb,$thumbnail_image,100);
} 
else if (preg_match('/[.](png)$/i', $filename)) {
imagepng($thumb,$thumbnail_image,1000);
} 
else {
imagejpeg($thumb,$thumbnail_image,100);
}
}

function getIndianCurrency(float $number)
{
    $decimal = round($number - ($no = floor($number)), 2) * 100;
    $hundred = null;
    $digits_length = strlen($no);
    $i = 0;
    $str = array();
    $words = array(0 => '', 1 => 'one', 2 => 'two',
        3 => 'three', 4 => 'four', 5 => 'five', 6 => 'six',
        7 => 'seven', 8 => 'eight', 9 => 'nine',
        10 => 'ten', 11 => 'eleven', 12 => 'twelve',
        13 => 'thirteen', 14 => 'fourteen', 15 => 'fifteen',
        16 => 'sixteen', 17 => 'seventeen', 18 => 'eighteen',
        19 => 'nineteen', 20 => 'twenty', 30 => 'thirty',
        40 => 'forty', 50 => 'fifty', 60 => 'sixty',
        70 => 'seventy', 80 => 'eighty', 90 => 'ninety');
    $digits = array('', 'hundred','thousand','lakh', 'crore');
    while( $i < $digits_length ) {
        $divider = ($i == 2) ? 10 : 100;
        $number = floor($no % $divider);
        $no = floor($no / $divider);
        $i += $divider == 10 ? 1 : 2;
        if ($number) {
            $plural = (($counter = count($str)) && $number > 9) ? '' : null;
            $hundred = ($counter == 1 && $str[0]) ? ' and ' : null;
            $str [] = ($number < 21) ? $words[$number].' '. $digits[$counter]. $plural.' '.$hundred:$words[floor($number / 10) * 10].' '.$words[$number % 10]. ' '.$digits[$counter].$plural.' '.$hundred;
        } else $str[] = null;
    }
    $Only = implode('', array_reverse($str));
    $paise = ($decimal) ? "." . ($words[$decimal / 10] . " " . $words[$decimal % 10]) . ' Paise' : '';
    return ($Only ? $Only . 'Only ' : '') . $paise;
}
?>