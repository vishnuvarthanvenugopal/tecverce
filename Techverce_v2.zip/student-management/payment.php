<?php 
if(function_exists('date_default_timezone_set'))
{
    date_default_timezone_set("Asia/Kolkata");
}
$date = date('YmdHis');

$transaction_no = date('mdHis');

function makeCheckSum($input_xml) {
    $checksum = hash_hmac('sha256',$input_xml,'Y7Xtv70Su135', false);    
    return strtoupper($checksum);
}

//Store your XML Request in a variable

function initiatePayment($input_xml) {
    
    $url = "https://payments.billdesk.com/ecom/ECOM2ReqHandler";
    $request_xml = '<REQUEST>'.$input_xml.'<CHECKSUM>'.makeCheckSum($input_xml).'</CHECKSUM></REQUEST>';
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    // Following line is compulsary to add as it is:
    curl_setopt($ch, CURLOPT_POSTFIELDS,'msg=<?xml version="1.0" encoding="UTF-8"?>'.$request_xml);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 300);
    $data = curl_exec($ch);
    curl_close($ch);
    //$response = simplexml_load_string($data);    
    //$txndata = $response->TXNDATA;
    $array_data = json_decode(json_encode(simplexml_load_string($data)), true);

    print_r('<pre>');
    print_r($array_data['TXNDATA']);
    print_r('</pre>');

    return $array_data['TXNDATA'];
}

function array2xml($data, $root = null){
    $xml = new SimpleXMLElement($root ? '<' . $root . '/>' : '<root/>');
    array_walk_recursive($data, function($value, $key)use($xml){
        $xml->addChild($key, $value);
    });
    return $xml->asXML();
}

$pgcustomerid = 'aihtcus'. $date;

$input_xml = '<TXNDATA><TXNSUMMARY><REQID>PGECOM201</REQID><PGMERCID>IBANATECM</PGMERCID><RECORDS>2</RECORDS><PGCUSTOMERID>'.$pgcustomerid.'</PGCUSTOMERID><AMOUNT>2.00</AMOUNT><TXNDATE>'.$date.'</TXNDATE></TXNSUMMARY><RECORD ID="1"><MERCID>IBATKEY</MERCID><AMOUNT>1.00</AMOUNT><CUSTOMERID>aiht001'.$transaction_no.'</CUSTOMERID><ADDITIONALINFO1>9000007309</ADDITIONALINFO1><ADDITIONALINFO2>sunilkumar.perala@gmail.com</ADDITIONALINFO2><ADDITIONALINFO3>NA</ADDITIONALINFO3><ADDITIONALINFO4>NA</ADDITIONALINFO4><ADDITIONALINFO5>NA</ADDITIONALINFO5><ADDITIONALINFO6>NA</ADDITIONALINFO6><ADDITIONALINFO7>NA</ADDITIONALINFO7><FILLER1>NA</FILLER1><FILLER2>NA</FILLER2><FILLER3>NA</FILLER3></RECORD><RECORD ID="2"><MERCID>IBATHOS</MERCID><AMOUNT>1.00</AMOUNT><CUSTOMERID>aiht002'.$transaction_no.'</CUSTOMERID><ADDITIONALINFO1>9000007309</ADDITIONALINFO1><ADDITIONALINFO2>sunilkumar.perala@gmail.com</ADDITIONALINFO2><ADDITIONALINFO3>NA</ADDITIONALINFO3><ADDITIONALINFO4>NA</ADDITIONALINFO4><ADDITIONALINFO5>NA</ADDITIONALINFO5><ADDITIONALINFO6>NA</ADDITIONALINFO6><ADDITIONALINFO7>NA</ADDITIONALINFO7><FILLER1>NA</FILLER1><FILLER2>NA</FILLER2><FILLER3>NA</FILLER3></RECORD></TXNDATA>';

$response_aray = initiatePayment($input_xml);
$response_xml = array2xml($response_aray,"TXNSUMMARY");
$response_xml = substr($response_xml, strpos($response_xml, '?'.'>') + 2);
$initialChecksum = "<TXNDATA>".$response_xml."</TXNDATA>";

$payment_id="aihtpay0000".$transaction_no;
$msg_str = "IBANATECM|".$pgcustomerid."|NA|2.00|NA|NA|NA|INR|NA|R|ibanatecm|NA|NA|F|9942855065|silaluthirapathi@gmail.com|82206205032|NA|NA|NA|NA|http://aiht.ac.in/payment-sucess.php";


/*$checksum = hash_hmac('sha256',$msg_str,'Y7Xtv70Su135', false); 
$checksum = strtoupper($checksum);*/

$msg = $msg_str."|".makeCheckSum($msg_str);                    

?> 
<form name='billdesk' method='post' action='https://pgi.billdesk.com/pgidsk/PGIMerchantPayment'>
<input type="hidden" name="msg" value='<?=$msg?>' >
 <input type='submit' value='Pay' id='button-confirm'/>
</form>
<script type="text/javascript">
    function pay() {        
        document.payfrm.submit(); 
    }   
</script>
