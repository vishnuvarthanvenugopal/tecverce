<?php 
include "header.php";
include "left-menu.php";
if(isset($_POST["submit"]))
{
	
    $filename = md5($_POST['title']).".pdf";  
	$filepath = "../webinar/files/invitations/";
    $newname = $filepath .$filename;
    $FileType = pathinfo($newname,PATHINFO_EXTENSION);
    if($FileType == "pdf")
    {
		/*
		$file = $_FILES['invitation_brochure']['name'];
		$path = pathinfo($file);
        $filename = md5($file);
        $ext = $path['extension'];
		$temp_name = $_FILES['invitation_brochure']['tmp_name'];
        $path_filename_ext = $filepath.$filename.".".$ext;
		*/
		$random_file_name = rand();
		$invi_file = $_FILES['invitation_brochure']['name'];
		$invi_path = pathinfo($invi_file);
        $invi_filename = $random_file_name;
        $invi_ext = $invi_path['extension'];
		$invi_temp_name = $invi_filename.".".$invi_ext;
        $invi_path_filename_ext = "../webinar/files/invitations/".$invi_filename.".".$invi_ext;
		
		$pho_file = $_FILES['staff_photo']['name'];
		$pho_path = pathinfo($pho_file);
        $pho_filename = $random_file_name;
        $pho_ext = $pho_path['extension'];
		$pho_temp_name = $pho_filename.".".$pho_ext;
        $pho_filename_ext = "../webinar/files/profile_images/".$pho_filename.".".$pho_ext;
		
		$bann_file = $_FILES['banner_image']['name'];
		$bann_path = pathinfo($pho_file);
        $bann_filename = $random_file_name;
        $bann_ext = $bann_path['extension'];
		$bann_temp_name = $bann_filename.".".$bann_ext;
        $bann_filename_ext = "../webinar/files/banner_image/".$bann_filename.".".$bann_ext;
		 
		$invitation_path = $invi_path_filename_ext;
		$profile_path = $pho_filename_ext;
		$bann_path = $bann_filename_ext;
		//$invitation_path = "../webinar/files/invitations/".basename( $_FILES['invitation_brochure']['name']);
		//$profile_path = "../webinar/files/profile_images/".basename( $_FILES['staff_photo']['name']);
        if(move_uploaded_file($_FILES['invitation_brochure']['tmp_name'],$invitation_path) && move_uploaded_file($_FILES['staff_photo']['tmp_name'],$profile_path) && move_uploaded_file($_FILES['banner_image']['tmp_name'],$bann_path))
        {
			
			$start_date_time = $_POST['start_date_time'];
			$start_date_time = date('Y-m-d H:i:s',strtotime($start_date_time));
			
			$end_date_time = $_POST['end_date_time'];
			$end_date_time = date('Y-m-d H:i:s',strtotime($end_date_time));
			
			//$date = $_POST['start_date_time'];
			//$date = new \DateTime();
			//$start_date_time =  date_format($date, 'Y-m-d H:i:s');
			//echo date_format($date, 'G:ia');
			
             $insertdata = dbRowInsert('webinar_info', array(
                'category_of_event'=> $_POST['category_of_event'],
                'title'=> $_POST['title'],
                'start_date_time'=>$start_date_time,
                'end_date_time'=>$end_date_time,
                'event_organizer'=> $_POST['event_organizer'],
                'registration_link'=> $_POST['registration_link'],
                'join_event_link'=> $_POST['join_event_link'],
                'video_link'=> $_POST['video_link'],
                'feedback_link'=> $_POST['feedback_link'],
                'staff_name'=> $_POST['staff_name'],
                'organizer_name'=> $_POST['organizer_name'],
                'staff_phone'=> $_POST['staff_phone'],
                'staff_email'=> $_POST['staff_email'],
                'staff_details'=> $_POST['staff_details'],
                'event_details'=> $_POST['event_details'],
                'invitation_brochure'=> $invi_temp_name,
                'staff_photo'=> $pho_temp_name,
                'banner_image'=> $bann_temp_name,
                'createdBy' =>$_SESSION['userType']['name'], 
                'status'  =>1,
            ));
			if($insertdata)
			{
				echo "<script>
				  alert('Webinar added succefully!')
				  //window.location.href='add_webinar.php'
				  </script>";
			}
			else
			{
				echo "<script>
				  alert('Webinar Record Insert Error')
				  //window.location.href='add_webinar.php'
				  </script>";
			}
		  
        }
        else{
            echo 'failed to upload';
        	}
      
    
    }
    else
    {
        echo "<p>Files must be uploaded in PDF format.</p>";
    }
	

}
?>   

<link href="css/bootstrap.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="css/font-awesome.css">
<link rel="stylesheet" href="css/bootstrap-datetimepicker.min.css" type="text/css" media="all" />

<!-- End header header -->
<!-- Page wrapper  -->
<div class="page-wrapper">
	<!-- Bread crumb -->
		<div class="row page-titles">
			<div class="col-md-5 align-self-center">
			<h3 class="text-primary">Add Webinar</h3> </div>
			<div class="col-md-7 align-self-center">
				<ol class="breadcrumb">
					<li class="breadcrumb-item"><a >Home</a></li>
					<li class="breadcrumb-item active">Dashboard</li>
				</ol>
			</div>
		</div>
		<!-- End Bread crumb -->
		<!-- Container fluid  -->
		<div class="container-fluid">
			<!-- Start Page Content -->
			<h2 style="text-align: center;"> Webinar</h2>

			<div class="row justify-content-center">
				<div class="col-lg-12">
					<div class="card">
						<div class="card-body">
							<div class="form-validation">
								<form method="POST" action="#" id="add_webinar" name="add_webinar" enctype="multipart/form-data">
									<div class="row">
										<div class="col-md-12">
											<div class="form-group row">
												<label class="col-md-12 col-form-label" for="val-category">Category of Event   <span class="text-danger">*</span></label>
												<div class="col-md-9">
													<input type="text" class="form-control validate" id="category_of_event" name="category_of_event" placeholder="Enter a Category of Event.." required>
												</div>
											</div>
										</div>
										<div class="col-md-12">
											<div class="form-group row">
												<label class="col-md-12 col-form-label" for="val-event-name">Title of the Event <span class="text-danger">*</span></label>
												<div class="col-md-9">
													<input type="text" class="form-control validate" id="title" name="title" placeholder="Enter a Title.." required>
												</div>
											</div>
										</div>
										<div class="col-md-5">
											<div class="form-group row">
												<label class="col-md-6 col-form-label" for="val-sstadate-atartdate-time">Start Date & Time <span class="text-danger">*</span></label>
												<div class="col-md-9">
												<div class="input-group date" id="id_0">
													<input type="text" class="form-control" name="start_date_time" id="start_date_time" placeholder="Start Date and Time Here*">
													<div class="input-group-addon input-group-append">
														<div class="input-group-text">
															<i class="glyphicon glyphicon-calendar fa fa-calendar"></i>
														</div>
													</div>
												</div>
													<!-- <input type="text" class="form-control validate" id="start_date_time" name="start_date_time" placeholder="Enter a Date format of : Y-m-d H:i:s" required> -->
												</div>
											</div>
										</div>
										
										<div class="col-md-5">
											<div class="form-group row">
												<label class="col-md-6 col-form-label" for="val-enddate-time">End Date & Time <span class="text-danger">*</span></label>
												<div class="col-md-9">
												<div class="input-group date" id="id_1">
													<input type="text" class="form-control" name="end_date_time" id="end_date_time" placeholder="End Date and Time Here*">
													<div class="input-group-addon input-group-append">
														<div class="input-group-text">
															<i class="glyphicon glyphicon-calendar fa fa-calendar"></i>
														</div>
													</div>
												</div>
													<!-- <input type="text" class="form-control validate" id="end_date_time" name="end_date_time" placeholder="Enter a Date format of : Y-m-d H:i:s" required> -->
												</div>
											</div>
										</div>
										<div class="col-md-12">
											<div class="form-group row">
												<label class="col-md-12 col-form-label" for="val-event-org">Event Organizer<span class="text-danger">*</span></label>
												<div class="col-md-9">
													<input type="text" class="form-control validate" id="event_organizer" name="event_organizer" placeholder="Enter Event Organizer" required>
												</div>
											</div>
										</div>
										<div class="col-md-12">
											<div class="form-group row">
												<label class="col-md-12 col-form-label" for="val-reg-link">Registration Link<span class="text-danger">*</span></label>
												<div class="col-md-9">
													<input type="text" class="form-control validate" id="registration_link" name="registration_link" placeholder="Enter a Registration Link" required>
												</div>
											</div>
										</div>
										<div class="col-md-12">
											<div class="form-group row">
												<label class="col-md-12 col-form-label" for="val-online-event">Link for Join the Online event  <span class="text-danger">*</span></label>
												<div class="col-md-9">
													<input type="text" class="form-control validate" id="join_event_link" name="join_event_link" placeholder="Enter Join Event Link.." required>
												</div>
											</div>
										</div>
										<div class="col-md-12">
											<div class="form-group row">
												<label class="col-md-12 col-form-label" for="val-video-link">Recorded Video Link <span class="text-danger">*</span></label>
												<div class="col-md-9">
													<input type="text" class="form-control validate" id="video_link" name="video_link" placeholder="Enter a video link" required>
												</div>
											</div>
										</div>
										<div class="col-md-12">
											<div class="form-group row">
												<label class="col-md-12 col-form-label" for="val-feedback">Feedback Form Link <span class="text-danger">*</span></label>
												<div class="col-md-9">
													<input type="text" class="form-control validate" id="feedback_link" name="feedback_link" placeholder="Enter Feedback Form Link" required>
												</div>
											</div>
										</div>
										<div class="col-md-12">
											<div class="form-group row">
												<label class="col-md-12 col-form-label" for="val-feedback">Staff/Speaker Name <span class="text-danger">*</span></label>
												<div class="col-md-9">
													<input type="text" class="form-control validate" id="staff_name" name="staff_name" placeholder="Enter Staff Name" required>
												</div>
											</div>
										</div>
										
										<div class="col-md-12">
											<div class="form-group row ">
												<label class="col-md-12 col-form-label" for="val-staff-details"> Details of Staff/Speaker  <span class="text-danger">*</span></label>
												<div class="col-md-9">
													<textarea type="text" class="form-control" rows="5" id="staff_details" name="staff_details" placeholder="Staff Details " required></textarea>
												</div>
											</div>
										</div>
										<div class="col-md-12">
											<div class="form-group row ">
												<label class="col-md-12 col-form-label" for="val-about-event"> About this event  <span class="text-danger">*</span></label>
												<div class="col-md-9">
													<textarea type="text" class="form-control" rows="5" id="event_details" name="event_details" placeholder="About this event " required></textarea>
												</div>
											</div>
										</div>
										<div class="col-md-12">
											<div class="form-group row">
												<label class="col-md-12 col-form-label" for="val-feedback">Event Organizer Name <span class="text-danger">*</span></label>
												<div class="col-md-9">
													<input type="text" class="form-control validate" id="organizer_name" name="organizer_name" placeholder="Enter Event Organizer name" required>
												</div>
											</div>
										</div>
										<div class="col-md-12">
											<div class="form-group row">
												<label class="col-md-12 col-form-label" for="val-feedback">Event Organizer Mobile <span class="text-danger">*</span></label>
												<div class="col-md-9">
													<input type="text" class="form-control validate" id="staff_phone" name="staff_phone" placeholder="Enter Organizer Mobile number" required>
												</div>
											</div>
										</div>
										<div class="col-md-12">
											<div class="form-group row">
												<label class="col-md-12 col-form-label" for="val-feedback">Event Organizer Email <span class="text-danger">*</span></label>
												<div class="col-md-9">
													<input type="email" class="form-control validate" id="staff_email" name="staff_email" placeholder="Enter Organizer email" required>
												</div>
											</div>
										</div>

										<div class="col-md-6">
											<div class="form-group row ">  
													<label class="col-md-12 col-form-label" >Upload Invitation/Brochure <span class="text-danger">*</span></label>
													<div class="col-md-9">
														 <input type="file" id="invitation_brochure" name="invitation_brochure" accept="application/pdf" required>
													</div>
											</div>
										</div>
										
										<div class="col-md-6">
											<div class="form-group row ">
													<label class="col-md-12 col-form-label" >Upload the Photo of Staff/Speaker <span class="text-danger">*</span></label>
													<div class="col-md-9">
														 <input type="file" id="staff_photo" name="staff_photo" required>
													</div>
											</div>
										</div>
										
										<div class="col-md-12">
											<div class="form-group row ">
													<label class="col-md-12 col-form-label" >Upload banner image <span class="text-danger">*</span></label>
													<div class="col-md-9">
														 <input type="file" id="banner_image" name="banner_image" required>
													</div>
											</div>
										</div>
								
										<div class="col-md-12">
                                            <div class="form-group row ">
                                                <label class="col-md-12 col-form-label" for="val-add-webinar"> &nbsp; </label>
                                                <div class="col-md-9">
                                                    <button type="submit" name="submit" value="Upload" class="btn btn-primary">Add Webinar</button>
                                                </div>
                                            </div>
                                        </div>

									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- End PAge Content -->
		</div>
		<!-- End Container fluid  -->
		<?php include "footer.php"; ?>
<script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.10.0/jquery.validate.js" type="text/javascript">
</script>  
<script type="text/javascript">  

			$(document).ready(function () {
				$("#add_webinar").validate({
					rules: {
						status: "required",
						title: "required",
						staff_details: "required",
						file: "required",
					},
					 messages: {
					 	status: "Please select status from list",
           				 title : "Please enter the title",
						staff_details: "Please enter the staff detail",
						file: "Please Upload the pdf file"
					}
				});     
			}); 
		</script>
		

		<!--======== SCRIPT FILES =========-->
		<script src="js/bootstrap.min.js"></script>
		<script src="js/materialize.min.js"></script>
		<script src="js/custom.js"></script>
		
 <script src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/moment-with-locales.min.js"></script>
<script type="text/javascript" src="js/bootstrap-datetimepicker.min.js"></script>
<script type="text/javascript" src="js/dtpicker.js"></script>
<script crossorigin="anonymous" src="js/jquery-3.2.1.min.js"></script>
