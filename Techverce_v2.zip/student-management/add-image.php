
<?php
include "header.php";
include "left-menu.php";

if(isset($_POST['submit'])) {

    $small_width = 700;
    $small_height = 467;
    $med_width = 500;
    $med_height = 386;
    $large_width = 370;
    $large_height = 250;
    $upload_dir_small = '../gallery/small/';
    $upload_dir_med = '../gallery/medium/';
    $upload_dir_large = '../gallery/large/';
    $targetDir = "../gallery/";
    $allowTypes = array('jpg','png','jpeg');

    $statusMsg = $successMsg = $errorUpload = $errorUploadType = '';
 
 printArray($_FILES['files']);
    if(!empty(array_filter($_FILES['files']['name']))) {
        foreach($_FILES['files']['name'] as $key => $val) {
        	$temp = explode(".", $_FILES['files']['name'][$key]);
        	$fileName = generateSeoURL($_POST['catname']).'-'.round(microtime(true)) . '.' . end($temp);        	
            $targetFilePath = $targetDir.$fileName;
            $fileType = pathinfo($targetFilePath,PATHINFO_EXTENSION);
            if(in_array($fileType, $allowTypes)) {
                if(move_uploaded_file($_FILES["files"]["tmp_name"][$key], $targetFilePath)) {
                    createThumbnail($fileName, $small_width, $small_height, $targetDir, $upload_dir_small);
                    createThumbnail($fileName, $med_width, $med_height, $targetDir, $upload_dir_med);
                    createThumbnail($fileName, $large_width, $large_height, $targetDir, $upload_dir_large);
                    $formdata = dbRowInsert('tbl_galleries', array(               
                        "catId"=>$_POST['categoryName'],
                        "smallImg"=>$fileName,
                        "mediumImg"=>$fileName,
                        "largeImg"=>$fileName,
                        "createdDate" =>date('Y-m-d H:i:s'), 
                        "createdBy" =>$_SESSION['userType']['name']
                    ));
                    $successMsg = "success";
                } else {
                    $errorUpload .= $_FILES['files']['name'][$key].', ';
                }
            } else {
                $errorUploadType .= $_FILES['files']['name'][$key].', ';
            }
        }
    } else {
        $statusMsg = 'Please select a file to upload.';
    }
    if($successMsg == "success") {
        ?>
        <script>
            alert('Images added succefully!')
            window.location.href='add-image.php'
        </script>
        <?php
    }
    echo $statusMsg;
}


$id = isset($_GET['id']) ? $_GET['id'] : '';
if(isset($_GET['action']) == "delete") {
	dbRowDelete('tbl_galleries', "id = '".$id."'");
	echo "<script>
	alert('Category is deleted sucessfully!')
	window.location.href='add-image.php'
	</script>";

}

$result_aray = selectQryToAray("SELECT * FROM tbl_image_category ORDER BY id ASC");
?>
<div class="page-wrapper">
	<!-- Bread crumb -->
	<div class="row page-titles">
		<div class="col-md-5 align-self-center">
			<h3 class="text-primary">Category</h3> </div>
			<div class="col-md-7 align-self-center">
				<ol class="breadcrumb">
					<li class="breadcrumb-item"><a >Home</a></li>
					<li class="breadcrumb-item active">Dashboard</li>
				</ol>
			</div>
		</div>
		<!-- End Bread crumb -->
		<!-- Container fluid  -->
		<div class="container-fluid">
			<!-- Start Page Content -->
			<h2 style="text-align: center;">Category</h2>
			<div class="row justify-content-center">
				<div class="col-lg-12">
					<div class="card">
						<div class="card-body">
							<div class="form-validation">
								<form action="#" method="post" name="image_upload" id="image_upload" enctype="multipart/form-data">									
									<div class="col-md-6">
										<div class="form-group row ">
											<label class="col-md-12 col-form-label" for="val-email">Category<span class="text-danger">*</span></label>
											<div class="col-md-9">
												<select class="form-control" name="categoryName" id="categoryName">
													<option value="">Select</option>
													<?php foreach ($result_aray as $value) { ?>
    													<option value=<?php print $value['id']?> catname="<?php print $value['catName']?>">
    														<?php print $value['catName']; ?>
    													</option>
													<?php } ?>
												</select>
												<input type="hidden" name="catname" id="catname" value="">
											</div>
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group row ">
											<div class="col-md-9">
												<input type="file" name="files[]" id="files" multiple  accept="image/gif, image/jpeg" >
												<input type="submit" name="submit" value="Save Images">
											</div>
										</div>
									</div>
								</form>
								<div class="table-responsive m-t-40">
									<form method="POST" action="#" id="add_news" name="edit">
										<h2>Category Lists</h2>
										<table id="myTable" class="display nowrap table table-hover table-striped table-bordered" cellspacing="0" width="100%"> 
											<thead>
												<tr>
													<th>S.no</th>
													<th>Category Name</th>
													<th>Action</th>
												</tr>
											</thead>
											<tbody>
                                                <?php
                                                $i = 1;
                                                foreach ($result_aray as $row) {
                                                    ?>
                                                    <tr>
                                                        <td><?php print $i++; ?></td>
                                                        <td><?php print $row['catName']; ?></td>
                                                        <td>
                                                            <a class=" fix-sidebar" href="view-image.php?id=<?php print $row['id'] ?> ">
                                                                <i class="fa fa-eye" title="View" style="color:blue; font-size:17px;"></i>
                                                            </a>
                                                                &nbsp;&nbsp;
                                                            <!-- <a class="fix-sidebar" href="image-edit.php?id=<?php print $row['id'] ?> ">
                                                                <i class="fa fa-pencil" title="Edit" style="color:#1c8fb7;font-size:17px;"></i>
                                                            </a> -->
                                                            &nbsp;&nbsp;
                                                            <a class="confirmation fix-sidebar" href="?id=<?php print $row['id'] ?>&action=delete"> 
                                                                <i class="fa fa-trash" style="color:red;" title="delete" aria-hidden="true"></i>
                                                            </a>
                                                            
                                                                </td>
                                                            </tr>
                                                            <?php
                                                        }
                                                        ?>
													</tbody>
												</table>
											</form>

										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<!-- End PAge Content -->
				</div>
				<!-- End Container fluid  -->
				<?php include "footer.php"; ?>

				<script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.10.0/jquery.validate.js" type="text/javascript">
				</script>  
				<script type="text/javascript">

					$(document).ready(function () {
						$("#image_upload").validate({
							rules: {
								categoryName: "required",
								files:"required"
							},					 
							messages: {
								categoryName :"Please select the Category ",
							},    
							submitHandler: function(form) {
								form.submit();
							}
						}); 
                        $('#categoryName').on('change', function() {
                            var element = $(this).find('option:selected'); 
        					var myTag = element.attr("catname"); 
                            $("#catname").val(myTag)
                        });
					});

				</script>

				<!--======== SCRIPT FILES =========-->
				<script src="js/bootstrap.min.js"></script>
				<script src="js/materialize.min.js"></script>
				<script src="js/custom.js"></script>