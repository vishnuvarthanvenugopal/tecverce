<?php 
include "header.php";
include "left-menu.php";

$id = isset($_GET['id']) ? $_GET['id'] : '';

$action = (isset($_GET["action"])) ? $_GET["action"] : "";

if(isset($_GET['action']) == "edit") {
    $query = "SELECT * FROM tbl_image_category WHERE id ='$id'";
    $result = mysqli_query($connection,$query) or die(mysqli_error());
    $row = mysqli_fetch_assoc($result);    
}
$success = false;

if($id == "" && isset($_POST["submit"])) {
    $insertdata = dbRowInsert('tbl_image_category', array(
        'catName'=>$_POST['catName'],
        'gallery_url'=>generateSeoUrl($_POST['catName']),
        'sortOrder'=> $_POST['sortOrder'],
        'status'=> $_POST['status'],
        'createdDate' =>date('Y-m-d H:i:s'), 
        'createdBy' =>$_SESSION['userType']['name'], 
    ));

    //$last_insert_id = dbRowInsert('tbl_image_category', $insertdata);   
    $success = true;
} 
if(isset($_POST["submit"]) && $action == "edit") {
    $formData = array(
        'catName'=>$_POST['catName'],
         'gallery_url'=>generateSeoUrl($_POST['catName']),
        'sortOrder'=> $_POST['sortOrder'],
        'status'=> $_POST['status']
    );
    dbRowUpdate('tbl_image_category', $formData, "id = '".$id."'");
    $success = true;
}

if($success == true) {
    echo "<script>
    alert('Category saved succefully!')
    window.location.href='add-category.php'
    </script>";
}

/*
*** delete
*/
if($action == "delete") {
	
    dbRowDelete('tbl_image_category', "id = '".$id."'");
    echo "<script>
          alert('Category is deleted sucessfully!')
          window.location.href='add-category.php'
          </script>";
        
}

?>   
<!-- End header header -->
<!-- Page wrapper  -->
<div class="page-wrapper">
	<!-- Bread crumb -->
	<div class="row page-titles">
		<div class="col-md-5 align-self-center">
			<h3 class="text-primary">Category</h3> </div>
			<div class="col-md-7 align-self-center">
				<ol class="breadcrumb">
					<li class="breadcrumb-item"><a >Home</a></li>
					<li class="breadcrumb-item active">Dashboard</li>
				</ol>
			</div>
		</div>
		<!-- End Bread crumb -->
		<!-- Container fluid  -->
		<div class="container-fluid">
			<!-- Start Page Content -->
			<h2 style="text-align: center;">Category</h2>

			<div class="row justify-content-center">
				<div class="col-lg-12">
					<div class="card">
						<div class="card-body">
							<div class="form-validation">
								<form method="POST" action="#" id="add_news" name="fileUpload" enctype="multipart/form-data">
									<div class="row">
										<div class="col-md-6">
											<div class="form-group row">
												<label class="col-md-12 col-form-label" for="val-username">Category Name <span class="text-danger">*</span></label>
												<div class="col-md-9">
													<input type="text" class="form-control validate" id="catName" name="catName" placeholder="Enter a Category Name.." value="<?php echo isset($row['catName']) ? $row['catName'] : ""; ?>" required>
												</div>
											</div>
										</div>

										<div class="col-md-6">
											<div class="form-group row">
												<label class="col-md-12 col-form-label" for="val-username">Sorting Order<span class="text-danger">*</span></label>
												<div class="col-md-9">
													<input type="text" class="form-control validate numeric" id="sortOrder" name="sortOrder" value="<?php echo isset($row['sortOrder']) ? $row['sortOrder'] : ""; ?>" placeholder="Enter a Number" minlength="1" maxlength="3" required>
												</div>
											</div>
										</div>
										
										<div class="col-md-6">
											<div class="form-group row ">
												<?php 
												$status = "";
												if(isset($row['status'])) {
													$status = $row['status'];
												}
												?>
												<div class="col-md-9">
													<label>Status: 
													<input type="radio" name="status" value="ACTIVE"> 
													<?php echo ($status == "ACTIVE") ? "checked" : "" ?>
													Active

													<input type="radio" name="status" value="INACTIVE">
													<?php echo ($status == "INACTIVE") ? "checked" : "" ?>
													  Inactive
													  </label>

												</div>
											</div>
										</div>

										<div class="col-md-12" style="text-align: center;" id="submit-cat" >
											<div class="form-group row">
												<div class="col-lg-12 ml-auto">
													<button type="submit" name="submit" value="submit" class="btn btn-primary">Save category</button>
												</div>
											</div>
										</div>

									</div>
								</form>

								<div class="table-responsive m-t-40">
									<form method="POST" action="#" id="add_news" name="edit">
										<h2>Category Lists</h2> 

										<table id="myTable" class="display nowrap table table-hover table-striped table-bordered" cellspacing="0" width="100%"> 
											<thead>
												<tr>
													<th>S.no</th>
													<th>Category Name</th>
													<th>Sorting Order</th>
													<th>Status</th>
													<th>Action</th>

												</tr>
											</thead>
											<tbody>
												<?php
												$cat_result_aray = mysqli_query($connection,"SELECT * FROM tbl_image_category ORDER BY id ASC") or die(mysqli_error());
												$i = 1;
												while($row = mysqli_fetch_array( $cat_result_aray )) 
												{
													echo "<tr>";
													echo '<td>' . $i++ . '</td>';
													echo '<td>' . $row['catName'] . '</td>';
													echo '<td>' . $row['sortOrder'] . '</td>';
													echo '<td>' . $row['status'] . '</td>';
													echo '<td>

													<a href="?id='.$row['id'].'&action=edit"> 
													<i class="fa fa-pencil" title="Edit" style="color:gupnp_service_freeze_notify(service);font-size:17px;"></i></a>					
													&nbsp;&nbsp;
													<a href="?id='.$row['id'].'&action=delete"> 
													<i class="fa fa-trash" style="color:red;" title="delete" aria-hidden="true"></i>
													</a>
													&nbsp;&nbsp;
													</td>'; 
													echo "</tr>";

												}
												?>
											</tbody>
										</table>
									</form>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- End PAge Content -->
		</div>
		<!-- End Container fluid  -->
		<?php include "footer.php"; ?>
		<script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.10.0/jquery.validate.js" type="text/javascript">
		</script>  
		<script type="text/javascript">  
			$(document).on("input", ".numeric", function() {
			    this.value = this.value.replace(/\D/g,'');
			});
			$(document).ready(function () {
				$("#add_news").validate({
					rules: {
						catName: "required",
						sortOrder: "required",
						status: "required",

					},
					 errorPlacement: function(error, element) {
	             		if ( element.is(":radio") ) {
	               
	           				 error.insertAfter( element.parent().parent());
	        				}
       				 else { // This is the default behavior of the script for all fields
           				 error.insertAfter( element );
       						 }
    				},
					messages: {

						catName : "Please enter the Category ",
						sortOrder: "Please enter the Number",
						status:  "Please select status type."
					},    
					submitHandler: function(form) {
						form.submit();
					}
				});
				
				});
			
		
 
		</script>
		

		<!--======== SCRIPT FILES =========-->
		<script src="js/bootstrap.min.js"></script>
		<script src="js/materialize.min.js"></script>
		<script src="js/custom.js"></script>