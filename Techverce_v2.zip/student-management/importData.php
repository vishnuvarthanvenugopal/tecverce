<?php include "connect.php"; 
if(isset($_POST['importsubmit'])){
    //validate whether uploaded file is a csv file
    $csvMimes = array('text/x-comma-separated-values', 'text/comma-separated-values', 'application/octet-stream', 'application/vnd.ms-excel', 'application/x-csv', 'text/x-csv', 'text/csv', 'application/csv', 'application/excel', 'application/vnd.msexcel','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    if(!empty($_FILES['file']['name']) && in_array($_FILES['file']['type'],$csvMimes)){
        if(is_uploaded_file($_FILES['file']['tmp_name'])){   
            $csv = array_map("str_getcsv", file($_FILES['file']['tmp_name'],FILE_SKIP_EMPTY_LINES));
            $keys = array_shift($csv);
            foreach ($csv as $i=>$row) {
                $csv[$i] = array_combine($keys, $row);
            }
            $totalrows = count($csv);
            //echo '<pre>';//print_r($csv);exit;
            if($totalrows > 0) {
                foreach ($csv as $col => $val) {   
                    $prevResult = checkStudentExists($val["REGISTER NO"]);
                    if($prevResult == 0 && $val['NAME OF THE STUDENT'] != null) {
                     $date = implode("-",array_reverse(explode('.', $val['DOB'])));
                     $studentType = $val['H / DS'];
                        $formData = array(
                            'applicationNumber' => $val['Appliction Number'],
                            'firstName' => $val['NAME OF THE STUDENT'],
                            "lastName" => "",
                            "registerNumber" => $val['REGISTER NO'],
                            "dateOfBirth" => $date,//date("Y-m-d",strtotime($val['DOB'])), //$val['DOB'],
                            "department" => $val['DEPARTMENT'],
                            "yearOfStudying" => $val['YEAR'],
                            "yearOfJoining" => $val['YEAR OF JOINING'],
                            "emailId" => $val['E-MAIL ID'],
                            "mobile" => $val['PHONE NUMBER'],
                            "address" => $val['ADDRESS'],
                            "quota" => $val['GQ / MQ'],
                            "studentType" => $studentType,
                            "password" => 'welcome'
                        );
                        
                        //print_r($formData);
                        
                        $last_insert_id = dbRowInsert('student', $formData);

                        // $travelHostelDue = ($studentType == "H") ? $val['hostel Due'] : $val['Tra. Due'];

                        // $travel_hos_food = ($studentType == "H") ? $val['Hostel Fee'] :$val['Transport & Food / Hostel Fee'];
                        

                        $student_fees_aray = array(
                            "studentId" =>  $last_insert_id,
                            "tutionFees" => $val['Tuition and R&D Fees'],
                             "hostelFees" => $val['Transport & Food / Hostel Fee'],
                            "previoustutionDue" => $val['Previous Tut fees due '],
                            "previoushostelDue" => $val['Previous hos  /Transport fees due'],
                            "firstGrConcession" => $val['I GR Concession'],
                            "scTutionFeeConcession" => $val['SC Tuition Fees Concession'],
                            "totalFees" => $val['Total Fees'],
                            "finaltutionfee" => $val['Final Tution/R&D Fee'],
                            "finalhostelfee" => $val['Final  Hos/Transport Fee'],
                            "totalFeesDue" => $val['Total Fees with Previous Dues'],
                            "tutionFeeDue" => ($val['Tuition and R&D Fees'] -($val['I GR Concession']+$val['SC Tuition Fees Concession'])-($val['Paid Tut/R&D Fee'])),
                            "travelHostelDue" => $val['Transport & Food / Hostel Fee']-$val['Paid Hos/Transport Fee'],
                            "pretutionFeeDue" => $val['Previous Tut fees due ']-$val['paid Pre Tut/R&D Fee'],
                            "pretravelHostelDue" => $val['Previous hos  /Transport fees due ']-$val['Paid Pre Hos/Transport Fee']
                            
                        );
                        dbRowInsert('studentfees', $student_fees_aray);
                        // if($val['Paid'] != 0){
                        //     if($val['Pending'] == 0){
                        //          $paid_tutition_fee  = $val['Tuition Fees'];
                        //          $paid_hostel_fee = $travel_hos_food;
                        //     }
                        //     else{
                        // $pending_hos_food = ($studentType == "H") ? $val['hostel Due'] :$val['Tra. Due'];
                        //         $paid_tutition_fee = $val['Tuition Fees'] - $val['Tuition fee Due'];
                        //          $paid_hostel_fee = $travel_hos_food - $pending_hos_food ;
                        //     }
                        
                        if($val['Paid Tut/R&D Fee'] && $val['Paid Hos/Transport Fee'] && $val['paid Pre Tut/R&D Fee'] && $val['Paid Pre Hos/Transport Fee']){
                            $paid_data =  array( 
                                'student_id' => $last_insert_id,
                                'firstName' => $val['NAME OF THE STUDENT'],
                                "mobile" => $val['PHONE NUMBER'],
                                "email" => $val['E-MAIL ID'],
                                "payment_mode" => "CASH",
                                "tutition_fee" =>  $val['Paid Tut/R&D Fee'],
                                "hos_dys_fee" => $val['Paid Hos/Transport Fee'],
                                "pre_tutition_fee"=> $val['paid Pre Tut/R&D Fee'],
                                "pre_hos_dys_fee" => $val['Paid Pre Hos/Transport Fee'],
                                "payment_status" => "SUCCESS"
                            );
                        }
                        
                            dbRowInsert('payment_history',$paid_data);
                        }
                    }
                    
                    
                
            }           
            $qstring = '?status=succ';
        } else {
            $qstring = '?status=err';
        }
    } else {
        $qstring = '?status=invalid_file';
    }
}
header("Location: student-details.php".$qstring);
?>
