
<?php include "header.php";
include "left-menu.php";
if(isset($_POST['submit'])) {
	$name = filter($_POST['name']);
	$email = filter($_POST['email']);
	$password = MD5($_POST['password']);
	$userType = filter($_POST['userType']);
	$status = filter($_POST['status'])	;    
	$createdBy = filter($_SESSION['userType']['name']);
	$query = "INSERT INTO `admin_login`(name,email,password,userType,status,createdBy ) VALUES('$name','$email','$password','$userType','$status','$createdBy')";
	$result = mysqli_query($connection, $query);
	echo "<script>
		alert('Admin account has been created!');
		window.location.href='admin.php'
	</script>";
}
?> 
<!-- End header header -->
<!-- Page wrapper  -->
<div class="page-wrapper">
	<!-- Bread crumb -->
	<div class="row page-titles">
		<div class="col-md-5 align-self-center">
			<h3 class="text-primary">Add ADMIN</h3> </div>
			<div class="col-md-7 align-self-center">
				<ol class="breadcrumb">
					<li class="breadcrumb-item"><a >Home</a></li>
					<li class="breadcrumb-item active">Dashboard</li>
				</ol>
			</div>
		</div>
		<!-- End Bread crumb -->
		<!-- Container fluid  -->
		<div class="container-fluid">
			<!-- Start Page Content -->
			<h2 style="text-align: center;"> ADMIN</h2>

			<div class="row justify-content-center">
				<div class="col-lg-12">
					<div class="card">
						<div class="card-body">
							<div class="form-validation">
								<form class="form-valide" id="add_usr_frm" method="post">
									<div class="row">
										<div class="col-md-6">
											<div class="form-group row">
												<label class="col-md-12 col-form-label" for="val-username">Username <span class="text-danger">*</span></label>
												<div class="col-md-9">
													<input type="text" oninput="this.value = this.value.replace(/[^A-Za-z.]/g, '').replace(/(\..*)\./g, '$1');" class="form-control validate" id="name" name="name" placeholder="Enter a username.." >
												</div>
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group row ">
												<label class="col-md-12 col-form-label" for="val-email">Email <span class="text-danger">*</span></label>
												<div class="col-md-9">
													<input type="text" class="form-control" id="email" name="email" placeholder="Your valid email.." >
												</div>
											</div>
										</div>

										<div class="col-md-6">
											<div class="form-group row ">
												<label class="col-md-12 col-form-label" >Password <span class="text-danger">*</span></label>
												<div class="col-md-9">
													<input type="password" class="form-control" id="password" name="password" placeholder="Password" >
												</div>
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group row ">
												<label class="col-md-12 col-form-label" >USER TYPE <span class="text-danger">*</span></label>
												<div class="col-md-9">
													<select class="form-control" id="userType" name="userType" >
														<option value="" >-- SELECT TYPE--  </option>
														<option value="SUPERADMIN">SUPERADMIN</option>
														<option value="ADMIN" selected="selected">ADMIN</option>
														<option value="ACCOUNTANT">ACCOUNTANT</option>
														<option value="USER" selected="">USER</option>
													</select>
												</div>
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group row ">
												<label class="col-md-12 col-form-label" for="val-email">STATUS <span class="text-danger">*</span></label>
												<div class="col-md-9">
													<select class="form-control" name="status">
														<option value="" >Status  </option>
														<option value="ACTIVE" selected="selected">Active</option>
														<option value="INACTIVE">InActive</option>  
													</select>
												</div>
											</div>
										</div>
										<div class="col-md-6">
										</div>
										<div class="col-md-12">
										<div class="form-group row">
											<div class="col-md-12 ml-auto">
												<p style="text-align: center;"><button type="submit" name="submit" class="btn btn-primary">Submit</button></p>
											</div>
										</div>
									</div>
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- End PAge Content -->
		</div>
		<!-- End Container fluid  -->
		<?php include "footer.php"; ?>
		<!-- Form validation -->
 <script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.10.0/jquery.validate.js" type="text/javascript"></script>
      <script  type="text/javascript">
        $(document).ready(function () {
          $("#add_usr_frm").validate({
            rules: {
              name: "required",
              userType: "required",
              status: "required",
              phone: {
                required:true,
                minlength:10,
                maxlength:10,
                number: true
              },
              email: {
                required: true,
                email: true
              },                      
              password: {
                required:true,
                minlength:6,
                maxlength:15
              },

            },
            messages: {
              name: "Please enter Name",
              userType: "Please select User Type from List",
              status: "Please select User Status from List",
              phone: {
                required:"Enter Mobile number",
                minlength:"10 digits only",
                maxlength:"10 digits only",
                number: "Enter number only!",
              },                      
              email: {
                required:"Please enter email ID",
                email:"Enter a valid email ID",
                remote: "Email already in use!",
              },
              password: {
                required:"Enter correct password",
                minlength:"Please enter 6 digits minimum",
                maxlength:"Please enter 15 digits maximum",

              }, 

            },    
            submitHandler: function(form) {
              form.submit();
            }
          });     
        }); 
      </script>
		<!--======== SCRIPT FILES =========-->
		<!-- <script src="js/bootstrap.min.js"></script>
		<script src="js/materialize.min.js"></script>
		<script src="js/custom.js"></script> -->