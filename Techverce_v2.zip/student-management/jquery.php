<span id="dummy">5</span>
		  <input type="text" id="qty_10" name="qty" value="5" style="display:none"/>

		<span class="label wk_action" id="edit_link_10">
				<img width="25" onclick="showField('10')" src="https://cdn4.iconfinder.com/data/icons/miu/22/editor_pencil_pen_edit_write_-128.png"/>
			</span>  

			<br/>
			<button id="update_button_10" class="button wk_mp_btn1" onclick="updateField('10');" style="display:none" >
				<span><span style="font-size:12px;">Update</span></span>
			</button>

			<button id="reset_button_10" type="reset" class="cancel" onclick="hideReset('10');" style="display:none">
				<span><span>Cancel</span></span>
			</button>

<script>

				var $wk_jq=jQuery.noConflict();

			function hideReset(product_id) {
                var qtyId='#qty_'+ product_id;

                var editLink="#edit_link_"+ product_id;
                var updateButton="#update_button_"+ product_id;
                var resetButton="#reset_button_"+ product_id;

                $wk_jq(qtyId).hide();

                $wk_jq(editLink).show();
                $wk_jq(updateButton).hide();
                $wk_jq(resetButton).hide();
            }
			
            function showField(product_id)
            {
                var qtyId='#qty_'+ product_id;

                var editLink="#edit_link_"+ product_id;
                var updateButton="#update_button_"+ product_id;
                var resetButton="#reset_button_"+ product_id;

                $wk_jq(qtyId).show();

                $wk_jq(editLink).hide();
                $wk_jq(updateButton).show();
                $wk_jq(updateButton).prop('disabled', false);//just in case
                $wk_jq(resetButton).show();
            }
			
            function updateField(product_id)
            {
                var qtyId='#qty_'+ product_id;
				
                var qty = $wk_jq(qtyId).val();
				
				var $updateButton = $wk_jq("#update_button_"+ product_id);
				

				//disable it after start
				$updateButton.prop('disabled', true);
				
				//simulate 1 second ajax request
				setTimeout(function() {
					$wk_jq('#dummy').text(qty);
					//do you really want to reset this after? decide
					hideReset(product_id);
					
					//enable it after complete whether success or failure
					$updateButton.prop('disabled', false);
				}, 1000);

            }
        </script>