<?php include "connect.php"; 
	$id=$_REQUEST['id'];
	$select_news=dbRowDelete('tbl_news_events', "id = '".$id."'");
		if($select_news)
		{
			echo "<script>
		  alert('News has been deleted!')
		  window.location.href='news-lists.php'
		  </script>";
		}
		else
		{
			echo "Delete Process Failed";
		}
?>