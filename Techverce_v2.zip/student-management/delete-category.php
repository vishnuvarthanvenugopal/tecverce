<?php include "connect.php"; 
	$id=$_REQUEST['id'];
	$select_news=dbRowDelete('tbl_image_category', "id = '".$id."'");
		if($select_news)
		{
			echo "<script>
		  alert('Category is deleted sucessfully!')
		  window.location.href='add-category.php'
		  </script>";
		}
		else
		{
			echo "Delete Process Failed";
		}
?>