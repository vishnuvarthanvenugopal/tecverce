
<?php 
include 'header.php';
include 'left-menu.php';
$regno = $_GET["reg"];
        $sql = "SELECT * FROM student WHERE registerNumber ='".trim($regno)."'";
        $stdqry = mysqli_query($connection,$sql) or die(mysql_error());
        $row = mysqli_fetch_assoc($stdqry);     



?>
<!-- End header header -->
<!-- Page wrapper  -->
<div class="page-wrapper">
    <!-- Bread crumb -->
    <div class="row page-titles">
      <div class="col-md-5 align-self-center">
        <h3 class="text-primary">STUDENT DETAILS</h3> </div>
        <div class="col-md-7 align-self-center">
          <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
              <li class="breadcrumb-item active">Dashboard</li>
          </ol>
      </div>
  </div>
  <!-- End Bread crumb -->
  <!-- Container fluid  -->
  <div class="container-fluid">
    <!-- Start Page Content -->
    <h2 style="text-align: center;"> STUDENT DETAILS</h2>
    <div class="row justify-content-center">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <div class="form-validation">
                        <form class="form-valide" action="#" id="student_form" method="post">
                            <div class="row">
                             <div class="col-md-6">
                                <div class="form-group row ">
                                    <label class="col-md-12 col-form-label" for="applicationNumber">Application Number <span class="text-danger">*</span></label>
                                    <div class="col-md-9">
                                        <input type="text" class="form-control" id="applicationNumber" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" value="<?php echo $row['applicationNumber']; ?>" name="applicationNumber" placeholder="Student application no">
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row ">
                                    <label class="col-md-12 col-form-label" for="val-email">Quota<span class="text-danger">*</span></label>
                                    <div class="col-md-9">
                                        <select class="form-control" id="quota" name="quota">
                                            <option value="">Select</option>
                                            <option value="MANAGEMENTQUOTA" <?php echo ($row['quota'] == "MANAGEMENTQUOTA") ? "selected" : ""; ?>>Management Quota</option>
                                            <option value="GENERALQUOTA" <?php echo ($row['quota'] == "GENERALQUOTA") ? "selected" : ""; ?>>General Quota</option>
                                        </select>

                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row ">
                                    <label class="col-md-12 col-form-label" for="val-email">Student Type <span class="text-danger">*</span></label>
                                    <div class="col-md-9">
                                        <select class="form-control" id="studentType" name="studentType">
                                            <option value="">Select</option>
                                            <option value="HOSTEL" <?php echo ($row['studentType'] == "HOSTEL") ? "selected" : ""; ?>>Hostel</option>
                                            <option value="DAYSCHOLAR" <?php echo ($row['studentType'] == "DAYSCHOLAR") ? "selected" : ""; ?>>Day Scholar</option>
                                        </select>

                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-12 col-form-label" for="val-username">First Name <span class="text-danger">*</span></label>
                                    <div class="col-md-9">
                                        <input type="text" class="form-control" id="firstName" name="firstName" value="<?php echo $row['firstName'];?>" oninput="this.value = this.value.replace(/[^A-Za-z.]/g, '').replace(/(\..*)\./g, '$1');" placeholder="Enter a firstname" required>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row ">
                                    <label class="col-md-12 col-form-label" for="val-email">Last Name <span class="text-danger">*</span></label>
                                    <div class="col-md-9">
                                        <input type="text" class="form-control" id="lastName" name="lastName" value="<?php echo $row['lastName'];?>" oninput="this.value = this.value.replace(/[^A-Za-z.]/g, '').replace(/(\..*)\./g, '$1');" placeholder="Enter a lastname" required>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row ">
                                    <label class="col-md-12 col-form-label" for="val-email">Student Roll Number or Registration Number <span class="text-danger">*</span></label>
                                    <div class="col-md-9">
                                        <input type="text" class="form-control" id="registerNumber" name="registerNumber" placeholder="Number" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" value="<?php echo $row['registerNumber'];?>" required>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row ">
                                    <label class="col-md-12 col-form-label" for="val-email">Date Of Birth <span class="text-danger">*</span></label>
                                    <div class="col-md-9">
                                        <input type="date" class="form-control" id="dateOfBirth" name="dateOfBirth" placeholder="Your DOB" value="<?php echo $row['dateOfBirth'];?>" required>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row ">
                                    <label class="col-md-12 col-form-label" for="val-email">Department <span class="text-danger">*</span></label>
                                    <div class="col-md-9">
                                        <input class="form-control" id="department" name="department" value="<?php echo $row['department']; ?>" required>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row ">
                                    <label class="col-md-12 col-form-label" for="val-email">Year of Studying<span class="text-danger">*</span></label>
                                    <div class="col-md-9">
                                        <select class="form-control" id="yearOfStudying" name="yearOfStudying">
                                            <option value="">Select</option>
                                            <option value="I" <?php echo ($row['yearOfStudying'] == "I") ? "selected" : ""; ?>>First Year</option>
                                            <option value="II" <?php echo ($row['yearOfStudying'] == "II") ? "selected" : ""; ?>>Second Year</option>
                                            <option value="III" <?php echo ($row['yearOfStudying'] == "III") ? "selected" : ""; ?>>Third Year</option>
                                            <option value="IV" <?php echo ($row['yearOfStudying'] == "IV") ? "selected" : ""; ?>>Fourth Year</option>
                                        </select>

                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row ">
                                    <label class="col-md-12 col-form-label" for="val-email">Year Of Joining <span class="text-danger">*</span></label>
                                    <div class="col-md-9">
                                        <select name="yearOfJoining" class="form-control" id="yearOfJoining">
                                            <option value="" >Choose year of joining</option>
                                            <?php
                                            $currentYear = date("Y");
                                            for($i = "2010"; $i <= $currentYear; $i++) {
                                                ?>
                                                <option value="<?php echo $i; ?>" <?php echo ($row["yearOfJoining"] == $i) ? "selected" : ""; ?> ><?php echo $i; ?></option>
                                                <?php
                                            }

                                            ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row ">
                                    <label class="col-md-12 col-form-label" for="val-email">Email ID <span class="text-danger">*</span></label>
                                    <div class="col-md-9">
                                        <input type="text" class="form-control" id="val-email" name="emailId" value="<?php echo $row['emailId'];?>" placeholder="Your valid email" required>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row ">
                                    <label class="col-md-12 col-form-label" for="val-email">Phone Number <span class="text-danger">*</span></label>
                                    <div class="col-md-9">
                                        <input type="text" class="form-control" id="mobile" name="mobile" value="<?php echo $row['mobile'];?>" max-length="10" placeholder="Your phone number" required>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row ">
                                    <label class="col-md-12 col-form-label" for="mobile">Address<span class="text-danger">*</span></label>
                                    <div class="col-md-9">
                                        <textarea type="text" class="form-control" id="address" name="address"  placeholder="Student Address" value=""><?php echo $row['address']; ?></textarea>

                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">    
                                <div class="form-group row ">
                                    <label class="col-md-12 col-form-label" for="dueFees">Previous Due<span class="text-danger">*</span></label>
                                    <div class="col-md-9">
                                        <input type="text" class="form-control" id="previousDue" name="previousDue" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" placeholder="Previous Due" value="<?php echo $row1['previousDue'];?>" required>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group row ">
                                    <label class="col-md-12 col-form-label" for="val-email">Tuition Fees  <span class="text-danger">*</span></label>
                                    <div class="col-md-9">
                                        <input type="text" class="form-control" id="tutionFees" name="tutionFees" value="<?php echo $row1['tutionFees'];?>" placeholder="Tuition Fees" required>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">    
                                <div class="form-group row ">
                                    <label class="col-md-12 col-form-label" for="1st year GR Concession">1st year GR Concession<span class="text-danger">*</span></label>
                                    <div class="col-md-9">
                                        <input type="text" class="form-control" id="grconcession" name="firstGrConcession"oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" placeholder="1st year GR Concession" value="<?php echo $row1['firstGrConcession'];?>" required>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">    
                                <div class="form-group row ">
                                    <label class="col-md-12 col-form-label" for="SC Tution Fees Concession">SC Tution Fees Concession <span class="text-danger">*</span></label>
                                    <div class="col-md-9">
                                        <input type="text" class="form-control" id="tutionfeesconcession" name="scTutionFeeConcession" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" placeholder="SC tution fees concession " value="<?php echo $row1['scTutionFeeConcession'];?>" required>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row ">
                                    <label class="col-md-12 col-form-label" for="val-email">Fees<span class="text-danger">*</span></label>
                                    <div class="col-md-9">
                                        <input type="text" class="form-control" id="otherFees" name="hostelFees"  value="<?php echo $row1['hostelFees'];?>" placeholder="Hostel Fees" required>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6" id="">
                                <div class="form-group row ">
                                    <label class="col-md-12 col-form-label" for="Total Fees">Total Fees<span class="text-danger">*</span></label>
                                    <div class="col-md-9">
                                        <input type="text" class="form-control" id="totalFees" name="totalFees" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" value="<?php echo $row1['totalFees'];?>" placeholder="totalFees" required>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6" id="">
                                <div class="form-group row ">
                                    <label class="col-md-12 col-form-label" for="Total Fees with Previous Due">Total Fees with Previous Due<span class="text-danger">*</span></label>
                                    <div class="col-md-9">
                                        <input type="text" class="form-control" id="totalFeesdue" name="totalFeesdue" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" value="<?php echo $row1['totalFeesDue']; ?>" placeholder="totalFees" required>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-lg-8 ml-auto">
                                <button type="submit" id="update" name="update" class="btn btn-primary">Update</button>
                                <a href="student-details.php">
                                  <button type="button" name="submit" id="submit" class="btn btn-danger">
                                  Close</button></a>
                              </div>
                          </div>
                      </form>
                  </div>
              </div>
          </div>
      </div>
  </div>
  <!-- End PAge Content -->
</div>
<?php include "footer.php"; ?>
<script type="text/javascript">

    $(document).ready(function() {

        $(function() {            
            $('#studentType').change(function(){
                var studentType = $(this).val();
                if( studentType == 'DAYSCHOLAR') {
                    $('#hostelFees').attr("placeholder", "Day Scholar fees");
                } else {
                    $('#hostelFees').attr("placeholder", "Hostel fees"); 
                } 
            });
        });
        $("#tutionFees,#grconcession,#tutionfeesconcession,#otherFees,#dueFees").change(function() {
         var tutionFees =$("#tutionFees").val();

           //alert(tutionFees);
           var grconcession=$("#grconcession").val();
           var dueFees=$("#dueFees").val();

           var otherFees=$("#otherFees").val();
           //alert(grconcession);
           var tutionfeesconcession=$("#tutionfeesconcession").val();
           var totalfees=(parseFloat(tutionFees) - parseFloat(grconcession) - parseFloat(tutionfeesconcession)) + parseFloat(otherFees);
           $("#totalFees").val(totalfees);
           //alert(tutionfeesconcession);
           var totalAmt=(parseFloat(tutionFees)+parseFloat(dueFees)) - parseFloat(grconcession) - parseFloat(tutionfeesconcession) + parseFloat(otherFees);
           //alert(totalAmt);
           $("#totalFeesdue").val(totalAmt);
           
       });


        $("#student_form").validate({
            rules: {
                studentType : "required",
                firstName: "required",
                lastName: "required",
                registerNumber: "required",
                dateOfBirth:"required",
                department:"required",
                yearOfJoining:"required",
                mobile: {
                    required:true,
                    minlength:10,
                    maxlength:10,
                    number: true
                },
                emailId: {
                    required: true,
                    email: true
                },                      
                hostel: "required",
                tution: "required",
            },
            messages: {
                studentType : "Please select student type",
                firstName: "Please enter student firstname",
                lastName: "Please enter student lastname",
                registerNumber : "Please enter student register no",

                mobile: {
                    required:"Please enter student phone number",
                    minlength:"10 digits only",
                    maxlength:"10 digits only",
                    number: "Enter number only!"
                },                      
                emailId: {
                    required:"Please enter email ID",
                    email:"Enter a valid email ID",
                    remote: "Email already in use!"
                },
                password: {
                    required:"Enter correct password",
                    minlength:"Please enter 6 digits minimum",
                    maxlength:"Please enter 15 digits maximum"
                }, 

            },    
            submitHandler: function(form) {
                form.submit();
            }
        });     
    });
</script>
