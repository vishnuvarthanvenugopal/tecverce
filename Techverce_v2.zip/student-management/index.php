<?php
include 'connect.php';
if(isset($_POST['login']))
{
    $email = mysqli_real_escape_string($connection,$_POST['email']);
    $password = mysqli_real_escape_string ($connection,md5($_REQUEST['password']));
    if(empty($email)&&empty($password)) {
        $error = 'Fileds are Mandatory';
    } else  {
        //Checking Login Detail
        $result = mysqli_query($connection,"SELECT * FROM admin_login WHERE email = '".$email."' AND password = '".$password."' AND status = 'ACTIVE' ");
        $row = mysqli_fetch_assoc($result);
        $count = mysqli_num_rows($result);
        if($count) {
            $_SESSION['userType'] = array(
                'name' => $row['name'],     
                'role'=>$row['userType']
            );
            $status = $row['status'];
            if($status == 'INACTIVE') {
                $error = "Sorry! Your account is deactivated.";
            } else { 
                // status is active
                $role=$_SESSION['userType']['role'];

                if(!$role && $row['name'] == 'ACCOUNTS'){
                  $role = 'ACCOUNTANT';
                  $_SESSION['userType']['role'] = 'ACCOUNTANT';
                }

                //Redirecting User Based on Role
                switch($role) {
                    case 'SUPERADMIN':
                    header('location:dashboard.php');
                    break;
                    case 'ADMIN':
                    header('location:add-payment.php');
                    break;
                    case 'ACCOUNTANT':
                    header('location:add-payment.php');
                    break;
                    case 'USER':
                    header('location:add-news.php');
                    break;
                }
            }
        } else {
            $error='Please enter valid credential';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="">
  <meta name="author" content="">
  <!-- Favicon icon -->
  <!--  -->
  <title>Student Management</title>
  <!-- Bootstrap Core CSS -->
  <link href="css/lib/bootstrap/bootstrap.min.css" rel="stylesheet">
  <link rel="shortcut icon" href=" https://www.aiht.ac.in/online-payment/images/fevi.png" type="image/x-icon" />
  <!-- Custom CSS -->
  <link href="css/helper.css" rel="stylesheet">
  <link href="css/style.css" rel="stylesheet">
</head>
<!--<body class="fix-header fix-sidebar">-->
<body class="fix-header fix-sidebar" style="background-image:url(images/bg.jpg);background-position: center;
  background-repeat: no-repeat;
  background-size: cover; height:950px;">
  <!-- Preloader - style you can find in spinners.css -->
  <div class="preloader">
    <svg class="circular" viewBox="25 25 50 50">
      <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="2" stroke-miterlimit="10" /> </svg>
    </div>
    <!-- Main wrapper  -->
    <div id="main-wrapper">
      <div class="unix-login">
        <div class="container-fluid">
          <div class="row justify-content-center">
            <div class="col-lg-4">
              <div class="login-content card1">
                <div class="login-form" style="background:#007bff;">
                  <h4><b><img style="width:100%;" src="http://asa.ac.in/images/logo1.png" alt="" class="dark-logo" /></b></h4>
                  <form method="POST" action="" id="add_user">
                    <?php if(isset($error)){ echo "<h4 style='color:red;text-align:center;'>".$error."</h4>";}?><br>
                      <div class="form-group">
                        <label>Email address</label>
                        <input type="text" id="val-email" name="email" class="form-control" placeholder="Email" value="<?php echo (isset($_POST['email'])) ? $_POST['email'] : ""; ?>" autocomplete="off" required>
                      </div>
                      <div class="form-group">
                        <label>Password</label>
                        <input type="password" name="password" class="form-control" placeholder="Password" required>
                      </div>
                      <button type="submit" id="login" name="login" value="Login" class="btn btn-success">Sign in</button>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- All Jquery -->
      <script src="js/lib/jquery/jquery.min.js"></script>
      <!-- Bootstrap tether Core JavaScript -->
      <script src="js/lib/bootstrap/js/popper.min.js"></script>
      <script src="js/lib/bootstrap/js/bootstrap.min.js"></script>
      <!-- slimscrollbar scrollbar JavaScript -->
      <script src="js/jquery.slimscroll.js"></script>
      <!--Menu sidebar -->
      <script src="js/sidebarmenu.js"></script>
      <!--stickey kit -->
      <script src="js/lib/sticky-kit-master/dist/sticky-kit.min.js"></script>
      <!--Custom JavaScript -->
      <script src="js/custom.min.js"></script>
      <!-- Global site tag (gtag.js) - Google Analytics -->
      <script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13"></script>

      <script src="http://code.jquery.com/jquery-1.8.3.min.js" type="text/javascript"></script>

      <script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.10.0/jquery.validate.js" type="text/javascript"></script>
      <script  type="text/javascript">
        $().ready(function () {
          $("#add_user").validate({
            rules: {
              email: 
              {
                required: true,
                email: true         
              },
              password: "required"
            },
            messages: {
              email: {
                required:"Please enter email address",
                email:"Please enter a valid email address",
                remote: "Email already in use!"
              },
              password: {
                required:"Please enter correct password",
              }, 
            },    
            submitHandler: function(form) {
              form.submit();
            }
          });   
        }); 
      </script>
    </body>


    <!-- Mirrored from colorlib.com/polygon/elaadmin/page-login.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 25 Jul 2018 07:51:54 GMT -->
    </html>